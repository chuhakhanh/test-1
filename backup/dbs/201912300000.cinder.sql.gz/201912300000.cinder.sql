-- MariaDB dump 10.17  Distrib 10.4.10-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: cinder
-- ------------------------------------------------------
-- Server version	10.4.10-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `cinder`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `cinder` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `cinder`;

--
-- Table structure for table `attachment_specs`
--

DROP TABLE IF EXISTS `attachment_specs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attachment_specs` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attachment_id` varchar(36) NOT NULL,
  `key` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_attachment_specs_attachment_id` (`attachment_id`),
  CONSTRAINT `attachment_specs_ibfk_1` FOREIGN KEY (`attachment_id`) REFERENCES `volume_attachment` (`id`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`deleted` in (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attachment_specs`
--

LOCK TABLES `attachment_specs` WRITE;
/*!40000 ALTER TABLE `attachment_specs` DISABLE KEYS */;
/*!40000 ALTER TABLE `attachment_specs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_metadata`
--

DROP TABLE IF EXISTS `backup_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backup_metadata` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `backup_id` varchar(36) NOT NULL,
  `key` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_backup_metadata_backup_id` (`backup_id`),
  CONSTRAINT `backup_metadata_ibfk_1` FOREIGN KEY (`backup_id`) REFERENCES `backups` (`id`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`deleted` in (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_metadata`
--

LOCK TABLES `backup_metadata` WRITE;
/*!40000 ALTER TABLE `backup_metadata` DISABLE KEYS */;
/*!40000 ALTER TABLE `backup_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backups`
--

DROP TABLE IF EXISTS `backups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backups` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `id` varchar(36) NOT NULL,
  `volume_id` varchar(36) NOT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `host` varchar(255) DEFAULT NULL,
  `availability_zone` varchar(255) DEFAULT NULL,
  `display_name` varchar(255) DEFAULT NULL,
  `display_description` varchar(255) DEFAULT NULL,
  `container` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `fail_reason` varchar(255) DEFAULT NULL,
  `service_metadata` varchar(255) DEFAULT NULL,
  `service` varchar(255) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `object_count` int(11) DEFAULT NULL,
  `parent_id` varchar(36) DEFAULT NULL,
  `temp_volume_id` varchar(36) DEFAULT NULL,
  `temp_snapshot_id` varchar(36) DEFAULT NULL,
  `num_dependent_backups` int(11) DEFAULT NULL,
  `snapshot_id` varchar(36) DEFAULT NULL,
  `data_timestamp` datetime DEFAULT NULL,
  `restore_volume_id` varchar(36) DEFAULT NULL,
  `encryption_key_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`deleted` in (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backups`
--

LOCK TABLES `backups` WRITE;
/*!40000 ALTER TABLE `backups` DISABLE KEYS */;
/*!40000 ALTER TABLE `backups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cgsnapshots`
--

DROP TABLE IF EXISTS `cgsnapshots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cgsnapshots` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `id` varchar(36) NOT NULL,
  `consistencygroup_id` varchar(36) NOT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_cgsnapshots_consistencygroup_id` (`consistencygroup_id`),
  CONSTRAINT `cgsnapshots_ibfk_1` FOREIGN KEY (`consistencygroup_id`) REFERENCES `consistencygroups` (`id`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`deleted` in (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cgsnapshots`
--

LOCK TABLES `cgsnapshots` WRITE;
/*!40000 ALTER TABLE `cgsnapshots` DISABLE KEYS */;
/*!40000 ALTER TABLE `cgsnapshots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clusters`
--

DROP TABLE IF EXISTS `clusters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clusters` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `binary` varchar(255) NOT NULL,
  `disabled` tinyint(1) DEFAULT NULL,
  `disabled_reason` varchar(255) DEFAULT NULL,
  `race_preventer` int(11) NOT NULL,
  `replication_status` varchar(36) DEFAULT NULL,
  `active_backend_id` varchar(255) DEFAULT NULL,
  `frozen` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`binary`,`race_preventer`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`deleted` in (0,1)),
  CONSTRAINT `CONSTRAINT_2` CHECK (`disabled` in (0,1)),
  CONSTRAINT `CONSTRAINT_3` CHECK (`frozen` in (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clusters`
--

LOCK TABLES `clusters` WRITE;
/*!40000 ALTER TABLE `clusters` DISABLE KEYS */;
/*!40000 ALTER TABLE `clusters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consistencygroups`
--

DROP TABLE IF EXISTS `consistencygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consistencygroups` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `id` varchar(36) NOT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `host` varchar(255) DEFAULT NULL,
  `availability_zone` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `volume_type_id` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `cgsnapshot_id` varchar(36) DEFAULT NULL,
  `source_cgid` varchar(36) DEFAULT NULL,
  `cluster_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`deleted` in (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consistencygroups`
--

LOCK TABLES `consistencygroups` WRITE;
/*!40000 ALTER TABLE `consistencygroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `consistencygroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `driver_initiator_data`
--

DROP TABLE IF EXISTS `driver_initiator_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `driver_initiator_data` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `initiator` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `initiator` (`initiator`,`namespace`,`key`),
  KEY `ix_driver_initiator_data_initiator` (`initiator`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `driver_initiator_data`
--

LOCK TABLES `driver_initiator_data` WRITE;
/*!40000 ALTER TABLE `driver_initiator_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `driver_initiator_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `encryption`
--

DROP TABLE IF EXISTS `encryption`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `encryption` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `cipher` varchar(255) DEFAULT NULL,
  `control_location` varchar(255) NOT NULL,
  `key_size` int(11) DEFAULT NULL,
  `provider` varchar(255) NOT NULL,
  `volume_type_id` varchar(36) NOT NULL,
  `encryption_id` varchar(36) NOT NULL,
  PRIMARY KEY (`encryption_id`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`deleted` in (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `encryption`
--

LOCK TABLES `encryption` WRITE;
/*!40000 ALTER TABLE `encryption` DISABLE KEYS */;
/*!40000 ALTER TABLE `encryption` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_snapshots`
--

DROP TABLE IF EXISTS `group_snapshots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_snapshots` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `id` varchar(36) NOT NULL,
  `group_id` varchar(36) NOT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `group_type_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_group_snapshots_group_id` (`group_id`),
  CONSTRAINT `group_snapshots_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`deleted` in (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_snapshots`
--

LOCK TABLES `group_snapshots` WRITE;
/*!40000 ALTER TABLE `group_snapshots` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_snapshots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_type_projects`
--

DROP TABLE IF EXISTS `group_type_projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_type_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `group_type_id` varchar(36) DEFAULT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_type_id` (`group_type_id`,`project_id`,`deleted`),
  CONSTRAINT `group_type_projects_ibfk_1` FOREIGN KEY (`group_type_id`) REFERENCES `group_types` (`id`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`deleted` in (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_type_projects`
--

LOCK TABLES `group_type_projects` WRITE;
/*!40000 ALTER TABLE `group_type_projects` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_type_projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_type_specs`
--

DROP TABLE IF EXISTS `group_type_specs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_type_specs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `group_type_id` varchar(36) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_group_type_specs_group_type_id` (`group_type_id`),
  CONSTRAINT `group_type_specs_ibfk_1` FOREIGN KEY (`group_type_id`) REFERENCES `group_types` (`id`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`deleted` in (0,1))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_type_specs`
--

LOCK TABLES `group_type_specs` WRITE;
/*!40000 ALTER TABLE `group_type_specs` DISABLE KEYS */;
INSERT INTO `group_type_specs` VALUES (1,'consistent_group_snapshot_enabled','<is> True','53fb199f-7460-4bf5-9779-241aada9c542','2019-12-04 03:56:17','2019-12-04 03:56:17',NULL,0);
/*!40000 ALTER TABLE `group_type_specs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_types`
--

DROP TABLE IF EXISTS `group_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_types` (
  `id` varchar(36) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `is_public` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`deleted` in (0,1)),
  CONSTRAINT `CONSTRAINT_2` CHECK (`is_public` in (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_types`
--

LOCK TABLES `group_types` WRITE;
/*!40000 ALTER TABLE `group_types` DISABLE KEYS */;
INSERT INTO `group_types` VALUES ('53fb199f-7460-4bf5-9779-241aada9c542','default_cgsnapshot_type','Default group type for migrating cgsnapshot','2019-12-04 03:56:17','2019-12-04 03:56:17',NULL,0,1);
/*!40000 ALTER TABLE `group_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_volume_type_mapping`
--

DROP TABLE IF EXISTS `group_volume_type_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_volume_type_mapping` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `volume_type_id` varchar(36) NOT NULL,
  `group_id` varchar(36) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_group_volume_type_mapping_volume_type_id` (`volume_type_id`),
  KEY `ix_group_volume_type_mapping_group_id` (`group_id`),
  CONSTRAINT `group_volume_type_mapping_ibfk_1` FOREIGN KEY (`volume_type_id`) REFERENCES `volume_types` (`id`),
  CONSTRAINT `group_volume_type_mapping_ibfk_2` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`deleted` in (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_volume_type_mapping`
--

LOCK TABLES `group_volume_type_mapping` WRITE;
/*!40000 ALTER TABLE `group_volume_type_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_volume_type_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groups` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `id` varchar(36) NOT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `cluster_name` varchar(255) DEFAULT NULL,
  `host` varchar(255) DEFAULT NULL,
  `availability_zone` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `group_type_id` varchar(36) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `group_snapshot_id` varchar(36) DEFAULT NULL,
  `source_group_id` varchar(36) DEFAULT NULL,
  `replication_status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`deleted` in (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groups`
--

LOCK TABLES `groups` WRITE;
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `image_volume_cache_entries`
--

DROP TABLE IF EXISTS `image_volume_cache_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `image_volume_cache_entries` (
  `image_updated_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `host` varchar(255) NOT NULL,
  `image_id` varchar(36) NOT NULL,
  `volume_id` varchar(36) NOT NULL,
  `size` int(11) NOT NULL,
  `last_used` datetime NOT NULL,
  `cluster_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_image_volume_cache_entries_host` (`host`),
  KEY `ix_image_volume_cache_entries_image_id` (`image_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `image_volume_cache_entries`
--

LOCK TABLES `image_volume_cache_entries` WRITE;
/*!40000 ALTER TABLE `image_volume_cache_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `image_volume_cache_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messages` (
  `id` varchar(36) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `request_id` varchar(255) DEFAULT NULL,
  `resource_type` varchar(36) DEFAULT NULL,
  `resource_uuid` varchar(255) DEFAULT NULL,
  `event_id` varchar(255) NOT NULL,
  `message_level` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `detail_id` varchar(10) DEFAULT NULL,
  `action_id` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_messages_expires_at` (`expires_at`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`deleted` in (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
INSERT INTO `messages` VALUES ('182d5cf6-741d-44c8-a349-e3221813da16','673aefad16724aa994e9224b37780ca0','req-16213ea5-8562-442d-8017-aaa551a62157','VOLUME','02631a95-5721-4d00-bd32-5ba6d03f93f5','VOLUME_VOLUME_001_003','ERROR','2019-12-24 11:37:08',NULL,NULL,0,'2020-01-23 11:37:08','003','001'),('1a29f950-403c-4c3a-b897-5431770ff710','673aefad16724aa994e9224b37780ca0','req-d455c1f4-161e-4531-bd5a-a87aa60a54ae','VOLUME','27177a1e-ebea-4420-8749-84f55f99abd5','VOLUME_VOLUME_001_001','ERROR','2019-12-26 03:02:09',NULL,NULL,0,'2020-01-25 03:02:09','001','001'),('333867ff-1ee4-4d6b-94bd-f547349b53e5','673aefad16724aa994e9224b37780ca0','req-98c25e22-745b-4bd5-aae0-3cf9bc46dfc5','VOLUME','6c71c6ef-f0b7-4b7a-8d7f-590d148781d0','VOLUME_VOLUME_001_001','ERROR','2019-12-26 03:02:09',NULL,NULL,0,'2020-01-25 03:02:09','001','001'),('37ee2165-aa97-4252-84ae-941a5237bddf','673aefad16724aa994e9224b37780ca0','req-28046069-d328-47b7-8817-ed2e8c5e99a6','VOLUME','30d35d98-9a9d-41be-a88c-7a7a72a2830b','VOLUME_VOLUME_001_003','ERROR','2019-12-24 11:37:09',NULL,NULL,0,'2020-01-23 11:37:09','003','001'),('4cd02075-5a7c-47ca-9497-0348ba825621','673aefad16724aa994e9224b37780ca0','req-ac3c165a-aeda-4dca-8981-cebe07378ca7','VOLUME','63c2058f-8cee-4f9b-bc57-568ea24d74d5','VOLUME_VOLUME_001_003','ERROR','2019-12-24 11:37:09',NULL,NULL,0,'2020-01-23 11:37:09','003','001'),('551d444b-767f-428e-af1c-a85482c445a0','673aefad16724aa994e9224b37780ca0','req-c86c21f0-b8f7-48e7-ab83-f9bc88e505dd','VOLUME','08532237-1837-459d-8bcd-4aebb803ffa2','VOLUME_VOLUME_001_003','ERROR','2019-12-24 11:37:09',NULL,NULL,0,'2020-01-23 11:37:09','003','001'),('9bcba5f9-d36a-4948-800f-0c74ccea273b','673aefad16724aa994e9224b37780ca0','req-ef864e2e-20b1-4488-b820-b4034aa159ea','VOLUME','c9ccd3a2-86bf-4f2b-a088-772217a89c35','VOLUME_VOLUME_001_003','ERROR','2019-12-24 11:37:09',NULL,NULL,0,'2020-01-23 11:37:09','003','001'),('b0cbb580-070d-48df-aea5-4048d557a8a1','673aefad16724aa994e9224b37780ca0','req-3e35b115-6bfb-402b-8c8c-3476176e03ba','VOLUME','dc8f7150-698a-4c6c-beff-e89dab0fb8e7','VOLUME_VOLUME_001_003','ERROR','2019-12-24 11:37:09',NULL,NULL,0,'2020-01-23 11:37:09','003','001'),('d1d8488f-7af0-4010-9c41-946b259f20b3','673aefad16724aa994e9224b37780ca0','req-8a7a5645-f4ec-41d4-8776-5b5cc5dbfed6','VOLUME','803a4c2b-b2d1-4a2c-bd3e-0b505675ee9e','VOLUME_VOLUME_001_003','ERROR','2019-12-24 11:37:09',NULL,NULL,0,'2020-01-23 11:37:09','003','001');
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrate_version`
--

DROP TABLE IF EXISTS `migrate_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrate_version` (
  `repository_id` varchar(250) NOT NULL,
  `repository_path` text DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  PRIMARY KEY (`repository_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrate_version`
--

LOCK TABLES `migrate_version` WRITE;
/*!40000 ALTER TABLE `migrate_version` DISABLE KEYS */;
INSERT INTO `migrate_version` VALUES ('cinder','/usr/lib/python2.7/site-packages/cinder/db/sqlalchemy/migrate_repo',132);
/*!40000 ALTER TABLE `migrate_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quality_of_service_specs`
--

DROP TABLE IF EXISTS `quality_of_service_specs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quality_of_service_specs` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `id` varchar(36) NOT NULL,
  `specs_id` varchar(36) DEFAULT NULL,
  `key` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_quality_of_service_specs_specs_id` (`specs_id`),
  CONSTRAINT `quality_of_service_specs_ibfk_1` FOREIGN KEY (`specs_id`) REFERENCES `quality_of_service_specs` (`id`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`deleted` in (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quality_of_service_specs`
--

LOCK TABLES `quality_of_service_specs` WRITE;
/*!40000 ALTER TABLE `quality_of_service_specs` DISABLE KEYS */;
/*!40000 ALTER TABLE `quality_of_service_specs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quota_classes`
--

DROP TABLE IF EXISTS `quota_classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quota_classes` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_name` varchar(255) DEFAULT NULL,
  `resource` varchar(255) DEFAULT NULL,
  `hard_limit` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_quota_classes_class_name` (`class_name`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`deleted` in (0,1))
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quota_classes`
--

LOCK TABLES `quota_classes` WRITE;
/*!40000 ALTER TABLE `quota_classes` DISABLE KEYS */;
INSERT INTO `quota_classes` VALUES ('2019-12-04 10:56:16',NULL,NULL,0,1,'default','volumes',10),('2019-12-04 10:56:16',NULL,NULL,0,4,'default','snapshots',10),('2019-12-04 10:56:16',NULL,NULL,0,7,'default','gigabytes',1000),('2019-12-04 10:56:16',NULL,NULL,0,10,'default','consistencygroups',10),('2019-12-04 10:56:16',NULL,NULL,0,13,'default','per_volume_gigabytes',-1),('2019-12-04 10:56:16',NULL,NULL,0,16,'default','groups',10);
/*!40000 ALTER TABLE `quota_classes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quota_usages`
--

DROP TABLE IF EXISTS `quota_usages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quota_usages` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` varchar(255) DEFAULT NULL,
  `resource` varchar(300) DEFAULT NULL,
  `in_use` int(11) NOT NULL,
  `reserved` int(11) NOT NULL,
  `until_refresh` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `quota_usage_project_resource_idx` (`project_id`,`resource`),
  KEY `ix_quota_usages_project_id` (`project_id`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`deleted` in (0,1))
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quota_usages`
--

LOCK TABLES `quota_usages` WRITE;
/*!40000 ALTER TABLE `quota_usages` DISABLE KEYS */;
INSERT INTO `quota_usages` VALUES ('2019-12-06 16:07:49','2019-12-27 08:53:30',NULL,0,3,'673aefad16724aa994e9224b37780ca0','gigabytes',624,0,NULL),('2019-12-06 16:07:49','2019-12-27 08:53:30',NULL,0,6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',624,0,NULL),('2019-12-06 16:07:49','2019-12-27 08:53:30',NULL,0,9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',20,0,NULL),('2019-12-06 16:07:49','2019-12-27 08:53:30',NULL,0,12,'673aefad16724aa994e9224b37780ca0','volumes',20,0,NULL),('2019-12-09 11:48:04','2019-12-25 03:01:59',NULL,0,15,'673aefad16724aa994e9224b37780ca0','snapshots___DEFAULT__',2,0,NULL),('2019-12-09 11:48:04','2019-12-25 03:01:59',NULL,0,18,'673aefad16724aa994e9224b37780ca0','snapshots',2,0,NULL);
/*!40000 ALTER TABLE `quota_usages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quotas`
--

DROP TABLE IF EXISTS `quotas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quotas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `resource` varchar(255) NOT NULL,
  `hard_limit` int(11) DEFAULT NULL,
  `allocated` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`deleted` in (0,1))
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quotas`
--

LOCK TABLES `quotas` WRITE;
/*!40000 ALTER TABLE `quotas` DISABLE KEYS */;
INSERT INTO `quotas` VALUES (3,'2019-12-25 03:20:15',NULL,NULL,0,'default','volumes',10000,0),(6,'2019-12-25 03:21:23',NULL,NULL,0,'default','backups',1000,0),(9,'2019-12-25 08:38:30',NULL,NULL,0,'673aefad16724aa994e9224b37780ca0','volumes',1500,0),(12,'2019-12-25 08:39:47',NULL,NULL,0,'673aefad16724aa994e9224b37780ca0','snapshots',1500,0);
/*!40000 ALTER TABLE `quotas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservations`
--

DROP TABLE IF EXISTS `reservations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reservations` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `usage_id` int(11) DEFAULT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `resource` varchar(255) DEFAULT NULL,
  `delta` int(11) NOT NULL,
  `expire` datetime DEFAULT NULL,
  `allocated_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_reservations_allocated_id` (`allocated_id`),
  KEY `reservations_deleted_expire_idx` (`deleted`,`expire`),
  KEY `ix_reservations_usage_id` (`usage_id`),
  KEY `reservations_deleted_uuid_idx` (`deleted`,`uuid`),
  KEY `ix_reservations_project_id` (`project_id`),
  CONSTRAINT `reservations_ibfk_1` FOREIGN KEY (`usage_id`) REFERENCES `quota_usages` (`id`),
  CONSTRAINT `reservations_ibfk_2` FOREIGN KEY (`allocated_id`) REFERENCES `quotas` (`id`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`deleted` in (0,1))
) ENGINE=InnoDB AUTO_INCREMENT=1030 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservations`
--

LOCK TABLES `reservations` WRITE;
/*!40000 ALTER TABLE `reservations` DISABLE KEYS */;
INSERT INTO `reservations` VALUES ('2019-12-06 16:07:49','2019-12-06 16:07:49','2019-12-06 16:07:49',1,3,'cb22063b-85a2-4b7d-a8f7-555fc73d9006',3,'673aefad16724aa994e9224b37780ca0','gigabytes',2,'2019-12-07 16:07:49',NULL),('2019-12-06 16:07:49','2019-12-06 16:07:49','2019-12-06 16:07:49',1,6,'3e2db76f-7030-4a4b-b55b-a0f4a0ee6927',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',2,'2019-12-07 16:07:49',NULL),('2019-12-06 16:07:49','2019-12-06 16:07:49','2019-12-06 16:07:49',1,9,'a5fe6982-7003-44a6-8aa7-475da1ce54ca',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-07 16:07:49',NULL),('2019-12-06 16:07:49','2019-12-06 16:07:49','2019-12-06 16:07:49',1,12,'5ac52780-0920-4a78-a9e0-485f15018747',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-07 16:07:49',NULL),('2019-12-06 16:20:47','2019-12-06 16:20:47','2019-12-06 16:20:47',1,15,'1f5d2449-ec7a-43b3-ab30-287ff5371a6d',3,'673aefad16724aa994e9224b37780ca0','gigabytes',10,'2019-12-07 16:20:47',NULL),('2019-12-06 16:20:47','2019-12-06 16:20:47','2019-12-06 16:20:47',1,18,'e814f5dd-40c4-43a4-ae6e-f5a5bd7246a8',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',10,'2019-12-07 16:20:47',NULL),('2019-12-06 16:20:47','2019-12-06 16:20:47','2019-12-06 16:20:47',1,21,'64922f9d-51d0-46c0-9f69-c39b5f3aa35e',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-07 16:20:47',NULL),('2019-12-06 16:20:47','2019-12-06 16:20:47','2019-12-06 16:20:47',1,24,'e8bb225d-d7a0-4bcd-bc82-d794de5617a3',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-07 16:20:47',NULL),('2019-12-09 11:48:04','2019-12-09 11:48:04','2019-12-09 11:48:04',1,27,'1c6c7c42-7c4b-4ff3-a7bc-ed50741804c8',3,'673aefad16724aa994e9224b37780ca0','gigabytes',2,'2019-12-10 11:48:04',NULL),('2019-12-09 11:48:04','2019-12-09 11:48:04','2019-12-09 11:48:04',1,30,'08b66eb1-ef1c-4857-b549-61724df4ea59',15,'673aefad16724aa994e9224b37780ca0','snapshots___DEFAULT__',1,'2019-12-10 11:48:04',NULL),('2019-12-09 11:48:04','2019-12-09 11:48:04','2019-12-09 11:48:04',1,33,'5593a62c-2878-4e8b-ad69-c1002f022206',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',2,'2019-12-10 11:48:04',NULL),('2019-12-09 11:48:04','2019-12-09 11:48:04','2019-12-09 11:48:04',1,36,'15c0c3cb-76a5-4c11-bc7b-d2c7a1d2d25f',18,'673aefad16724aa994e9224b37780ca0','snapshots',1,'2019-12-10 11:48:04',NULL),('2019-12-24 09:51:23','2019-12-24 09:51:23','2019-12-24 09:51:23',1,39,'29efc8d9-b77f-4008-9360-286713e67307',3,'673aefad16724aa994e9224b37780ca0','gigabytes',100,'2019-12-25 09:51:23',NULL),('2019-12-24 09:51:23','2019-12-24 09:51:23','2019-12-24 09:51:23',1,42,'f02d9c28-c821-4d33-b064-779dd22d296d',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',100,'2019-12-25 09:51:23',NULL),('2019-12-24 09:51:23','2019-12-24 09:51:23','2019-12-24 09:51:23',1,45,'f5a95320-039d-4c16-9beb-072f28ccdb51',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-25 09:51:23',NULL),('2019-12-24 09:51:23','2019-12-24 09:51:23','2019-12-24 09:51:23',1,48,'09c142b0-442d-482e-96a5-eaada6b71a15',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-25 09:51:23',NULL),('2019-12-24 09:51:24','2019-12-24 09:51:24','2019-12-24 09:51:24',1,51,'dec94782-5a46-4eb8-b1ec-bd25d5799e77',3,'673aefad16724aa994e9224b37780ca0','gigabytes',40,'2019-12-25 09:51:24',NULL),('2019-12-24 09:51:24','2019-12-24 09:51:24','2019-12-24 09:51:24',1,54,'4c09254f-016b-4c3c-a63d-6e92c813ce6e',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',40,'2019-12-25 09:51:24',NULL),('2019-12-24 09:51:24','2019-12-24 09:51:24','2019-12-24 09:51:24',1,57,'971d71ab-5837-4e70-9f48-bb7684af6a46',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-25 09:51:24',NULL),('2019-12-24 09:51:24','2019-12-24 09:51:24','2019-12-24 09:51:24',1,60,'b65acebd-3001-4241-be3a-b21f7c936e51',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-25 09:51:24',NULL),('2019-12-24 09:56:01','2019-12-24 09:56:02','2019-12-24 09:56:02',1,63,'144d5c09-ad07-42b4-a940-1a0bf96b4809',3,'673aefad16724aa994e9224b37780ca0','gigabytes',100,'2019-12-25 09:56:01',NULL),('2019-12-24 09:56:01','2019-12-24 09:56:02','2019-12-24 09:56:02',1,66,'b60ca83f-58dd-45bd-81fc-7cb683d5ee1f',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',100,'2019-12-25 09:56:01',NULL),('2019-12-24 09:56:01','2019-12-24 09:56:02','2019-12-24 09:56:02',1,69,'f0628757-243b-42ea-b737-90b2b930cc47',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-25 09:56:01',NULL),('2019-12-24 09:56:02','2019-12-24 09:56:02','2019-12-24 09:56:02',1,72,'a0da9986-0ced-4351-bebd-79b8c4926901',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-25 09:56:01',NULL),('2019-12-24 09:58:19','2019-12-24 09:58:19','2019-12-24 09:58:19',1,75,'0362abbb-4294-4c37-a3b8-39ed3785f287',3,'673aefad16724aa994e9224b37780ca0','gigabytes',40,'2019-12-25 09:58:19',NULL),('2019-12-24 09:58:19','2019-12-24 09:58:19','2019-12-24 09:58:19',1,78,'ebc1c4ba-409a-4693-acec-9ccfa21006c8',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',40,'2019-12-25 09:58:19',NULL),('2019-12-24 09:58:19','2019-12-24 09:58:19','2019-12-24 09:58:19',1,81,'d93733b7-2731-4d0e-8783-cf4b65e36ee7',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-25 09:58:19',NULL),('2019-12-24 09:58:19','2019-12-24 09:58:19','2019-12-24 09:58:19',1,84,'7311f87f-cb1d-49ad-9c70-7dbf9b3f1f4c',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-25 09:58:19',NULL),('2019-12-24 10:04:25','2019-12-24 10:04:25','2019-12-24 10:04:25',1,87,'5e2a75f0-2119-49e3-bf82-e45e4698bb65',3,'673aefad16724aa994e9224b37780ca0','gigabytes',10,'2019-12-25 10:04:25',NULL),('2019-12-24 10:04:25','2019-12-24 10:04:25','2019-12-24 10:04:25',1,90,'9ce6c441-ce16-4961-9c8a-6eaf4a57bf6f',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',10,'2019-12-25 10:04:25',NULL),('2019-12-24 10:04:25','2019-12-24 10:04:25','2019-12-24 10:04:25',1,93,'beb13289-e270-4469-aa8b-7c2c6cc3263e',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-25 10:04:25',NULL),('2019-12-24 10:04:25','2019-12-24 10:04:25','2019-12-24 10:04:25',1,96,'438ede58-f037-4562-93b9-631289dced93',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-25 10:04:25',NULL),('2019-12-24 10:14:14','2019-12-24 10:14:14','2019-12-24 10:14:14',1,99,'f87e7c23-5516-42d8-994a-5878ed578964',3,'673aefad16724aa994e9224b37780ca0','gigabytes',10,'2019-12-25 10:14:14',NULL),('2019-12-24 10:14:14','2019-12-24 10:14:14','2019-12-24 10:14:14',1,102,'9e5300f2-63c0-4cf0-83b1-ac288f594e7e',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',10,'2019-12-25 10:14:14',NULL),('2019-12-24 10:14:14','2019-12-24 10:14:14','2019-12-24 10:14:14',1,105,'0a6d6e74-b03f-42a4-8396-3ca7ab759581',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-25 10:14:14',NULL),('2019-12-24 10:14:14','2019-12-24 10:14:14','2019-12-24 10:14:14',1,108,'f95582ae-939b-4d89-bce1-6a7ffd69bba4',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-25 10:14:14',NULL),('2019-12-24 10:27:02','2019-12-24 10:27:02','2019-12-24 10:27:02',1,111,'fa6a17e1-4651-4aea-82f0-c899e68bfaf5',3,'673aefad16724aa994e9224b37780ca0','gigabytes',10,'2019-12-25 10:27:02',NULL),('2019-12-24 10:27:02','2019-12-24 10:27:02','2019-12-24 10:27:02',1,114,'d9c23a4f-4acd-4abd-93c4-21683a54b22c',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',10,'2019-12-25 10:27:02',NULL),('2019-12-24 10:27:02','2019-12-24 10:27:02','2019-12-24 10:27:02',1,117,'97c4d8dc-f853-47bb-8e27-f9e81de7d842',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-25 10:27:02',NULL),('2019-12-24 10:27:02','2019-12-24 10:27:02','2019-12-24 10:27:02',1,120,'e7fff674-3549-469b-93f6-b15967e48001',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-25 10:27:02',NULL),('2019-12-24 11:20:14','2019-12-24 11:20:14','2019-12-24 11:20:14',1,123,'6cfdce0e-191b-4880-98fc-02c3b6d0b6f7',3,'673aefad16724aa994e9224b37780ca0','gigabytes',10,'2019-12-25 11:20:14',NULL),('2019-12-24 11:20:14','2019-12-24 11:20:14','2019-12-24 11:20:14',1,126,'bfb29c8d-e148-49e0-8c60-e45c1e400d90',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',10,'2019-12-25 11:20:14',NULL),('2019-12-24 11:20:14','2019-12-24 11:20:14','2019-12-24 11:20:14',1,129,'4d7728dd-b56c-457e-8500-ca2803d3736a',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-25 11:20:14',NULL),('2019-12-24 11:20:14','2019-12-24 11:20:14','2019-12-24 11:20:14',1,132,'8cce94ad-a6d1-4771-ac11-c1502421beae',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-25 11:20:14',NULL),('2019-12-24 11:41:24','2019-12-24 11:41:24','2019-12-24 11:41:24',1,135,'6db66aa3-7e5b-4c78-be66-3c0fb3a37c19',3,'673aefad16724aa994e9224b37780ca0','gigabytes',-10,'2019-12-25 11:41:24',NULL),('2019-12-24 11:41:24','2019-12-24 11:41:24','2019-12-24 11:41:24',1,138,'dd524e02-3f64-4e22-9834-5ca7bfa776cb',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',-10,'2019-12-25 11:41:24',NULL),('2019-12-24 11:41:24','2019-12-24 11:41:24','2019-12-24 11:41:24',1,141,'a88ecaa9-88d2-4bcc-8a77-a61df9d681c9',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',-1,'2019-12-25 11:41:24',NULL),('2019-12-24 11:41:24','2019-12-24 11:41:24','2019-12-24 11:41:24',1,144,'739e8fe7-6763-4468-bb2a-516d107ebc4d',12,'673aefad16724aa994e9224b37780ca0','volumes',-1,'2019-12-25 11:41:24',NULL),('2019-12-24 11:41:24','2019-12-24 11:41:24','2019-12-24 11:41:24',1,147,'f8736703-2f60-4520-b5df-c41efa0e941b',3,'673aefad16724aa994e9224b37780ca0','gigabytes',-10,'2019-12-25 11:41:24',NULL),('2019-12-24 11:41:24','2019-12-24 11:41:24','2019-12-24 11:41:24',1,150,'00b5e8a2-078f-47ec-9e54-91c6874ef22c',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',-10,'2019-12-25 11:41:24',NULL),('2019-12-24 11:41:24','2019-12-24 11:41:24','2019-12-24 11:41:24',1,153,'b2d0271e-b202-49fc-8de1-0c094480970c',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',-1,'2019-12-25 11:41:24',NULL),('2019-12-24 11:41:24','2019-12-24 11:41:24','2019-12-24 11:41:24',1,156,'84b26ac4-634d-4aac-9fb3-8ba62b1e6021',12,'673aefad16724aa994e9224b37780ca0','volumes',-1,'2019-12-25 11:41:24',NULL),('2019-12-24 11:41:24','2019-12-24 11:41:24','2019-12-24 11:41:24',1,159,'50109f37-16cd-416a-9e0d-c9f251ab1692',3,'673aefad16724aa994e9224b37780ca0','gigabytes',-10,'2019-12-25 11:41:24',NULL),('2019-12-24 11:41:24','2019-12-24 11:41:24','2019-12-24 11:41:24',1,162,'24b7aa3b-dd49-4400-b155-7b6f78aacc56',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',-10,'2019-12-25 11:41:24',NULL),('2019-12-24 11:41:24','2019-12-24 11:41:24','2019-12-24 11:41:24',1,165,'f5a3da30-b9f7-42ea-bc85-9db336871545',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',-1,'2019-12-25 11:41:24',NULL),('2019-12-24 11:41:24','2019-12-24 11:41:24','2019-12-24 11:41:24',1,168,'fea7830b-aa82-4417-ba4d-22f324c2e428',12,'673aefad16724aa994e9224b37780ca0','volumes',-1,'2019-12-25 11:41:24',NULL),('2019-12-24 11:41:24','2019-12-24 11:41:24','2019-12-24 11:41:24',1,171,'f44c923f-efcd-49b0-8145-2b20e1e47611',3,'673aefad16724aa994e9224b37780ca0','gigabytes',-40,'2019-12-25 11:41:24',NULL),('2019-12-24 11:41:24','2019-12-24 11:41:24','2019-12-24 11:41:24',1,174,'c287163d-5380-4ea8-b6fb-301eb4e15725',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',-40,'2019-12-25 11:41:24',NULL),('2019-12-24 11:41:24','2019-12-24 11:41:24','2019-12-24 11:41:24',1,177,'2260693e-f76a-4b64-b33b-b0517d42dad7',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',-1,'2019-12-25 11:41:24',NULL),('2019-12-24 11:41:24','2019-12-24 11:41:24','2019-12-24 11:41:24',1,180,'70609a91-2890-48a6-8eb8-7801041e3041',12,'673aefad16724aa994e9224b37780ca0','volumes',-1,'2019-12-25 11:41:24',NULL),('2019-12-24 11:41:24','2019-12-24 11:41:24','2019-12-24 11:41:24',1,183,'f3d6b0a2-ee35-465f-a87b-5145ee8497e4',3,'673aefad16724aa994e9224b37780ca0','gigabytes',-10,'2019-12-25 11:41:24',NULL),('2019-12-24 11:41:24','2019-12-24 11:41:24','2019-12-24 11:41:24',1,186,'eb0cfd91-3346-43c4-8163-c014e04e0a24',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',-10,'2019-12-25 11:41:24',NULL),('2019-12-24 11:41:24','2019-12-24 11:41:24','2019-12-24 11:41:24',1,189,'6e8299ce-b2f0-43e2-9772-fbd0c0856a40',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',-1,'2019-12-25 11:41:24',NULL),('2019-12-24 11:41:24','2019-12-24 11:41:24','2019-12-24 11:41:24',1,192,'ff5df9dc-00db-4ff9-a2c7-6e33abb166e9',12,'673aefad16724aa994e9224b37780ca0','volumes',-1,'2019-12-25 11:41:24',NULL),('2019-12-24 11:41:24','2019-12-24 11:41:25','2019-12-24 11:41:25',1,195,'bb4fe832-c1a4-4d85-a4c4-2d090eeeab5b',3,'673aefad16724aa994e9224b37780ca0','gigabytes',-100,'2019-12-25 11:41:24',NULL),('2019-12-24 11:41:24','2019-12-24 11:41:25','2019-12-24 11:41:25',1,198,'bd24e355-1154-478c-a9c5-43c980fff320',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',-100,'2019-12-25 11:41:24',NULL),('2019-12-24 11:41:24','2019-12-24 11:41:25','2019-12-24 11:41:25',1,201,'7f91a311-f395-4e2e-b34b-2fdafcb7daf3',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',-1,'2019-12-25 11:41:24',NULL),('2019-12-24 11:41:24','2019-12-24 11:41:25','2019-12-24 11:41:25',1,204,'ccdfda39-d71d-469c-bfdb-2f01491a2cdb',12,'673aefad16724aa994e9224b37780ca0','volumes',-1,'2019-12-25 11:41:24',NULL),('2019-12-24 11:41:25','2019-12-24 11:41:25','2019-12-24 11:41:25',1,207,'cf7fba91-b441-400d-8977-dc56b18d6d83',3,'673aefad16724aa994e9224b37780ca0','gigabytes',-40,'2019-12-25 11:41:25',NULL),('2019-12-24 11:41:25','2019-12-24 11:41:25','2019-12-24 11:41:25',1,210,'6ceafd50-f0b4-4f52-9374-773fe30928d4',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',-40,'2019-12-25 11:41:25',NULL),('2019-12-24 11:41:25','2019-12-24 11:41:25','2019-12-24 11:41:25',1,213,'7e071369-6a85-41e0-a86f-1e1a20152d91',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',-1,'2019-12-25 11:41:25',NULL),('2019-12-24 11:41:25','2019-12-24 11:41:25','2019-12-24 11:41:25',1,216,'6ab0c31b-2243-4551-a238-b8adb4fce6f5',12,'673aefad16724aa994e9224b37780ca0','volumes',-1,'2019-12-25 11:41:25',NULL),('2019-12-24 11:41:25','2019-12-24 11:41:25','2019-12-24 11:41:25',1,219,'6dc2cc7d-9ddd-41b0-ba72-9a16f4cbc462',3,'673aefad16724aa994e9224b37780ca0','gigabytes',-100,'2019-12-25 11:41:25',NULL),('2019-12-24 11:41:25','2019-12-24 11:41:25','2019-12-24 11:41:25',1,222,'3bb40b60-3f88-425d-aa50-5b97a4c7d921',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',-100,'2019-12-25 11:41:25',NULL),('2019-12-24 11:41:25','2019-12-24 11:41:25','2019-12-24 11:41:25',1,225,'d081dc47-c764-44cb-be3b-6d7681380c63',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',-1,'2019-12-25 11:41:25',NULL),('2019-12-24 11:41:25','2019-12-24 11:41:25','2019-12-24 11:41:25',1,228,'58525654-bea3-41e0-9ac6-1fb6934c8357',12,'673aefad16724aa994e9224b37780ca0','volumes',-1,'2019-12-25 11:41:25',NULL),('2019-12-24 11:42:09','2019-12-24 11:42:09','2019-12-24 11:42:09',1,231,'7796f52d-38f2-48a8-81ed-4e152c89a067',3,'673aefad16724aa994e9224b37780ca0','gigabytes',10,'2019-12-25 11:42:08',NULL),('2019-12-24 11:42:09','2019-12-24 11:42:09','2019-12-24 11:42:09',1,234,'3c89b414-8815-4ae6-a73d-8df0c9b1bea8',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',10,'2019-12-25 11:42:08',NULL),('2019-12-24 11:42:09','2019-12-24 11:42:09','2019-12-24 11:42:09',1,237,'d9af9107-b494-486b-a27a-04a05823ea11',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-25 11:42:08',NULL),('2019-12-24 11:42:09','2019-12-24 11:42:09','2019-12-24 11:42:09',1,240,'f0ab1846-5ab2-4c96-91f2-a8d42d5b4916',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-25 11:42:08',NULL),('2019-12-24 11:47:20','2019-12-24 11:47:20','2019-12-24 11:47:20',1,243,'80392da7-02e1-41aa-b975-772bee4b16c2',3,'673aefad16724aa994e9224b37780ca0','gigabytes',10,'2019-12-25 11:47:20',NULL),('2019-12-24 11:47:20','2019-12-24 11:47:20','2019-12-24 11:47:20',1,246,'8c42c5ed-000c-4335-8dd6-776f0c06b6fb',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',10,'2019-12-25 11:47:20',NULL),('2019-12-24 11:47:20','2019-12-24 11:47:20','2019-12-24 11:47:20',1,249,'1924bc4c-a042-4f60-8e80-687533299ec7',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-25 11:47:20',NULL),('2019-12-24 11:47:20','2019-12-24 11:47:20','2019-12-24 11:47:20',1,252,'f5be6306-f3db-4f63-a55d-829c1919018a',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-25 11:47:20',NULL),('2019-12-24 11:50:48','2019-12-24 11:50:48','2019-12-24 11:50:48',1,255,'8e9b91dc-58a2-4762-9fe9-f3be3c45c94d',3,'673aefad16724aa994e9224b37780ca0','gigabytes',10,'2019-12-25 11:50:48',NULL),('2019-12-24 11:50:48','2019-12-24 11:50:48','2019-12-24 11:50:48',1,258,'13b3b19d-4fb6-4646-90df-5871ae6918ac',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',10,'2019-12-25 11:50:48',NULL),('2019-12-24 11:50:48','2019-12-24 11:50:48','2019-12-24 11:50:48',1,261,'6da6490a-59ea-4313-800d-501d39a54c6d',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-25 11:50:48',NULL),('2019-12-24 11:50:48','2019-12-24 11:50:48','2019-12-24 11:50:48',1,264,'41859f96-77bc-4aff-93ac-a44764678400',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-25 11:50:48',NULL),('2019-12-24 11:54:55','2019-12-24 11:54:56','2019-12-24 11:54:56',1,267,'02a06039-9d95-4318-a61e-28f5bdafab33',3,'673aefad16724aa994e9224b37780ca0','gigabytes',10,'2019-12-25 11:54:55',NULL),('2019-12-24 11:54:55','2019-12-24 11:54:56','2019-12-24 11:54:56',1,270,'4bbb6efd-e2e7-4d25-85b7-7c73f4e4e9db',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',10,'2019-12-25 11:54:55',NULL),('2019-12-24 11:54:55','2019-12-24 11:54:56','2019-12-24 11:54:56',1,273,'38b07e82-0994-42a6-9f8d-4aa5466f488b',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-25 11:54:55',NULL),('2019-12-24 11:54:55','2019-12-24 11:54:56','2019-12-24 11:54:56',1,276,'0a1496b3-11c3-4798-9b0c-da1b9b17fe5e',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-25 11:54:55',NULL),('2019-12-24 11:58:29','2019-12-24 11:58:29','2019-12-24 11:58:29',1,279,'9c61ab23-43f2-4e37-8246-8cddafea5888',3,'673aefad16724aa994e9224b37780ca0','gigabytes',10,'2019-12-25 11:58:29',NULL),('2019-12-24 11:58:29','2019-12-24 11:58:29','2019-12-24 11:58:29',1,282,'a2fcc2e8-96b0-4730-9a03-7e41cbe505e2',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',10,'2019-12-25 11:58:29',NULL),('2019-12-24 11:58:29','2019-12-24 11:58:29','2019-12-24 11:58:29',1,285,'6f64a3b9-ce01-4b2d-bcd8-58ffb46c0e99',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-25 11:58:29',NULL),('2019-12-24 11:58:29','2019-12-24 11:58:29','2019-12-24 11:58:29',1,288,'86e6de4e-62ff-49bf-8130-71e2c71f56e7',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-25 11:58:29',NULL),('2019-12-24 11:59:28','2019-12-24 11:59:28','2019-12-24 11:59:28',1,291,'f80a9445-36f3-425a-8ed0-978ed7771723',3,'673aefad16724aa994e9224b37780ca0','gigabytes',40,'2019-12-25 11:59:28',NULL),('2019-12-24 11:59:28','2019-12-24 11:59:28','2019-12-24 11:59:28',1,294,'dcb412a9-a4cc-4b9b-8692-439ed42b143f',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',40,'2019-12-25 11:59:28',NULL),('2019-12-24 11:59:28','2019-12-24 11:59:28','2019-12-24 11:59:28',1,297,'02a277df-6ecc-478b-bbf3-98f1253989ac',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-25 11:59:28',NULL),('2019-12-24 11:59:28','2019-12-24 11:59:28','2019-12-24 11:59:28',1,300,'8d434461-1129-41ac-b659-ef82c43261a7',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-25 11:59:28',NULL),('2019-12-25 02:41:54','2019-12-25 02:41:54','2019-12-25 02:41:54',1,303,'7c9e9389-1bb0-4c64-9282-52c3d429ae8c',3,'673aefad16724aa994e9224b37780ca0','gigabytes',100,'2019-12-26 02:41:54',NULL),('2019-12-25 02:41:54','2019-12-25 02:41:54','2019-12-25 02:41:54',1,306,'5d17cd64-ad5e-442c-bc1f-77576e9bb488',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',100,'2019-12-26 02:41:54',NULL),('2019-12-25 02:41:54','2019-12-25 02:41:54','2019-12-25 02:41:54',1,309,'ae6c979d-b3aa-410e-8931-ddaa253b2976',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-26 02:41:54',NULL),('2019-12-25 02:41:54','2019-12-25 02:41:54','2019-12-25 02:41:54',1,312,'ea6be7d4-7a2b-484a-94fa-a910f98a79e0',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-26 02:41:54',NULL),('2019-12-25 03:01:59','2019-12-25 03:01:59','2019-12-25 03:01:59',1,315,'9d22e72e-547e-4b9f-aca6-876a2e563c50',3,'673aefad16724aa994e9224b37780ca0','gigabytes',40,'2019-12-26 03:01:59',NULL),('2019-12-25 03:01:59','2019-12-25 03:01:59','2019-12-25 03:01:59',1,318,'4f02804b-5fc7-43c8-bc96-eda23f2523ab',15,'673aefad16724aa994e9224b37780ca0','snapshots___DEFAULT__',1,'2019-12-26 03:01:59',NULL),('2019-12-25 03:01:59','2019-12-25 03:01:59','2019-12-25 03:01:59',1,321,'20e260ce-3938-492a-96b7-2fdc42694cc6',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',40,'2019-12-26 03:01:59',NULL),('2019-12-25 03:01:59','2019-12-25 03:01:59','2019-12-25 03:01:59',1,324,'7d4c7df5-7be6-4b43-96e9-a14a1b6a2f19',18,'673aefad16724aa994e9224b37780ca0','snapshots',1,'2019-12-26 03:01:59',NULL),('2019-12-25 03:04:02','2019-12-25 03:04:02','2019-12-25 03:04:02',1,327,'d2a891b7-4042-4123-8dbb-b85f6ff31610',3,'673aefad16724aa994e9224b37780ca0','gigabytes',40,'2019-12-26 03:04:02',NULL),('2019-12-25 03:04:02','2019-12-25 03:04:02','2019-12-25 03:04:02',1,330,'a93e1cc9-7279-4978-bcf0-320e363117e9',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',40,'2019-12-26 03:04:02',NULL),('2019-12-25 03:04:02','2019-12-25 03:04:02','2019-12-25 03:04:02',1,333,'b5255e9e-11aa-4ff4-a351-af33e00c7d70',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-26 03:04:02',NULL),('2019-12-25 03:04:02','2019-12-25 03:04:02','2019-12-25 03:04:02',1,336,'e83c7fcc-8d93-4cba-905a-232dc55a8316',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-26 03:04:02',NULL),('2019-12-25 07:12:47','2019-12-25 07:12:47','2019-12-25 07:12:47',1,339,'5c1112a3-55b2-4a6b-a07a-695867acc2d2',3,'673aefad16724aa994e9224b37780ca0','gigabytes',-40,'2019-12-26 07:12:47',NULL),('2019-12-25 07:12:47','2019-12-25 07:12:47','2019-12-25 07:12:47',1,342,'12e65bbd-ef4c-4d0e-b59f-f9d8b07c840f',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',-40,'2019-12-26 07:12:47',NULL),('2019-12-25 07:12:47','2019-12-25 07:12:47','2019-12-25 07:12:47',1,345,'e7b5c35a-424c-417d-86e8-ad45912ddbc8',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',-1,'2019-12-26 07:12:47',NULL),('2019-12-25 07:12:47','2019-12-25 07:12:47','2019-12-25 07:12:47',1,348,'ffdbbb11-c0bd-4b0a-9a66-337812341f19',12,'673aefad16724aa994e9224b37780ca0','volumes',-1,'2019-12-26 07:12:47',NULL),('2019-12-25 07:20:32','2019-12-25 07:20:32','2019-12-25 07:20:32',1,351,'a5cb466f-3c2f-4f87-af49-5134e7c785bf',3,'673aefad16724aa994e9224b37780ca0','gigabytes',40,'2019-12-26 07:20:32',NULL),('2019-12-25 07:20:32','2019-12-25 07:20:32','2019-12-25 07:20:32',1,354,'d1d90195-5fc6-4973-8c2d-0c7a2237b5a8',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',40,'2019-12-26 07:20:32',NULL),('2019-12-25 07:20:32','2019-12-25 07:20:32','2019-12-25 07:20:32',1,357,'e354be0d-6665-42e7-aa2f-0113703bfed9',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-26 07:20:32',NULL),('2019-12-25 07:20:32','2019-12-25 07:20:32','2019-12-25 07:20:32',1,360,'a3c7640a-1f4b-4f67-8b7c-78400be6c1eb',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-26 07:20:32',NULL),('2019-12-25 08:32:38','2019-12-25 08:32:38','2019-12-25 08:32:38',1,361,'b1dc556e-04f3-4473-a457-b4321e3c7dd1',3,'673aefad16724aa994e9224b37780ca0','gigabytes',-10,'2019-12-26 08:32:38',NULL),('2019-12-25 08:32:38','2019-12-25 08:32:38','2019-12-25 08:32:38',1,364,'0dafdb72-2c94-4ce6-8aeb-204bd57f3b87',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',-10,'2019-12-26 08:32:38',NULL),('2019-12-25 08:32:38','2019-12-25 08:32:38','2019-12-25 08:32:38',1,367,'e63c924d-3d27-4647-9f9d-68b5865f289f',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',-1,'2019-12-26 08:32:38',NULL),('2019-12-25 08:32:38','2019-12-25 08:32:38','2019-12-25 08:32:38',1,370,'518029e6-a4a8-4fda-b3b2-ada75fddf8b7',12,'673aefad16724aa994e9224b37780ca0','volumes',-1,'2019-12-26 08:32:38',NULL),('2019-12-25 08:32:41','2019-12-25 08:32:41','2019-12-25 08:32:41',1,373,'89ed5b19-b11c-4652-a988-31fd7ca7444e',3,'673aefad16724aa994e9224b37780ca0','gigabytes',-100,'2019-12-26 08:32:41',NULL),('2019-12-25 08:32:41','2019-12-25 08:32:41','2019-12-25 08:32:41',1,376,'73d6e0bd-f187-481c-bbc5-f6195bd79090',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',-100,'2019-12-26 08:32:41',NULL),('2019-12-25 08:32:41','2019-12-25 08:32:41','2019-12-25 08:32:41',1,379,'a7554475-41b3-4517-98cf-f2196e61fee3',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',-1,'2019-12-26 08:32:41',NULL),('2019-12-25 08:32:41','2019-12-25 08:32:41','2019-12-25 08:32:41',1,382,'598be553-aa30-40ab-8c57-47a8918c69ed',12,'673aefad16724aa994e9224b37780ca0','volumes',-1,'2019-12-26 08:32:41',NULL),('2019-12-25 10:07:16','2019-12-25 10:07:16','2019-12-25 10:07:16',1,384,'44242816-a767-4390-a988-68f1b94726b3',3,'673aefad16724aa994e9224b37780ca0','gigabytes',40,'2019-12-26 10:07:16',NULL),('2019-12-25 10:07:16','2019-12-25 10:07:16','2019-12-25 10:07:16',1,387,'3abb96bd-b78b-42d6-b869-541869ce59b1',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',40,'2019-12-26 10:07:16',NULL),('2019-12-25 10:07:16','2019-12-25 10:07:16','2019-12-25 10:07:16',1,390,'136df0c6-e469-4e51-b504-a8401a6971b4',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-26 10:07:16',NULL),('2019-12-25 10:07:16','2019-12-25 10:07:16','2019-12-25 10:07:16',1,393,'f3cd82b1-84b0-440f-9272-4e3d08a29827',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-26 10:07:16',NULL),('2019-12-25 10:14:07','2019-12-25 10:14:07','2019-12-25 10:14:07',1,396,'e4f5d49f-468d-4615-8d7a-81035e464cb9',3,'673aefad16724aa994e9224b37780ca0','gigabytes',10,'2019-12-26 10:14:07',NULL),('2019-12-25 10:14:07','2019-12-25 10:14:07','2019-12-25 10:14:07',1,399,'29eb0397-bc49-445b-a250-254e7c846f06',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',10,'2019-12-26 10:14:07',NULL),('2019-12-25 10:14:07','2019-12-25 10:14:07','2019-12-25 10:14:07',1,402,'612e079a-8d13-4bd6-a0e3-478e7e0a296b',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-26 10:14:07',NULL),('2019-12-25 10:14:07','2019-12-25 10:14:07','2019-12-25 10:14:07',1,405,'f97dff76-c854-4d76-a88f-89630bb2ee8c',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-26 10:14:07',NULL),('2019-12-26 03:30:04','2019-12-26 03:30:04','2019-12-26 03:30:04',1,408,'31335f57-5435-4e5a-ab22-b15954b0d48a',3,'673aefad16724aa994e9224b37780ca0','gigabytes',40,'2019-12-27 03:30:04',NULL),('2019-12-26 03:30:04','2019-12-26 03:30:04','2019-12-26 03:30:04',1,411,'37d746e4-2129-484f-bf24-84b6e4cf0751',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',40,'2019-12-27 03:30:04',NULL),('2019-12-26 03:30:04','2019-12-26 03:30:04','2019-12-26 03:30:04',1,414,'a6f59fb9-c849-40ee-b076-7c06346e946b',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-27 03:30:04',NULL),('2019-12-26 03:30:04','2019-12-26 03:30:04','2019-12-26 03:30:04',1,417,'b4a05ef3-0314-4564-afe9-05cdb704b5bb',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-27 03:30:04',NULL),('2019-12-26 09:52:10','2019-12-26 09:52:10','2019-12-26 09:52:10',1,420,'0f58f5c7-f294-4f02-93ef-7cfbe1b5b68c',3,'673aefad16724aa994e9224b37780ca0','gigabytes',40,'2019-12-27 09:52:10',NULL),('2019-12-26 09:52:10','2019-12-26 09:52:10','2019-12-26 09:52:10',1,423,'9648236e-e549-405f-b5c7-cbad07679716',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',40,'2019-12-27 09:52:10',NULL),('2019-12-26 09:52:10','2019-12-26 09:52:10','2019-12-26 09:52:10',1,426,'9b868772-a2cb-4d74-8138-90e496243d43',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-27 09:52:10',NULL),('2019-12-26 09:52:10','2019-12-26 09:52:10','2019-12-26 09:52:10',1,429,'3e2f1421-7d47-4dce-8a56-60c0d6333444',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-27 09:52:10',NULL),('2019-12-26 09:52:10','2019-12-26 09:52:11','2019-12-26 09:52:11',1,432,'626e308f-f43c-457e-8f70-226af9616814',3,'673aefad16724aa994e9224b37780ca0','gigabytes',40,'2019-12-27 09:52:10',NULL),('2019-12-26 09:52:10','2019-12-26 09:52:11','2019-12-26 09:52:11',1,435,'041c1d4b-ebba-4cf2-94a1-74ae9c3ea877',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',40,'2019-12-27 09:52:10',NULL),('2019-12-26 09:52:10','2019-12-26 09:52:11','2019-12-26 09:52:11',1,438,'9b940c65-8ad1-4070-984e-6a37697e878c',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-27 09:52:10',NULL),('2019-12-26 09:52:10','2019-12-26 09:52:11','2019-12-26 09:52:11',1,441,'16029254-ba09-4acb-8944-0ddef8059b82',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-27 09:52:10',NULL),('2019-12-26 09:52:12','2019-12-26 09:52:12','2019-12-26 09:52:12',1,444,'bbd2f934-204e-4fdc-a4ad-6cf1428f365d',3,'673aefad16724aa994e9224b37780ca0','gigabytes',40,'2019-12-27 09:52:11',NULL),('2019-12-26 09:52:12','2019-12-26 09:52:12','2019-12-26 09:52:12',1,447,'52c30f49-e87a-47e7-bda9-1985f5038ec3',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',40,'2019-12-27 09:52:11',NULL),('2019-12-26 09:52:12','2019-12-26 09:52:12','2019-12-26 09:52:12',1,450,'2263698e-bf15-4f21-99d1-f36bbcb6e89c',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-27 09:52:11',NULL),('2019-12-26 09:52:12','2019-12-26 09:52:12','2019-12-26 09:52:12',1,453,'f45c920f-7f72-4685-899d-f0e1ac26b417',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-27 09:52:11',NULL),('2019-12-26 09:52:12','2019-12-26 09:52:12','2019-12-26 09:52:12',1,456,'4e7d1df6-7caa-43b3-bad7-4d238a6e280f',3,'673aefad16724aa994e9224b37780ca0','gigabytes',40,'2019-12-27 09:52:12',NULL),('2019-12-26 09:52:12','2019-12-26 09:52:12','2019-12-26 09:52:12',1,459,'0c9f570c-4463-4ec5-8f27-2c7fda66e281',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',40,'2019-12-27 09:52:12',NULL),('2019-12-26 09:52:12','2019-12-26 09:52:12','2019-12-26 09:52:12',1,462,'34f7fbf5-aa5b-4f37-92fe-faba8134b569',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-27 09:52:12',NULL),('2019-12-26 09:52:12','2019-12-26 09:52:12','2019-12-26 09:52:12',1,465,'59184d0c-f47b-405f-87a4-aa0579eb7d95',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-27 09:52:12',NULL),('2019-12-26 09:52:13','2019-12-26 09:52:13','2019-12-26 09:52:13',1,468,'133433cf-8005-4127-8fad-ef205db89400',3,'673aefad16724aa994e9224b37780ca0','gigabytes',40,'2019-12-27 09:52:13',NULL),('2019-12-26 09:52:13','2019-12-26 09:52:13','2019-12-26 09:52:13',1,471,'d5ab9071-a9f3-48e3-b684-664ea33e675d',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',40,'2019-12-27 09:52:13',NULL),('2019-12-26 09:52:13','2019-12-26 09:52:13','2019-12-26 09:52:13',1,474,'87e25296-aae6-4353-8b00-f70294dba6c7',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-27 09:52:13',NULL),('2019-12-26 09:52:13','2019-12-26 09:52:13','2019-12-26 09:52:13',1,477,'e3ec356a-1400-4d06-a6fa-a14db70064e0',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-27 09:52:13',NULL),('2019-12-26 09:52:13','2019-12-26 09:52:13','2019-12-26 09:52:13',1,480,'53164824-b468-46ab-884e-99a031362324',3,'673aefad16724aa994e9224b37780ca0','gigabytes',40,'2019-12-27 09:52:13',NULL),('2019-12-26 09:52:13','2019-12-26 09:52:13','2019-12-26 09:52:13',1,483,'b151bc80-aa1a-4a70-a4dc-ab36fe5c33e9',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',40,'2019-12-27 09:52:13',NULL),('2019-12-26 09:52:13','2019-12-26 09:52:13','2019-12-26 09:52:13',1,486,'a860d097-da63-46cc-af10-52b4b301fd39',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-27 09:52:13',NULL),('2019-12-26 09:52:13','2019-12-26 09:52:13','2019-12-26 09:52:13',1,489,'a53ff83c-ab21-48a7-ba8b-5eef569be330',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-27 09:52:13',NULL),('2019-12-26 09:52:13','2019-12-26 09:52:13','2019-12-26 09:52:13',1,492,'ad8a031f-00f6-48fb-b4d3-5ae33458e775',3,'673aefad16724aa994e9224b37780ca0','gigabytes',40,'2019-12-27 09:52:13',NULL),('2019-12-26 09:52:13','2019-12-26 09:52:13','2019-12-26 09:52:13',1,495,'a0b71e6f-d6a3-4227-ac1d-295508ac8385',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',40,'2019-12-27 09:52:13',NULL),('2019-12-26 09:52:13','2019-12-26 09:52:13','2019-12-26 09:52:13',1,498,'c3f5fb37-8c12-4fc7-8119-acc6b1b5d445',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-27 09:52:13',NULL),('2019-12-26 09:52:13','2019-12-26 09:52:13','2019-12-26 09:52:13',1,501,'f20c6933-4e1c-4368-85ba-d8e6de494c90',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-27 09:52:13',NULL),('2019-12-26 09:52:14','2019-12-26 09:52:15','2019-12-26 09:52:15',1,504,'f1f0e008-dfc4-41f1-a2da-11f7c0e1c129',3,'673aefad16724aa994e9224b37780ca0','gigabytes',40,'2019-12-27 09:52:14',NULL),('2019-12-26 09:52:15','2019-12-26 09:52:15','2019-12-26 09:52:15',1,507,'ec8d9946-2f20-475c-bf62-bffe8c1f88f5',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',40,'2019-12-27 09:52:14',NULL),('2019-12-26 09:52:15','2019-12-26 09:52:15','2019-12-26 09:52:15',1,510,'ca3eaf53-3579-4f61-91ab-552062bff14c',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-27 09:52:14',NULL),('2019-12-26 09:52:15','2019-12-26 09:52:15','2019-12-26 09:52:15',1,513,'777e0e6d-f9ff-4a0c-a0ba-d89143c1ff2c',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-27 09:52:14',NULL),('2019-12-26 09:52:15','2019-12-26 09:52:15','2019-12-26 09:52:15',1,516,'5ece44b8-174f-4b56-a9aa-a8b10509d2c2',3,'673aefad16724aa994e9224b37780ca0','gigabytes',40,'2019-12-27 09:52:15',NULL),('2019-12-26 09:52:15','2019-12-26 09:52:15','2019-12-26 09:52:15',1,519,'84152ba4-5d3e-4f3e-ba6c-5c0966f83f20',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',40,'2019-12-27 09:52:15',NULL),('2019-12-26 09:52:15','2019-12-26 09:52:15','2019-12-26 09:52:15',1,522,'c667fa23-d375-4c14-b52d-bcf5021059ab',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-27 09:52:15',NULL),('2019-12-26 09:52:15','2019-12-26 09:52:15','2019-12-26 09:52:15',1,525,'39c3f80c-6b79-42cc-88a2-bb7578aca392',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-27 09:52:15',NULL),('2019-12-26 09:52:15','2019-12-26 09:52:16','2019-12-26 09:52:16',1,528,'d1ca2feb-e0a6-4892-96e0-438de47cb002',3,'673aefad16724aa994e9224b37780ca0','gigabytes',40,'2019-12-27 09:52:15',NULL),('2019-12-26 09:52:16','2019-12-26 09:52:16','2019-12-26 09:52:16',1,531,'7407994d-3ed9-4b6a-bf6e-880cd08922ef',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',40,'2019-12-27 09:52:15',NULL),('2019-12-26 09:52:16','2019-12-26 09:52:16','2019-12-26 09:52:16',1,534,'20bf7bd3-2548-4ff2-a263-108643f1e431',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-27 09:52:15',NULL),('2019-12-26 09:52:16','2019-12-26 09:52:16','2019-12-26 09:52:16',1,537,'381bced0-fc13-4992-84d5-c99a4ccc8680',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-27 09:52:15',NULL),('2019-12-26 10:04:46','2019-12-26 10:04:46','2019-12-26 10:04:46',1,540,'9a26c7be-ab3d-4a27-b719-8b7bfa9ca36f',3,'673aefad16724aa994e9224b37780ca0','gigabytes',-40,'2019-12-27 10:04:46',NULL),('2019-12-26 10:04:46','2019-12-26 10:04:46','2019-12-26 10:04:46',1,543,'e238e49b-16a9-48f6-8588-52060592f3fe',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',-40,'2019-12-27 10:04:46',NULL),('2019-12-26 10:04:46','2019-12-26 10:04:46','2019-12-26 10:04:46',1,546,'72386cea-2d26-4a9e-8a0a-9a1eeb2c1792',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',-1,'2019-12-27 10:04:46',NULL),('2019-12-26 10:04:46','2019-12-26 10:04:46','2019-12-26 10:04:46',1,549,'2bd64004-edfe-46e5-a231-c98efc058c5d',12,'673aefad16724aa994e9224b37780ca0','volumes',-1,'2019-12-27 10:04:46',NULL),('2019-12-26 10:10:39','2019-12-26 10:10:39','2019-12-26 10:10:39',1,552,'c7e11fa2-e01b-4937-b795-0666e90e946d',3,'673aefad16724aa994e9224b37780ca0','gigabytes',-40,'2019-12-27 10:10:39',NULL),('2019-12-26 10:10:39','2019-12-26 10:10:39','2019-12-26 10:10:39',1,555,'126e6ace-e2ff-4b39-9398-6674b7c6ed7e',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',-40,'2019-12-27 10:10:39',NULL),('2019-12-26 10:10:39','2019-12-26 10:10:39','2019-12-26 10:10:39',1,558,'af10794d-8733-4ff1-b2d0-309a83e25e2b',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',-1,'2019-12-27 10:10:39',NULL),('2019-12-26 10:10:39','2019-12-26 10:10:39','2019-12-26 10:10:39',1,561,'0c8eebf9-4139-4fee-b946-b98f155aa943',12,'673aefad16724aa994e9224b37780ca0','volumes',-1,'2019-12-27 10:10:39',NULL),('2019-12-26 10:10:39','2019-12-26 10:10:39','2019-12-26 10:10:39',1,564,'e9bc3028-11c1-4c2f-979c-3d59e1cd9152',3,'673aefad16724aa994e9224b37780ca0','gigabytes',-40,'2019-12-27 10:10:39',NULL),('2019-12-26 10:10:39','2019-12-26 10:10:39','2019-12-26 10:10:39',1,567,'bb93e9db-fcaf-4669-bbab-ee3fc66db3f2',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',-40,'2019-12-27 10:10:39',NULL),('2019-12-26 10:10:39','2019-12-26 10:10:39','2019-12-26 10:10:39',1,570,'416d4d92-bbfa-4e1d-b52d-bcd3d6d1f732',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',-1,'2019-12-27 10:10:39',NULL),('2019-12-26 10:10:39','2019-12-26 10:10:39','2019-12-26 10:10:39',1,573,'ef4b225d-df02-49bc-987d-6fca24d2c379',12,'673aefad16724aa994e9224b37780ca0','volumes',-1,'2019-12-27 10:10:39',NULL),('2019-12-26 10:10:39','2019-12-26 10:10:39','2019-12-26 10:10:39',1,576,'ef704c13-4a02-493c-b4ca-6bb0a13f03c6',3,'673aefad16724aa994e9224b37780ca0','gigabytes',-40,'2019-12-27 10:10:39',NULL),('2019-12-26 10:10:39','2019-12-26 10:10:39','2019-12-26 10:10:39',1,579,'ebf1d493-6b35-4eab-bc43-939f552c6d29',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',-40,'2019-12-27 10:10:39',NULL),('2019-12-26 10:10:39','2019-12-26 10:10:39','2019-12-26 10:10:39',1,582,'0877c00d-3370-41cb-9561-03716048ba4c',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',-1,'2019-12-27 10:10:39',NULL),('2019-12-26 10:10:39','2019-12-26 10:10:39','2019-12-26 10:10:39',1,585,'f054bb7e-6240-4e60-bc93-bde796d83d40',12,'673aefad16724aa994e9224b37780ca0','volumes',-1,'2019-12-27 10:10:39',NULL),('2019-12-26 10:10:39','2019-12-26 10:10:40','2019-12-26 10:10:40',1,588,'89f1d968-794b-474f-bbb6-3526410486ec',3,'673aefad16724aa994e9224b37780ca0','gigabytes',-40,'2019-12-27 10:10:39',NULL),('2019-12-26 10:10:39','2019-12-26 10:10:40','2019-12-26 10:10:40',1,591,'a1809a2d-65a9-421b-99c3-847d88cbbecf',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',-40,'2019-12-27 10:10:39',NULL),('2019-12-26 10:10:39','2019-12-26 10:10:40','2019-12-26 10:10:40',1,594,'43017b5a-757b-4a37-ae73-9fbdb74bc498',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',-1,'2019-12-27 10:10:39',NULL),('2019-12-26 10:10:39','2019-12-26 10:10:40','2019-12-26 10:10:40',1,597,'93cd34f8-3ed9-439a-bacb-ff1f97a4fd15',12,'673aefad16724aa994e9224b37780ca0','volumes',-1,'2019-12-27 10:10:39',NULL),('2019-12-26 10:10:39','2019-12-26 10:10:40','2019-12-26 10:10:40',1,600,'82bfa59e-69e3-40d6-a6eb-14e39255bc6b',3,'673aefad16724aa994e9224b37780ca0','gigabytes',-40,'2019-12-27 10:10:39',NULL),('2019-12-26 10:10:39','2019-12-26 10:10:40','2019-12-26 10:10:40',1,603,'d2672789-f26c-4961-9364-cfe8794a908b',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',-40,'2019-12-27 10:10:39',NULL),('2019-12-26 10:10:39','2019-12-26 10:10:40','2019-12-26 10:10:40',1,606,'f8b85eee-76d4-4273-9d0e-966749c33ed0',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',-1,'2019-12-27 10:10:39',NULL),('2019-12-26 10:10:39','2019-12-26 10:10:40','2019-12-26 10:10:40',1,609,'ab48941a-c6f0-497f-a796-41b16f1b6163',12,'673aefad16724aa994e9224b37780ca0','volumes',-1,'2019-12-27 10:10:39',NULL),('2019-12-26 10:10:39','2019-12-26 10:10:40','2019-12-26 10:10:40',1,612,'1c80293f-2180-4925-a54e-b802ae0fd6c7',3,'673aefad16724aa994e9224b37780ca0','gigabytes',-40,'2019-12-27 10:10:39',NULL),('2019-12-26 10:10:39','2019-12-26 10:10:40','2019-12-26 10:10:40',1,615,'a9fd10cf-c4b4-4562-a202-5cf25d5b1c33',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',-40,'2019-12-27 10:10:39',NULL),('2019-12-26 10:10:39','2019-12-26 10:10:40','2019-12-26 10:10:40',1,618,'a46c0507-ca5d-4987-bc26-fa997510e322',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',-1,'2019-12-27 10:10:39',NULL),('2019-12-26 10:10:39','2019-12-26 10:10:40','2019-12-26 10:10:40',1,621,'2e5decc5-93ac-4874-a4a8-1efafe8903f4',12,'673aefad16724aa994e9224b37780ca0','volumes',-1,'2019-12-27 10:10:39',NULL),('2019-12-26 10:10:39','2019-12-26 10:10:40','2019-12-26 10:10:40',1,624,'1edf4783-eeda-451f-8aa9-e2ee49db1cea',3,'673aefad16724aa994e9224b37780ca0','gigabytes',-40,'2019-12-27 10:10:39',NULL),('2019-12-26 10:10:40','2019-12-26 10:10:40','2019-12-26 10:10:40',1,627,'2c26d740-db56-4adf-a8e3-c0b728a2387f',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',-40,'2019-12-27 10:10:39',NULL),('2019-12-26 10:10:40','2019-12-26 10:10:40','2019-12-26 10:10:40',1,630,'496ce4b0-d43c-49bd-95ee-dabc62bb800e',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',-1,'2019-12-27 10:10:39',NULL),('2019-12-26 10:10:40','2019-12-26 10:10:40','2019-12-26 10:10:40',1,633,'ddccdd5a-4df8-44ba-ae56-a086c19886b6',12,'673aefad16724aa994e9224b37780ca0','volumes',-1,'2019-12-27 10:10:39',NULL),('2019-12-26 10:10:40','2019-12-26 10:10:40','2019-12-26 10:10:40',1,636,'7d539696-46b4-4e25-9361-d07d448d53f3',3,'673aefad16724aa994e9224b37780ca0','gigabytes',-40,'2019-12-27 10:10:39',NULL),('2019-12-26 10:10:40','2019-12-26 10:10:40','2019-12-26 10:10:40',1,639,'ca7e044e-64a0-42ec-9494-e888895f4bea',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',-40,'2019-12-27 10:10:39',NULL),('2019-12-26 10:10:40','2019-12-26 10:10:40','2019-12-26 10:10:40',1,642,'3e94357c-8b52-4dae-bae5-692def84461f',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',-1,'2019-12-27 10:10:39',NULL),('2019-12-26 10:10:40','2019-12-26 10:10:40','2019-12-26 10:10:40',1,645,'fe099f44-befb-4863-a276-56ad2deb1cd4',12,'673aefad16724aa994e9224b37780ca0','volumes',-1,'2019-12-27 10:10:39',NULL),('2019-12-26 10:10:40','2019-12-26 10:10:40','2019-12-26 10:10:40',1,648,'f5cc6301-f376-4f83-8d2c-93b50bcd1bdf',3,'673aefad16724aa994e9224b37780ca0','gigabytes',-40,'2019-12-27 10:10:40',NULL),('2019-12-26 10:10:40','2019-12-26 10:10:40','2019-12-26 10:10:40',1,651,'12b47243-2e27-4040-9420-1fcfc05e4996',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',-40,'2019-12-27 10:10:40',NULL),('2019-12-26 10:10:40','2019-12-26 10:10:40','2019-12-26 10:10:40',1,654,'443c4c8a-2c88-42c5-b091-227df7f5b64c',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',-1,'2019-12-27 10:10:40',NULL),('2019-12-26 10:10:40','2019-12-26 10:10:40','2019-12-26 10:10:40',1,657,'c117efbe-57aa-42e0-b019-52844ab53b9b',12,'673aefad16724aa994e9224b37780ca0','volumes',-1,'2019-12-27 10:10:40',NULL),('2019-12-27 02:29:37','2019-12-27 02:29:37','2019-12-27 02:29:37',1,658,'30d8fbfb-3e52-4b20-ab0e-506d12f4e3e3',3,'673aefad16724aa994e9224b37780ca0','gigabytes',-40,'2019-12-28 02:29:37',NULL),('2019-12-27 02:29:37','2019-12-27 02:29:37','2019-12-27 02:29:37',1,661,'2b750cad-a6c9-4522-96f1-16d6464c8b37',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',-40,'2019-12-28 02:29:37',NULL),('2019-12-27 02:29:37','2019-12-27 02:29:37','2019-12-27 02:29:37',1,664,'62770851-b9d1-4636-b615-08446f20fac7',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',-1,'2019-12-28 02:29:37',NULL),('2019-12-27 02:29:37','2019-12-27 02:29:37','2019-12-27 02:29:37',1,667,'0731e31f-de66-48f0-879b-d0b20e28f4a1',12,'673aefad16724aa994e9224b37780ca0','volumes',-1,'2019-12-28 02:29:37',NULL),('2019-12-27 08:27:11','2019-12-27 08:27:11','2019-12-27 08:27:11',1,670,'fa2593af-a0b6-4224-9667-c592e0128ad6',3,'673aefad16724aa994e9224b37780ca0','gigabytes',40,'2019-12-28 08:27:11',NULL),('2019-12-27 08:27:11','2019-12-27 08:27:11','2019-12-27 08:27:11',1,673,'e0f003e8-9bcf-4fe5-b237-ff654d5f9860',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',40,'2019-12-28 08:27:11',NULL),('2019-12-27 08:27:11','2019-12-27 08:27:11','2019-12-27 08:27:11',1,676,'cd9d9d36-c746-43db-acdd-c29d40cf21b1',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-28 08:27:11',NULL),('2019-12-27 08:27:11','2019-12-27 08:27:11','2019-12-27 08:27:11',1,679,'8a74a1bd-60f0-4140-b647-1aa90e71d0a5',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-28 08:27:11',NULL),('2019-12-27 08:27:11','2019-12-27 08:27:11','2019-12-27 08:27:11',1,682,'7cd04597-4d09-4397-ae79-5d32bcd94466',3,'673aefad16724aa994e9224b37780ca0','gigabytes',40,'2019-12-28 08:27:11',NULL),('2019-12-27 08:27:11','2019-12-27 08:27:11','2019-12-27 08:27:11',1,685,'8ef4950e-3048-418a-83e0-4178aa9016df',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',40,'2019-12-28 08:27:11',NULL),('2019-12-27 08:27:11','2019-12-27 08:27:11','2019-12-27 08:27:11',1,688,'c46a5c7b-8cca-4dc3-b0e7-0111bb647776',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-28 08:27:11',NULL),('2019-12-27 08:27:11','2019-12-27 08:27:11','2019-12-27 08:27:11',1,691,'7813f052-fb99-4ef1-b74f-278fd06e38fc',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-28 08:27:11',NULL),('2019-12-27 08:27:11','2019-12-27 08:27:11','2019-12-27 08:27:11',1,694,'3c8fea47-eb36-466f-8c7b-f48c51561591',3,'673aefad16724aa994e9224b37780ca0','gigabytes',40,'2019-12-28 08:27:11',NULL),('2019-12-27 08:27:11','2019-12-27 08:27:11','2019-12-27 08:27:11',1,697,'fc6ae291-1c84-4721-a33f-93cf23f38d83',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',40,'2019-12-28 08:27:11',NULL),('2019-12-27 08:27:11','2019-12-27 08:27:11','2019-12-27 08:27:11',1,700,'d34b0ce9-af15-4f01-b8ac-f034f8ecf82e',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-28 08:27:11',NULL),('2019-12-27 08:27:11','2019-12-27 08:27:11','2019-12-27 08:27:11',1,703,'72f6b6a9-4b4a-4f0d-ad01-1f0aa34383e4',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-28 08:27:11',NULL),('2019-12-27 08:27:12','2019-12-27 08:27:12','2019-12-27 08:27:12',1,706,'a20e2963-756c-4650-bb0e-73f57e28583e',3,'673aefad16724aa994e9224b37780ca0','gigabytes',40,'2019-12-28 08:27:11',NULL),('2019-12-27 08:27:12','2019-12-27 08:27:12','2019-12-27 08:27:12',1,709,'8e3e3198-e6e2-4c75-8bcf-061077b2f544',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',40,'2019-12-28 08:27:11',NULL),('2019-12-27 08:27:12','2019-12-27 08:27:12','2019-12-27 08:27:12',1,712,'680a71c1-b7dc-4e8b-9971-aad00ad76fa6',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-28 08:27:11',NULL),('2019-12-27 08:27:12','2019-12-27 08:27:12','2019-12-27 08:27:12',1,715,'12b682b7-aa6d-4001-b4ec-47d50772bdcf',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-28 08:27:11',NULL),('2019-12-27 08:27:12','2019-12-27 08:27:12','2019-12-27 08:27:12',1,718,'43da81ce-e74e-4b9b-b989-63ad8b59d77e',3,'673aefad16724aa994e9224b37780ca0','gigabytes',40,'2019-12-28 08:27:12',NULL),('2019-12-27 08:27:12','2019-12-27 08:27:12','2019-12-27 08:27:12',1,721,'f8518247-f836-4f9d-bb0a-79a57896fe67',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',40,'2019-12-28 08:27:12',NULL),('2019-12-27 08:27:12','2019-12-27 08:27:12','2019-12-27 08:27:12',1,724,'ed0f0819-a85a-4e6b-ba9c-9e004c95197f',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-28 08:27:12',NULL),('2019-12-27 08:27:12','2019-12-27 08:27:12','2019-12-27 08:27:12',1,727,'1de2ca9a-b3f0-401c-bb89-71f98bacdb16',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-28 08:27:12',NULL),('2019-12-27 08:27:12','2019-12-27 08:27:13','2019-12-27 08:27:13',1,730,'6c4b4b6d-909a-40d6-89aa-dc152b879710',3,'673aefad16724aa994e9224b37780ca0','gigabytes',40,'2019-12-28 08:27:12',NULL),('2019-12-27 08:27:12','2019-12-27 08:27:13','2019-12-27 08:27:13',1,733,'28134589-fda8-44ea-a729-41e321c0d9dc',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',40,'2019-12-28 08:27:12',NULL),('2019-12-27 08:27:12','2019-12-27 08:27:13','2019-12-27 08:27:13',1,736,'627b01c9-78a2-429b-8f87-906b90db69d6',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-28 08:27:12',NULL),('2019-12-27 08:27:12','2019-12-27 08:27:13','2019-12-27 08:27:13',1,739,'8b8acd9c-ef21-430d-b8e4-1da38b2c5412',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-28 08:27:12',NULL),('2019-12-27 08:27:13','2019-12-27 08:27:14','2019-12-27 08:27:14',1,742,'ee11ebca-8d3d-4a8d-bd32-08eb1fdb1085',3,'673aefad16724aa994e9224b37780ca0','gigabytes',40,'2019-12-28 08:27:13',NULL),('2019-12-27 08:27:13','2019-12-27 08:27:14','2019-12-27 08:27:14',1,745,'66094ca9-b566-48bf-97e7-e22d67e84a68',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',40,'2019-12-28 08:27:13',NULL),('2019-12-27 08:27:13','2019-12-27 08:27:14','2019-12-27 08:27:14',1,748,'bf09fdd9-a581-4e4e-82f8-137385a99f21',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-28 08:27:13',NULL),('2019-12-27 08:27:13','2019-12-27 08:27:14','2019-12-27 08:27:14',1,751,'56058c10-1ea9-430c-a71d-8be3a8e14425',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-28 08:27:13',NULL),('2019-12-27 08:27:14','2019-12-27 08:27:14','2019-12-27 08:27:14',1,754,'7a4ce0e0-78f9-4eb9-bcef-8e3b2c7b5a46',3,'673aefad16724aa994e9224b37780ca0','gigabytes',40,'2019-12-28 08:27:13',NULL),('2019-12-27 08:27:14','2019-12-27 08:27:14','2019-12-27 08:27:14',1,757,'3ad45e08-3c28-49a2-b312-58ff07628b77',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',40,'2019-12-28 08:27:13',NULL),('2019-12-27 08:27:14','2019-12-27 08:27:14','2019-12-27 08:27:14',1,760,'eb22e3a3-9266-49e1-8cb9-663a51560bfb',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-28 08:27:13',NULL),('2019-12-27 08:27:14','2019-12-27 08:27:14','2019-12-27 08:27:14',1,763,'437f363c-5933-498a-8d12-9e0bdced2d50',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-28 08:27:13',NULL),('2019-12-27 08:27:14','2019-12-27 08:27:14','2019-12-27 08:27:14',1,766,'cb0f9eb2-113e-4dec-8b66-e4d4aad57cb7',3,'673aefad16724aa994e9224b37780ca0','gigabytes',40,'2019-12-28 08:27:14',NULL),('2019-12-27 08:27:14','2019-12-27 08:27:14','2019-12-27 08:27:14',1,769,'bcb3a927-a1c2-4409-8ba0-3afcb12133e4',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',40,'2019-12-28 08:27:14',NULL),('2019-12-27 08:27:14','2019-12-27 08:27:14','2019-12-27 08:27:14',1,772,'ab007083-2659-46a0-827d-788966663644',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-28 08:27:14',NULL),('2019-12-27 08:27:14','2019-12-27 08:27:14','2019-12-27 08:27:14',1,775,'ba2044bc-4b39-43e8-a051-b5735c4ce32b',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-28 08:27:14',NULL),('2019-12-27 08:27:14','2019-12-27 08:27:14','2019-12-27 08:27:14',1,778,'6e9c645b-4dc4-4c1b-ab68-baace6df184f',3,'673aefad16724aa994e9224b37780ca0','gigabytes',40,'2019-12-28 08:27:14',NULL),('2019-12-27 08:27:14','2019-12-27 08:27:15','2019-12-27 08:27:15',1,781,'7214e233-a7f5-439a-854a-b2d59bad13bd',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',40,'2019-12-28 08:27:14',NULL),('2019-12-27 08:27:14','2019-12-27 08:27:15','2019-12-27 08:27:15',1,784,'91bf8ced-cd79-4b57-994b-c63f7aa3a4a6',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-28 08:27:14',NULL),('2019-12-27 08:27:14','2019-12-27 08:27:15','2019-12-27 08:27:15',1,787,'a085dafd-4980-4045-a627-752261ea5906',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-28 08:27:14',NULL),('2019-12-27 08:36:19','2019-12-27 08:36:19','2019-12-27 08:36:19',1,790,'3feaa007-6895-46fb-8ce7-1e1d8ea12e08',3,'673aefad16724aa994e9224b37780ca0','gigabytes',-40,'2019-12-28 08:36:18',NULL),('2019-12-27 08:36:19','2019-12-27 08:36:19','2019-12-27 08:36:19',1,793,'343f68dd-0578-4fcf-a030-32f77a3cba67',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',-40,'2019-12-28 08:36:18',NULL),('2019-12-27 08:36:19','2019-12-27 08:36:19','2019-12-27 08:36:19',1,796,'5cfe9295-0ee6-4dab-bc7f-5f3808740744',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',-1,'2019-12-28 08:36:18',NULL),('2019-12-27 08:36:19','2019-12-27 08:36:19','2019-12-27 08:36:19',1,799,'714548bf-d2ea-4af2-b794-bd42a18ba907',12,'673aefad16724aa994e9224b37780ca0','volumes',-1,'2019-12-28 08:36:18',NULL),('2019-12-27 08:36:19','2019-12-27 08:36:19','2019-12-27 08:36:19',1,802,'8c6ada4c-092b-48de-9a02-44dc01b249ff',3,'673aefad16724aa994e9224b37780ca0','gigabytes',-40,'2019-12-28 08:36:19',NULL),('2019-12-27 08:36:19','2019-12-27 08:36:19','2019-12-27 08:36:19',1,805,'998f684c-3e16-479f-a12b-21ee8c8d40b0',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',-40,'2019-12-28 08:36:19',NULL),('2019-12-27 08:36:19','2019-12-27 08:36:19','2019-12-27 08:36:19',1,808,'ab9fb8ad-8d53-46fa-ac6c-fb97028a348d',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',-1,'2019-12-28 08:36:19',NULL),('2019-12-27 08:36:19','2019-12-27 08:36:19','2019-12-27 08:36:19',1,811,'6cd70af5-ccdd-4690-9768-85030a7e5377',12,'673aefad16724aa994e9224b37780ca0','volumes',-1,'2019-12-28 08:36:19',NULL),('2019-12-27 08:36:19','2019-12-27 08:36:19','2019-12-27 08:36:19',1,814,'fbb367e9-5a8d-46a0-a9f7-ea792c76a8e0',3,'673aefad16724aa994e9224b37780ca0','gigabytes',-40,'2019-12-28 08:36:19',NULL),('2019-12-27 08:36:19','2019-12-27 08:36:19','2019-12-27 08:36:19',1,817,'f6bd64d6-7f58-4f03-930a-447b474e47e3',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',-40,'2019-12-28 08:36:19',NULL),('2019-12-27 08:36:19','2019-12-27 08:36:19','2019-12-27 08:36:19',1,820,'5f1ef4a3-ef3a-4bfb-b240-b6fee2d3ecf0',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',-1,'2019-12-28 08:36:19',NULL),('2019-12-27 08:36:19','2019-12-27 08:36:19','2019-12-27 08:36:19',1,823,'ca1a9933-dc77-4050-8b22-b37da5213130',12,'673aefad16724aa994e9224b37780ca0','volumes',-1,'2019-12-28 08:36:19',NULL),('2019-12-27 08:36:19','2019-12-27 08:36:19','2019-12-27 08:36:19',1,826,'13a40fa3-9a2f-41e2-aff3-6dd052ba976b',3,'673aefad16724aa994e9224b37780ca0','gigabytes',-40,'2019-12-28 08:36:19',NULL),('2019-12-27 08:36:19','2019-12-27 08:36:19','2019-12-27 08:36:19',1,829,'739f8ef0-0116-43b5-ae27-df9ed6551df6',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',-40,'2019-12-28 08:36:19',NULL),('2019-12-27 08:36:19','2019-12-27 08:36:19','2019-12-27 08:36:19',1,832,'5c513c04-7ca6-4a45-8165-7c428167b883',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',-1,'2019-12-28 08:36:19',NULL),('2019-12-27 08:36:19','2019-12-27 08:36:19','2019-12-27 08:36:19',1,835,'a6769dfd-2c12-4d69-bd13-bf4d41dc7b21',12,'673aefad16724aa994e9224b37780ca0','volumes',-1,'2019-12-28 08:36:19',NULL),('2019-12-27 08:36:19','2019-12-27 08:36:19','2019-12-27 08:36:19',1,838,'91168569-7e52-4aac-934d-13d0dceaf65a',3,'673aefad16724aa994e9224b37780ca0','gigabytes',-40,'2019-12-28 08:36:19',NULL),('2019-12-27 08:36:19','2019-12-27 08:36:19','2019-12-27 08:36:19',1,841,'9faf53e1-4d04-487d-8fe9-085b59e3ea5c',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',-40,'2019-12-28 08:36:19',NULL),('2019-12-27 08:36:19','2019-12-27 08:36:19','2019-12-27 08:36:19',1,844,'f1a5c3af-ca6a-4dee-a786-991cbf609e01',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',-1,'2019-12-28 08:36:19',NULL),('2019-12-27 08:36:19','2019-12-27 08:36:19','2019-12-27 08:36:19',1,847,'4005aa3a-0173-4c36-805d-b330fed7d5c3',12,'673aefad16724aa994e9224b37780ca0','volumes',-1,'2019-12-28 08:36:19',NULL),('2019-12-27 08:36:19','2019-12-27 08:36:19','2019-12-27 08:36:19',1,850,'10835fd1-c304-42de-8660-98d2ad2aa266',3,'673aefad16724aa994e9224b37780ca0','gigabytes',-40,'2019-12-28 08:36:19',NULL),('2019-12-27 08:36:19','2019-12-27 08:36:19','2019-12-27 08:36:19',1,853,'0fbed6bc-9ab7-4ec2-b34f-3a27b08fa46e',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',-40,'2019-12-28 08:36:19',NULL),('2019-12-27 08:36:19','2019-12-27 08:36:19','2019-12-27 08:36:19',1,856,'2d62e34e-4223-4803-875c-2580815de1e4',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',-1,'2019-12-28 08:36:19',NULL),('2019-12-27 08:36:19','2019-12-27 08:36:19','2019-12-27 08:36:19',1,859,'603da992-96e6-44e0-bf1b-1f97e9ee63ff',12,'673aefad16724aa994e9224b37780ca0','volumes',-1,'2019-12-28 08:36:19',NULL),('2019-12-27 08:36:19','2019-12-27 08:36:19','2019-12-27 08:36:19',1,862,'0ce3af1d-ab9e-4532-b0c3-a576b0db6c50',3,'673aefad16724aa994e9224b37780ca0','gigabytes',-40,'2019-12-28 08:36:19',NULL),('2019-12-27 08:36:19','2019-12-27 08:36:19','2019-12-27 08:36:19',1,865,'1b2d6904-9c02-4293-8b2e-ecc7a108d838',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',-40,'2019-12-28 08:36:19',NULL),('2019-12-27 08:36:19','2019-12-27 08:36:19','2019-12-27 08:36:19',1,868,'ada8ec4d-8b1d-43ce-b5f9-358c01c32b7a',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',-1,'2019-12-28 08:36:19',NULL),('2019-12-27 08:36:19','2019-12-27 08:36:19','2019-12-27 08:36:19',1,871,'00abbf84-0b27-4f8a-89cf-d0f2e25efb7c',12,'673aefad16724aa994e9224b37780ca0','volumes',-1,'2019-12-28 08:36:19',NULL),('2019-12-27 08:36:19','2019-12-27 08:36:19','2019-12-27 08:36:19',1,874,'96643752-bfa4-41ad-93d7-6496142c2238',3,'673aefad16724aa994e9224b37780ca0','gigabytes',-40,'2019-12-28 08:36:19',NULL),('2019-12-27 08:36:19','2019-12-27 08:36:19','2019-12-27 08:36:19',1,877,'7d632834-86a1-448f-bb15-a1d4d1ca5402',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',-40,'2019-12-28 08:36:19',NULL),('2019-12-27 08:36:19','2019-12-27 08:36:19','2019-12-27 08:36:19',1,880,'17542369-0d52-44da-8ede-2f032835a82f',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',-1,'2019-12-28 08:36:19',NULL),('2019-12-27 08:36:19','2019-12-27 08:36:19','2019-12-27 08:36:19',1,883,'7acd715b-3f53-41d3-b47f-552245db843a',12,'673aefad16724aa994e9224b37780ca0','volumes',-1,'2019-12-28 08:36:19',NULL),('2019-12-27 08:36:20','2019-12-27 08:36:20','2019-12-27 08:36:20',1,886,'a1b9c5d6-d2f2-4125-9cb1-36f9a58e72c0',3,'673aefad16724aa994e9224b37780ca0','gigabytes',-40,'2019-12-28 08:36:19',NULL),('2019-12-27 08:36:20','2019-12-27 08:36:20','2019-12-27 08:36:20',1,889,'bac31db0-defa-4dc3-97a7-8e76b105f2e0',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',-40,'2019-12-28 08:36:19',NULL),('2019-12-27 08:36:20','2019-12-27 08:36:20','2019-12-27 08:36:20',1,892,'9a8c5908-d445-4fa0-8eab-b252f93db744',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',-1,'2019-12-28 08:36:19',NULL),('2019-12-27 08:36:20','2019-12-27 08:36:20','2019-12-27 08:36:20',1,895,'81c49e6e-2016-4b72-8d16-bbcc21e68c23',12,'673aefad16724aa994e9224b37780ca0','volumes',-1,'2019-12-28 08:36:19',NULL),('2019-12-27 08:36:20','2019-12-27 08:36:20','2019-12-27 08:36:20',1,898,'4a7777ca-f7fe-4745-9390-a57d40e948f4',3,'673aefad16724aa994e9224b37780ca0','gigabytes',-40,'2019-12-28 08:36:20',NULL),('2019-12-27 08:36:20','2019-12-27 08:36:20','2019-12-27 08:36:20',1,901,'abcfd4cb-092f-4420-adb6-f32cf19ba7aa',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',-40,'2019-12-28 08:36:20',NULL),('2019-12-27 08:36:20','2019-12-27 08:36:20','2019-12-27 08:36:20',1,904,'0c2f1010-59a5-43cc-b55f-98e38f2149a2',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',-1,'2019-12-28 08:36:20',NULL),('2019-12-27 08:36:20','2019-12-27 08:36:20','2019-12-27 08:36:20',1,907,'1a137e15-707e-4c12-9e2c-2189599ff512',12,'673aefad16724aa994e9224b37780ca0','volumes',-1,'2019-12-28 08:36:20',NULL),('2019-12-27 08:53:27','2019-12-27 08:53:27','2019-12-27 08:53:27',1,910,'d3814d0c-ee9c-4cfd-a73c-d2a32cf7bbed',3,'673aefad16724aa994e9224b37780ca0','gigabytes',40,'2019-12-28 08:53:27',NULL),('2019-12-27 08:53:27','2019-12-27 08:53:27','2019-12-27 08:53:27',1,913,'0eb021a0-0c1b-4f5d-8f02-ee3cddefd824',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',40,'2019-12-28 08:53:27',NULL),('2019-12-27 08:53:27','2019-12-27 08:53:27','2019-12-27 08:53:27',1,916,'b373be59-a238-4506-bb89-f2609bdb7137',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-28 08:53:27',NULL),('2019-12-27 08:53:27','2019-12-27 08:53:27','2019-12-27 08:53:27',1,919,'24fc8ada-3ec4-4c67-97c4-8910bafff731',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-28 08:53:27',NULL),('2019-12-27 08:53:27','2019-12-27 08:53:27','2019-12-27 08:53:27',1,922,'90e52c6e-b378-4d66-830d-5b5868cb3163',3,'673aefad16724aa994e9224b37780ca0','gigabytes',40,'2019-12-28 08:53:27',NULL),('2019-12-27 08:53:27','2019-12-27 08:53:27','2019-12-27 08:53:27',1,925,'e2967a6a-8186-4cd0-9ca3-5df28d8aa146',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',40,'2019-12-28 08:53:27',NULL),('2019-12-27 08:53:27','2019-12-27 08:53:27','2019-12-27 08:53:27',1,928,'8b988106-69c5-4346-a868-a1376bbaeff1',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-28 08:53:27',NULL),('2019-12-27 08:53:27','2019-12-27 08:53:27','2019-12-27 08:53:27',1,931,'21629bc0-ccb8-4cec-91c6-b785bbef4200',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-28 08:53:27',NULL),('2019-12-27 08:53:27','2019-12-27 08:53:28','2019-12-27 08:53:28',1,934,'da85201e-430a-4a07-b964-6e4bcea49651',3,'673aefad16724aa994e9224b37780ca0','gigabytes',40,'2019-12-28 08:53:27',NULL),('2019-12-27 08:53:27','2019-12-27 08:53:28','2019-12-27 08:53:28',1,937,'0b9fc388-19de-43fe-b1d2-3d7363fe3897',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',40,'2019-12-28 08:53:27',NULL),('2019-12-27 08:53:27','2019-12-27 08:53:28','2019-12-27 08:53:28',1,940,'58153500-b34f-4e9a-a9cf-f5ad1509f0d6',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-28 08:53:27',NULL),('2019-12-27 08:53:27','2019-12-27 08:53:28','2019-12-27 08:53:28',1,943,'d9e49b8a-1239-4190-a921-1e51f1303d85',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-28 08:53:27',NULL),('2019-12-27 08:53:28','2019-12-27 08:53:28','2019-12-27 08:53:28',1,946,'02963427-8f84-4097-a81a-64c19bb08dc6',3,'673aefad16724aa994e9224b37780ca0','gigabytes',40,'2019-12-28 08:53:28',NULL),('2019-12-27 08:53:28','2019-12-27 08:53:28','2019-12-27 08:53:28',1,949,'12a937ea-dec7-4dbc-8c11-0cefd2a1c8c3',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',40,'2019-12-28 08:53:28',NULL),('2019-12-27 08:53:28','2019-12-27 08:53:28','2019-12-27 08:53:28',1,952,'a67ee61e-bc21-4830-b5dd-d36fd143939a',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-28 08:53:28',NULL),('2019-12-27 08:53:28','2019-12-27 08:53:28','2019-12-27 08:53:28',1,955,'8883ed14-490a-4f5b-8283-e6290eb455f9',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-28 08:53:28',NULL),('2019-12-27 08:53:28','2019-12-27 08:53:28','2019-12-27 08:53:28',1,958,'4947ca87-990d-4cc1-8772-4bd4b9a16d07',3,'673aefad16724aa994e9224b37780ca0','gigabytes',40,'2019-12-28 08:53:28',NULL),('2019-12-27 08:53:28','2019-12-27 08:53:28','2019-12-27 08:53:28',1,961,'47dcee3b-d5b3-41e2-a035-f6925def0d40',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',40,'2019-12-28 08:53:28',NULL),('2019-12-27 08:53:28','2019-12-27 08:53:28','2019-12-27 08:53:28',1,964,'9761ed49-d651-48cf-9373-8532bf0524ee',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-28 08:53:28',NULL),('2019-12-27 08:53:28','2019-12-27 08:53:28','2019-12-27 08:53:28',1,967,'aa89e651-63d2-43a5-ad2c-eba57f93071f',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-28 08:53:28',NULL),('2019-12-27 08:53:28','2019-12-27 08:53:29','2019-12-27 08:53:29',1,970,'08d822c6-2cf6-413f-9f7f-e420c9b4f2de',3,'673aefad16724aa994e9224b37780ca0','gigabytes',40,'2019-12-28 08:53:28',NULL),('2019-12-27 08:53:28','2019-12-27 08:53:29','2019-12-27 08:53:29',1,973,'b0fa8775-4ddd-4703-a7ef-866f16646a2d',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',40,'2019-12-28 08:53:28',NULL),('2019-12-27 08:53:28','2019-12-27 08:53:29','2019-12-27 08:53:29',1,976,'06a44eda-8c16-4420-ab63-3d1106f37acc',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-28 08:53:28',NULL),('2019-12-27 08:53:28','2019-12-27 08:53:29','2019-12-27 08:53:29',1,979,'09e59dc0-302c-444e-971f-a0ba343c7628',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-28 08:53:28',NULL),('2019-12-27 08:53:29','2019-12-27 08:53:29','2019-12-27 08:53:29',1,982,'b27125b6-af74-48e3-b26b-7ff0a7b6d58d',3,'673aefad16724aa994e9224b37780ca0','gigabytes',40,'2019-12-28 08:53:29',NULL),('2019-12-27 08:53:29','2019-12-27 08:53:29','2019-12-27 08:53:29',1,985,'b079c1b9-1678-4345-90d4-058322654b13',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',40,'2019-12-28 08:53:29',NULL),('2019-12-27 08:53:29','2019-12-27 08:53:29','2019-12-27 08:53:29',1,988,'401fb9ed-bfbc-4f52-b4c0-be3c4b7d7dd1',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-28 08:53:29',NULL),('2019-12-27 08:53:29','2019-12-27 08:53:29','2019-12-27 08:53:29',1,991,'476cefbc-47e7-4506-b39f-c3d32c250691',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-28 08:53:29',NULL),('2019-12-27 08:53:29','2019-12-27 08:53:30','2019-12-27 08:53:30',1,994,'cfaa1285-b269-4509-9370-04a67fbb7ef7',3,'673aefad16724aa994e9224b37780ca0','gigabytes',40,'2019-12-28 08:53:29',NULL),('2019-12-27 08:53:29','2019-12-27 08:53:30','2019-12-27 08:53:30',1,997,'8f8d1278-9ada-4452-b0e8-f41caad1be3e',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',40,'2019-12-28 08:53:29',NULL),('2019-12-27 08:53:30','2019-12-27 08:53:30','2019-12-27 08:53:30',1,1000,'7f2725f7-bf9e-4451-b183-0bf2a3902f86',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-28 08:53:29',NULL),('2019-12-27 08:53:30','2019-12-27 08:53:30','2019-12-27 08:53:30',1,1003,'27bb3518-aadb-40e7-bdb5-59f09be3c6df',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-28 08:53:29',NULL),('2019-12-27 08:53:30','2019-12-27 08:53:30','2019-12-27 08:53:30',1,1006,'813c56b8-02ef-4223-b573-2cd720de1f28',3,'673aefad16724aa994e9224b37780ca0','gigabytes',40,'2019-12-28 08:53:30',NULL),('2019-12-27 08:53:30','2019-12-27 08:53:30','2019-12-27 08:53:30',1,1009,'eff1889b-5564-4ed0-99bf-4eff6323a73c',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',40,'2019-12-28 08:53:30',NULL),('2019-12-27 08:53:30','2019-12-27 08:53:30','2019-12-27 08:53:30',1,1012,'fd8d2244-4706-4327-b429-a14f120d27f4',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-28 08:53:30',NULL),('2019-12-27 08:53:30','2019-12-27 08:53:30','2019-12-27 08:53:30',1,1015,'ef146094-eda1-40c8-b3ef-c40b302b398d',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-28 08:53:30',NULL),('2019-12-27 08:53:30','2019-12-27 08:53:30','2019-12-27 08:53:30',1,1018,'8cc76136-4488-4cf3-a965-5beb9ff04b19',3,'673aefad16724aa994e9224b37780ca0','gigabytes',40,'2019-12-28 08:53:30',NULL),('2019-12-27 08:53:30','2019-12-27 08:53:30','2019-12-27 08:53:30',1,1021,'619d881b-504a-442c-83b4-8f3e3fdbec6d',6,'673aefad16724aa994e9224b37780ca0','gigabytes___DEFAULT__',40,'2019-12-28 08:53:30',NULL),('2019-12-27 08:53:30','2019-12-27 08:53:30','2019-12-27 08:53:30',1,1024,'47ef2423-408e-49d1-9395-7fcf728e380f',9,'673aefad16724aa994e9224b37780ca0','volumes___DEFAULT__',1,'2019-12-28 08:53:30',NULL),('2019-12-27 08:53:30','2019-12-27 08:53:30','2019-12-27 08:53:30',1,1027,'81c49264-84ae-4072-b8f1-4681ec0ef9a2',12,'673aefad16724aa994e9224b37780ca0','volumes',1,'2019-12-28 08:53:30',NULL);
/*!40000 ALTER TABLE `reservations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `services` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `host` varchar(255) DEFAULT NULL,
  `binary` varchar(255) DEFAULT NULL,
  `topic` varchar(255) DEFAULT NULL,
  `report_count` int(11) NOT NULL,
  `disabled` tinyint(1) DEFAULT NULL,
  `availability_zone` varchar(255) DEFAULT NULL,
  `disabled_reason` varchar(255) DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `rpc_current_version` varchar(36) DEFAULT NULL,
  `object_current_version` varchar(36) DEFAULT NULL,
  `replication_status` varchar(36) DEFAULT NULL,
  `frozen` tinyint(1) DEFAULT NULL,
  `active_backend_id` varchar(255) DEFAULT NULL,
  `cluster_name` varchar(255) DEFAULT NULL,
  `uuid` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `services_uuid_idx` (`uuid`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`deleted` in (0,1)),
  CONSTRAINT `CONSTRAINT_2` CHECK (`disabled` in (0,1)),
  CONSTRAINT `CONSTRAINT_3` CHECK (`frozen` in (0,1))
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services`
--

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
INSERT INTO `services` VALUES ('2019-12-04 03:56:31','2019-12-29 17:00:00',NULL,0,1,'controller01','cinder-scheduler','cinder-scheduler',201194,0,'nova',NULL,NULL,'3.11','1.38','not-capable',0,NULL,NULL,'32608768-d6fb-427c-8cf6-d3a9fd12e8a1'),('2019-12-04 03:56:34','2019-12-29 17:00:01',NULL,0,4,'controller02','cinder-scheduler','cinder-scheduler',201385,0,'nova',NULL,NULL,'3.11','1.38','not-capable',0,NULL,NULL,'cf06c0d9-5007-40e7-b89d-0c8f70a051bb'),('2019-12-04 03:56:36','2019-12-29 16:59:59',NULL,0,7,'controller03','cinder-scheduler','cinder-scheduler',201403,0,'nova',NULL,NULL,'3.11','1.38','not-capable',0,NULL,NULL,'fd37d333-80a3-4d2d-9901-21ab87228960'),('2019-12-06 16:00:39','2019-12-29 16:59:57',NULL,0,9,'controller01@ceph','cinder-volume','cinder-volume',180280,0,'nova',NULL,NULL,'3.16','1.38','disabled',0,NULL,NULL,'cf1d8b24-363c-4865-9ff2-c45c718ecc1c'),('2019-12-06 16:02:17','2019-12-29 16:59:59',NULL,0,12,'controller02@ceph','cinder-volume','cinder-volume',180005,0,'nova',NULL,NULL,'3.16','1.38','disabled',0,NULL,NULL,'4c273a2c-2ab7-49f4-bfb1-43d437efef31'),('2019-12-06 16:03:16','2019-12-29 16:59:59',NULL,0,15,'controller03@ceph','cinder-volume','cinder-volume',180000,0,'nova',NULL,NULL,'3.16','1.38','disabled',0,NULL,NULL,'de32308f-bc2b-41f2-9819-2bd248f2c02d');
/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `snapshot_metadata`
--

DROP TABLE IF EXISTS `snapshot_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `snapshot_metadata` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `snapshot_id` varchar(36) NOT NULL,
  `key` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_snapshot_metadata_snapshot_id` (`snapshot_id`),
  CONSTRAINT `snapshot_metadata_ibfk_1` FOREIGN KEY (`snapshot_id`) REFERENCES `snapshots` (`id`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`deleted` in (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `snapshot_metadata`
--

LOCK TABLES `snapshot_metadata` WRITE;
/*!40000 ALTER TABLE `snapshot_metadata` DISABLE KEYS */;
/*!40000 ALTER TABLE `snapshot_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `snapshots`
--

DROP TABLE IF EXISTS `snapshots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `snapshots` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `id` varchar(36) NOT NULL,
  `volume_id` varchar(36) NOT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `progress` varchar(255) DEFAULT NULL,
  `volume_size` int(11) DEFAULT NULL,
  `scheduled_at` datetime DEFAULT NULL,
  `display_name` varchar(255) DEFAULT NULL,
  `display_description` varchar(255) DEFAULT NULL,
  `provider_location` varchar(255) DEFAULT NULL,
  `encryption_key_id` varchar(36) DEFAULT NULL,
  `volume_type_id` varchar(36) DEFAULT NULL,
  `cgsnapshot_id` varchar(36) DEFAULT NULL,
  `provider_id` varchar(255) DEFAULT NULL,
  `provider_auth` varchar(255) DEFAULT NULL,
  `group_snapshot_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_snapshots_volume_id` (`volume_id`),
  KEY `ix_snapshots_group_snapshot_id` (`group_snapshot_id`),
  KEY `ix_snapshots_cgsnapshot_id` (`cgsnapshot_id`),
  CONSTRAINT `snapshots_ibfk_1` FOREIGN KEY (`cgsnapshot_id`) REFERENCES `cgsnapshots` (`id`),
  CONSTRAINT `snapshots_ibfk_2` FOREIGN KEY (`group_snapshot_id`) REFERENCES `group_snapshots` (`id`),
  CONSTRAINT `snapshots_volume_id_fkey` FOREIGN KEY (`volume_id`) REFERENCES `volumes` (`id`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`deleted` in (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `snapshots`
--

LOCK TABLES `snapshots` WRITE;
/*!40000 ALTER TABLE `snapshots` DISABLE KEYS */;
INSERT INTO `snapshots` VALUES ('2019-12-09 11:48:04','2019-12-27 10:17:59','2019-12-27 10:17:59',1,'448f7249-82f8-48b6-8f6b-d2496a1b1fd8','b62ce1aa-5172-4b58-bb12-c0d99ee0d7f0','871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','deleted','100%',2,NULL,'snap_vol_inst1','',NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,NULL,NULL,NULL),('2019-12-25 03:01:59','2019-12-27 10:16:45','2019-12-27 10:16:45',1,'a37e1787-05f1-4d9a-b8d3-09f1db015f14','3f96d033-5734-467b-9777-7d85f80933b7','871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','deleted','100%',40,NULL,'snap-base-centos','',NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `snapshots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transfers`
--

DROP TABLE IF EXISTS `transfers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transfers` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `id` varchar(36) NOT NULL,
  `volume_id` varchar(36) NOT NULL,
  `display_name` varchar(255) DEFAULT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `crypt_hash` varchar(255) DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `no_snapshots` tinyint(1) DEFAULT NULL,
  `source_project_id` varchar(255) DEFAULT NULL,
  `destination_project_id` varchar(255) DEFAULT NULL,
  `accepted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_transfers_volume_id` (`volume_id`),
  CONSTRAINT `transfers_ibfk_1` FOREIGN KEY (`volume_id`) REFERENCES `volumes` (`id`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`deleted` in (0,1)),
  CONSTRAINT `CONSTRAINT_2` CHECK (`no_snapshots` in (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transfers`
--

LOCK TABLES `transfers` WRITE;
/*!40000 ALTER TABLE `transfers` DISABLE KEYS */;
/*!40000 ALTER TABLE `transfers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volume_admin_metadata`
--

DROP TABLE IF EXISTS `volume_admin_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volume_admin_metadata` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `volume_id` varchar(36) NOT NULL,
  `key` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_volume_admin_metadata_volume_id` (`volume_id`),
  CONSTRAINT `volume_admin_metadata_ibfk_1` FOREIGN KEY (`volume_id`) REFERENCES `volumes` (`id`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`deleted` in (0,1))
) ENGINE=InnoDB AUTO_INCREMENT=115 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volume_admin_metadata`
--

LOCK TABLES `volume_admin_metadata` WRITE;
/*!40000 ALTER TABLE `volume_admin_metadata` DISABLE KEYS */;
INSERT INTO `volume_admin_metadata` VALUES ('2019-12-06 16:20:55','2019-12-06 16:20:55','2019-12-06 16:20:55',1,3,'d2806e0b-a6f3-49eb-b805-f0c68963de1c','readonly','False'),('2019-12-06 16:20:55',NULL,'2019-12-25 03:23:09',1,6,'d2806e0b-a6f3-49eb-b805-f0c68963de1c','attached_mode','rw'),('2019-12-24 11:42:17','2019-12-24 11:42:17','2019-12-24 11:42:17',1,9,'62ffb3fe-1bb6-4837-af63-833641330dd1','readonly','False'),('2019-12-24 11:42:17',NULL,'2019-12-24 11:47:21',1,12,'62ffb3fe-1bb6-4837-af63-833641330dd1','attached_mode','rw'),('2019-12-24 11:47:27','2019-12-24 11:47:28','2019-12-24 11:47:28',1,15,'fae19897-e732-43fc-a73f-21f971de7173','readonly','False'),('2019-12-24 11:47:28',NULL,'2019-12-24 11:52:30',1,18,'fae19897-e732-43fc-a73f-21f971de7173','attached_mode','rw'),('2019-12-24 11:50:55','2019-12-24 11:50:55','2019-12-24 11:50:55',1,21,'93f9710f-3de5-4c26-bed3-4c827308c5ad','readonly','False'),('2019-12-24 11:50:55',NULL,'2019-12-24 11:55:58',1,24,'93f9710f-3de5-4c26-bed3-4c827308c5ad','attached_mode','rw'),('2019-12-24 11:55:04','2019-12-24 11:55:04','2019-12-24 11:55:04',1,27,'b225b36d-6434-4e89-b302-2de775754069','readonly','False'),('2019-12-24 11:55:04',NULL,'2019-12-25 03:23:10',1,30,'b225b36d-6434-4e89-b302-2de775754069','attached_mode','rw'),('2019-12-24 11:58:36','2019-12-24 11:58:36','2019-12-24 11:58:36',1,33,'2d26bdaa-b52f-4505-a4d8-b2074a5355d8','readonly','False'),('2019-12-24 11:58:36',NULL,'2019-12-25 03:23:08',1,36,'2d26bdaa-b52f-4505-a4d8-b2074a5355d8','attached_mode','rw'),('2019-12-24 11:59:54','2019-12-24 11:59:54','2019-12-24 11:59:54',1,39,'3f96d033-5734-467b-9777-7d85f80933b7','readonly','False'),('2019-12-24 11:59:54',NULL,'2019-12-25 07:12:44',1,42,'3f96d033-5734-467b-9777-7d85f80933b7','attached_mode','rw'),('2019-12-25 07:22:38','2019-12-25 07:22:38','2019-12-25 07:22:38',1,45,'01aea4a1-b0c5-41fb-b184-2b1d9e8d1a18','readonly','False'),('2019-12-25 07:22:38',NULL,'2019-12-25 09:52:34',1,48,'01aea4a1-b0c5-41fb-b184-2b1d9e8d1a18','attached_mode','rw'),('2019-12-26 03:32:17','2019-12-26 03:32:17','2019-12-26 03:32:17',1,51,'55976623-d1fe-4370-8aa5-7e6d9234fffa','readonly','False'),('2019-12-26 03:32:17',NULL,'2019-12-27 02:24:08',1,54,'55976623-d1fe-4370-8aa5-7e6d9234fffa','attached_mode','rw'),('2019-12-27 09:01:03','2019-12-27 09:01:04','2019-12-27 09:01:04',1,55,'f76a0505-f942-4cd4-82ce-6cef82279616','readonly','False'),('2019-12-27 09:01:03','2019-12-27 09:01:04','2019-12-27 09:01:04',1,58,'e3e4ebfd-4da1-4c1f-b79f-6071a02816ef','readonly','False'),('2019-12-27 09:01:04',NULL,NULL,0,61,'e3e4ebfd-4da1-4c1f-b79f-6071a02816ef','attached_mode','rw'),('2019-12-27 09:01:04',NULL,NULL,0,64,'f76a0505-f942-4cd4-82ce-6cef82279616','attached_mode','rw'),('2019-12-27 09:01:05','2019-12-27 09:01:06','2019-12-27 09:01:06',1,67,'9396d79a-4a8e-45f9-907d-b30ba6299c5f','readonly','False'),('2019-12-27 09:01:06',NULL,NULL,0,70,'9396d79a-4a8e-45f9-907d-b30ba6299c5f','attached_mode','rw'),('2019-12-27 09:01:06','2019-12-27 09:01:07','2019-12-27 09:01:07',1,73,'8be45146-a7e7-4d43-b368-b8c18e6fcbbb','readonly','False'),('2019-12-27 09:01:06','2019-12-27 09:01:07','2019-12-27 09:01:07',1,76,'418ef8f2-c31f-4b9f-a570-98679812e5bf','readonly','False'),('2019-12-27 09:01:07',NULL,NULL,0,79,'8be45146-a7e7-4d43-b368-b8c18e6fcbbb','attached_mode','rw'),('2019-12-27 09:01:07',NULL,NULL,0,82,'418ef8f2-c31f-4b9f-a570-98679812e5bf','attached_mode','rw'),('2019-12-27 09:01:09','2019-12-27 09:01:09','2019-12-27 09:01:09',1,85,'2dc173b4-996c-4f66-b221-1dcfacd10f3d','readonly','False'),('2019-12-27 09:01:09',NULL,NULL,0,88,'2dc173b4-996c-4f66-b221-1dcfacd10f3d','attached_mode','rw'),('2019-12-27 09:01:45','2019-12-27 09:01:45','2019-12-27 09:01:45',1,91,'c9dbc7bb-c6c6-483a-80e9-6796f47f2f03','readonly','False'),('2019-12-27 09:01:45','2019-12-27 09:01:45','2019-12-27 09:01:45',1,94,'92365e82-3632-4469-b67d-69e6115c6944','readonly','False'),('2019-12-27 09:01:45',NULL,NULL,0,97,'c9dbc7bb-c6c6-483a-80e9-6796f47f2f03','attached_mode','rw'),('2019-12-27 09:01:45',NULL,NULL,0,100,'92365e82-3632-4469-b67d-69e6115c6944','attached_mode','rw'),('2019-12-27 09:01:46','2019-12-27 09:01:46','2019-12-27 09:01:46',1,103,'526de067-9664-459e-b973-f03990d85147','readonly','False'),('2019-12-27 09:01:46',NULL,NULL,0,106,'526de067-9664-459e-b973-f03990d85147','attached_mode','rw'),('2019-12-27 09:01:46','2019-12-27 09:01:46','2019-12-27 09:01:46',1,109,'625c33db-3326-456e-accc-080f46ebba5d','readonly','False'),('2019-12-27 09:01:46',NULL,NULL,0,112,'625c33db-3326-456e-accc-080f46ebba5d','attached_mode','rw');
/*!40000 ALTER TABLE `volume_admin_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volume_attachment`
--

DROP TABLE IF EXISTS `volume_attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volume_attachment` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `id` varchar(36) NOT NULL,
  `volume_id` varchar(36) NOT NULL,
  `attached_host` varchar(255) DEFAULT NULL,
  `instance_uuid` varchar(36) DEFAULT NULL,
  `mountpoint` varchar(255) DEFAULT NULL,
  `attach_time` datetime DEFAULT NULL,
  `detach_time` datetime DEFAULT NULL,
  `attach_mode` varchar(36) DEFAULT NULL,
  `attach_status` varchar(255) DEFAULT NULL,
  `connection_info` text DEFAULT NULL,
  `connector` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_volume_attachment_volume_id` (`volume_id`),
  CONSTRAINT `volume_attachment_ibfk_1` FOREIGN KEY (`volume_id`) REFERENCES `volumes` (`id`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`deleted` in (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volume_attachment`
--

LOCK TABLES `volume_attachment` WRITE;
/*!40000 ALTER TABLE `volume_attachment` DISABLE KEYS */;
INSERT INTO `volume_attachment` VALUES ('2019-12-24 11:47:28',NULL,'2019-12-24 11:52:30',1,'0a96326d-ffd9-4036-b4d5-6203750151e7','fae19897-e732-43fc-a73f-21f971de7173',NULL,'844f415c-5ff2-4dc0-aff5-1a5168f12a31','/dev/vda','2019-12-24 11:47:28','2019-12-24 11:52:30','rw','detached',NULL,NULL),('2019-12-24 11:55:04',NULL,'2019-12-25 03:23:09',1,'127bd626-b4f5-4c68-8b90-17f2064ea048','b225b36d-6434-4e89-b302-2de775754069',NULL,'eb53ce2e-f3ef-4804-8095-adb6bb8f1493','/dev/vda','2019-12-24 11:55:04','2019-12-25 03:23:09','rw','detached',NULL,NULL),('2019-12-06 16:20:55',NULL,'2019-12-25 03:23:09',1,'15546e5d-3c02-4743-b672-4891a6a5a778','d2806e0b-a6f3-49eb-b805-f0c68963de1c',NULL,'99c36ff4-4502-43a1-ba0b-71357522eca6','/dev/vda','2019-12-06 16:20:55','2019-12-25 03:23:09','rw','detached',NULL,NULL),('2019-12-27 09:01:45',NULL,NULL,0,'1dbf7254-5185-4473-a55d-c8ff8ab8e588','c9dbc7bb-c6c6-483a-80e9-6796f47f2f03',NULL,'987b866b-512e-4810-90a5-de5ee9d94a7f','/dev/vda','2019-12-27 09:01:45',NULL,'rw','attached',NULL,NULL),('2019-12-27 09:01:45',NULL,NULL,0,'2132dc6e-bb4d-491d-94a1-ee47a07e5303','92365e82-3632-4469-b67d-69e6115c6944',NULL,'baf667a5-3d32-4889-851a-fa9a9d473701','/dev/vda','2019-12-27 09:01:45',NULL,'rw','attached',NULL,NULL),('2019-12-27 09:01:07',NULL,NULL,0,'3330f2d7-a150-4e4d-82cc-28118c86b614','418ef8f2-c31f-4b9f-a570-98679812e5bf',NULL,'94892e98-598d-41a0-8ae0-276891a226ca','/dev/vda','2019-12-27 09:01:08',NULL,'rw','attached',NULL,NULL),('2019-12-27 09:01:46',NULL,NULL,0,'395829db-26ea-4435-80c0-2b3ac368fdfd','625c33db-3326-456e-accc-080f46ebba5d',NULL,'fcb34f44-6165-4286-92b3-3cad1750fd49','/dev/vda','2019-12-27 09:01:46',NULL,'rw','attached',NULL,NULL),('2019-12-27 09:01:04',NULL,NULL,0,'430f5be2-6bfa-42da-8e22-dd3b375928bf','e3e4ebfd-4da1-4c1f-b79f-6071a02816ef',NULL,'b1bdf716-3931-4d24-b091-d4fb83e2e10e','/dev/vda','2019-12-27 09:01:05',NULL,'rw','attached',NULL,NULL),('2019-12-24 11:58:36',NULL,'2019-12-25 03:23:08',1,'45b86472-8be4-4109-98e1-951828314d6d','2d26bdaa-b52f-4505-a4d8-b2074a5355d8',NULL,'111f8ba6-b261-4b4b-8c64-7b4e368047ca','/dev/vda','2019-12-24 11:58:36','2019-12-25 03:23:08','rw','detached',NULL,NULL),('2019-12-27 09:01:46',NULL,NULL,0,'61ff3730-1a39-45d4-b962-5f9aa9118b0e','526de067-9664-459e-b973-f03990d85147',NULL,'839bf8a7-ac89-4636-b17f-b8ae052c8320','/dev/vda','2019-12-27 09:01:46',NULL,'rw','attached',NULL,NULL),('2019-12-27 09:01:04',NULL,NULL,0,'6c112230-4881-4567-9516-19f14c9d3eef','f76a0505-f942-4cd4-82ce-6cef82279616',NULL,'7a558482-b098-4a50-8df2-fe60d9ac601b','/dev/vda','2019-12-27 09:01:05',NULL,'rw','attached',NULL,NULL),('2019-12-26 03:32:17',NULL,'2019-12-27 02:24:08',1,'7be6002f-dd26-498c-8ad2-3152d9d4153e','55976623-d1fe-4370-8aa5-7e6d9234fffa',NULL,'1efca57e-1383-4343-b77c-a9e9185279ef','/dev/vda','2019-12-26 03:32:17','2019-12-27 02:24:08','rw','detached',NULL,NULL),('2019-12-27 09:01:09',NULL,NULL,0,'7eb6fcff-43ee-464e-b927-460be65d7f17','2dc173b4-996c-4f66-b221-1dcfacd10f3d',NULL,'d96bfa5c-e59a-4f19-9906-f4ec9c7021f6','/dev/vda','2019-12-27 09:01:09',NULL,'rw','attached',NULL,NULL),('2019-12-24 11:42:17',NULL,'2019-12-24 11:47:21',1,'8d08fb12-c3b5-4a5d-85ff-77a08d89f4c3','62ffb3fe-1bb6-4837-af63-833641330dd1',NULL,'c1cd5248-38e7-490a-9bb5-cb50470d0584','/dev/vda','2019-12-24 11:42:17','2019-12-24 11:47:21','rw','detached',NULL,NULL),('2019-12-24 11:50:55',NULL,'2019-12-24 11:55:58',1,'8ebb9e9a-c878-43b3-9c41-7d9498d96356','93f9710f-3de5-4c26-bed3-4c827308c5ad',NULL,'4d5cf044-b875-4d62-8a56-875957e6cffd','/dev/vda','2019-12-24 11:50:55','2019-12-24 11:55:58','rw','detached',NULL,NULL),('2019-12-25 07:22:38',NULL,'2019-12-25 09:52:34',1,'91362d35-28c5-4f84-a059-36c81f4d5fa7','01aea4a1-b0c5-41fb-b184-2b1d9e8d1a18',NULL,'4758ed88-3fa2-4d2f-a241-5559b0ae5666','/dev/vda','2019-12-25 07:22:38','2019-12-25 09:52:34','rw','detached',NULL,NULL),('2019-12-24 11:59:54',NULL,'2019-12-25 07:12:44',1,'b3375b54-8e09-462e-bd6d-136dae2daaf4','3f96d033-5734-467b-9777-7d85f80933b7',NULL,'60ee1e8e-1ba8-4fef-aefd-783e4f7a1aec','/dev/vda','2019-12-24 11:59:54','2019-12-25 07:12:44','rw','detached',NULL,NULL),('2019-12-25 03:05:19','2019-12-25 03:05:24','2019-12-25 07:12:45',1,'c27c0041-5729-454a-a986-b7d58d40ce64','99afd14f-9028-4d77-bf9f-3c12ac9a1df2','compute02','20018ddd-3d53-4f2c-bbaa-5d3d2a312107','/dev/vda','2019-12-25 03:05:24','2019-12-25 07:12:45','rw','detached','{\"attachment_id\": \"c27c0041-5729-454a-a986-b7d58d40ce64\", \"encrypted\": false, \"driver_volume_type\": \"rbd\", \"secret_uuid\": \"5c778d4e-2d9a-4227-9d4f-cc1729c64b65\", \"qos_specs\": null, \"volume_id\": \"99afd14f-9028-4d77-bf9f-3c12ac9a1df2\", \"auth_username\": \"cinder\", \"secret_type\": \"ceph\", \"name\": \"volumes/volume-99afd14f-9028-4d77-bf9f-3c12ac9a1df2\", \"discard\": true, \"keyring\": null, \"cluster_name\": \"ceph\", \"auth_enabled\": true, \"hosts\": [\"192.168.100.41\", \"192.168.100.42\", \"192.168.100.43\"], \"access_mode\": \"rw\", \"ports\": [\"6789\", \"6789\", \"6789\"]}','{\"initiator\": \"iqn.1994-05.com.redhat:15f615db787b\", \"ip\": \"10.38.22.37\", \"system uuid\": \"30393137-3136-4753-4837-313956435457\", \"platform\": \"x86_64\", \"host\": \"compute02\", \"do_local_attach\": false, \"mountpoint\": \"/dev/vda\", \"os_type\": \"linux2\", \"multipath\": false}'),('2019-12-27 09:01:06',NULL,NULL,0,'c3d6599a-e3fc-40da-84f7-f13cdccaecba','8be45146-a7e7-4d43-b368-b8c18e6fcbbb',NULL,'94ede387-7fe3-4987-8c37-7cdcf590b364','/dev/vda','2019-12-27 09:01:07',NULL,'rw','attached',NULL,NULL),('2019-12-27 09:01:05',NULL,NULL,0,'c3eef45e-b674-4576-8a51-8330a0a89f55','9396d79a-4a8e-45f9-907d-b30ba6299c5f',NULL,'094646d6-faec-4ab0-abc3-98ae8f55d147','/dev/vda','2019-12-27 09:01:06',NULL,'rw','attached',NULL,NULL);
/*!40000 ALTER TABLE `volume_attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volume_glance_metadata`
--

DROP TABLE IF EXISTS `volume_glance_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volume_glance_metadata` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `volume_id` varchar(36) DEFAULT NULL,
  `snapshot_id` varchar(36) DEFAULT NULL,
  `key` varchar(255) DEFAULT NULL,
  `value` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_volume_glance_metadata_volume_id` (`volume_id`),
  KEY `ix_volume_glance_metadata_snapshot_id` (`snapshot_id`),
  CONSTRAINT `volume_glance_metadata_ibfk_1` FOREIGN KEY (`volume_id`) REFERENCES `volumes` (`id`),
  CONSTRAINT `volume_glance_metadata_ibfk_2` FOREIGN KEY (`snapshot_id`) REFERENCES `snapshots` (`id`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`deleted` in (0,1))
) ENGINE=InnoDB AUTO_INCREMENT=1087 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volume_glance_metadata`
--

LOCK TABLES `volume_glance_metadata` WRITE;
/*!40000 ALTER TABLE `volume_glance_metadata` DISABLE KEYS */;
INSERT INTO `volume_glance_metadata` VALUES ('2019-12-06 16:20:48',NULL,NULL,0,3,'d2806e0b-a6f3-49eb-b805-f0c68963de1c',NULL,'signature_verified','False'),('2019-12-06 16:20:51',NULL,NULL,0,6,'d2806e0b-a6f3-49eb-b805-f0c68963de1c',NULL,'container_format','bare'),('2019-12-06 16:20:51',NULL,NULL,0,9,'d2806e0b-a6f3-49eb-b805-f0c68963de1c',NULL,'min_ram','0'),('2019-12-06 16:20:51',NULL,NULL,0,12,'d2806e0b-a6f3-49eb-b805-f0c68963de1c',NULL,'disk_format','qcow2'),('2019-12-06 16:20:51',NULL,NULL,0,15,'d2806e0b-a6f3-49eb-b805-f0c68963de1c',NULL,'image_name','cirros'),('2019-12-06 16:20:51',NULL,NULL,0,18,'d2806e0b-a6f3-49eb-b805-f0c68963de1c',NULL,'image_id','5ee759d1-e9e3-4bda-a9c6-50bcfe5cc355'),('2019-12-06 16:20:51',NULL,NULL,0,21,'d2806e0b-a6f3-49eb-b805-f0c68963de1c',NULL,'checksum','443b7623e27ecf03dc9e01ee93f67afe'),('2019-12-06 16:20:51',NULL,NULL,0,24,'d2806e0b-a6f3-49eb-b805-f0c68963de1c',NULL,'min_disk','0'),('2019-12-06 16:20:51',NULL,NULL,0,27,'d2806e0b-a6f3-49eb-b805-f0c68963de1c',NULL,'size','12716032'),('2019-12-24 11:42:10',NULL,NULL,0,30,'62ffb3fe-1bb6-4837-af63-833641330dd1',NULL,'signature_verified','False'),('2019-12-24 11:42:13',NULL,NULL,0,33,'62ffb3fe-1bb6-4837-af63-833641330dd1',NULL,'container_format','bare'),('2019-12-24 11:42:13',NULL,NULL,0,36,'62ffb3fe-1bb6-4837-af63-833641330dd1',NULL,'min_ram','0'),('2019-12-24 11:42:13',NULL,NULL,0,39,'62ffb3fe-1bb6-4837-af63-833641330dd1',NULL,'disk_format','qcow2'),('2019-12-24 11:42:13',NULL,NULL,0,42,'62ffb3fe-1bb6-4837-af63-833641330dd1',NULL,'image_name','cirros'),('2019-12-24 11:42:13',NULL,NULL,0,45,'62ffb3fe-1bb6-4837-af63-833641330dd1',NULL,'image_id','5ee759d1-e9e3-4bda-a9c6-50bcfe5cc355'),('2019-12-24 11:42:13',NULL,NULL,0,48,'62ffb3fe-1bb6-4837-af63-833641330dd1',NULL,'checksum','443b7623e27ecf03dc9e01ee93f67afe'),('2019-12-24 11:42:13',NULL,NULL,0,51,'62ffb3fe-1bb6-4837-af63-833641330dd1',NULL,'min_disk','0'),('2019-12-24 11:42:13',NULL,NULL,0,54,'62ffb3fe-1bb6-4837-af63-833641330dd1',NULL,'size','12716032'),('2019-12-24 11:47:21',NULL,NULL,0,57,'fae19897-e732-43fc-a73f-21f971de7173',NULL,'signature_verified','False'),('2019-12-24 11:47:25',NULL,NULL,0,60,'fae19897-e732-43fc-a73f-21f971de7173',NULL,'container_format','bare'),('2019-12-24 11:47:25',NULL,NULL,0,63,'fae19897-e732-43fc-a73f-21f971de7173',NULL,'min_ram','0'),('2019-12-24 11:47:25',NULL,NULL,0,66,'fae19897-e732-43fc-a73f-21f971de7173',NULL,'disk_format','qcow2'),('2019-12-24 11:47:25',NULL,NULL,0,69,'fae19897-e732-43fc-a73f-21f971de7173',NULL,'image_name','cirros'),('2019-12-24 11:47:25',NULL,NULL,0,72,'fae19897-e732-43fc-a73f-21f971de7173',NULL,'image_id','5ee759d1-e9e3-4bda-a9c6-50bcfe5cc355'),('2019-12-24 11:47:25',NULL,NULL,0,75,'fae19897-e732-43fc-a73f-21f971de7173',NULL,'checksum','443b7623e27ecf03dc9e01ee93f67afe'),('2019-12-24 11:47:25',NULL,NULL,0,78,'fae19897-e732-43fc-a73f-21f971de7173',NULL,'min_disk','0'),('2019-12-24 11:47:25',NULL,NULL,0,81,'fae19897-e732-43fc-a73f-21f971de7173',NULL,'size','12716032'),('2019-12-24 11:50:49',NULL,NULL,0,84,'93f9710f-3de5-4c26-bed3-4c827308c5ad',NULL,'signature_verified','False'),('2019-12-24 11:50:53',NULL,NULL,0,87,'93f9710f-3de5-4c26-bed3-4c827308c5ad',NULL,'container_format','bare'),('2019-12-24 11:50:53',NULL,NULL,0,90,'93f9710f-3de5-4c26-bed3-4c827308c5ad',NULL,'min_ram','0'),('2019-12-24 11:50:53',NULL,NULL,0,93,'93f9710f-3de5-4c26-bed3-4c827308c5ad',NULL,'disk_format','qcow2'),('2019-12-24 11:50:53',NULL,NULL,0,96,'93f9710f-3de5-4c26-bed3-4c827308c5ad',NULL,'image_name','cirros'),('2019-12-24 11:50:53',NULL,NULL,0,99,'93f9710f-3de5-4c26-bed3-4c827308c5ad',NULL,'image_id','5ee759d1-e9e3-4bda-a9c6-50bcfe5cc355'),('2019-12-24 11:50:53',NULL,NULL,0,102,'93f9710f-3de5-4c26-bed3-4c827308c5ad',NULL,'checksum','443b7623e27ecf03dc9e01ee93f67afe'),('2019-12-24 11:50:53',NULL,NULL,0,105,'93f9710f-3de5-4c26-bed3-4c827308c5ad',NULL,'min_disk','0'),('2019-12-24 11:50:53',NULL,NULL,0,108,'93f9710f-3de5-4c26-bed3-4c827308c5ad',NULL,'size','12716032'),('2019-12-24 11:54:57',NULL,NULL,0,111,'b225b36d-6434-4e89-b302-2de775754069',NULL,'signature_verified','False'),('2019-12-24 11:55:00',NULL,NULL,0,114,'b225b36d-6434-4e89-b302-2de775754069',NULL,'container_format','bare'),('2019-12-24 11:55:00',NULL,NULL,0,117,'b225b36d-6434-4e89-b302-2de775754069',NULL,'min_ram','0'),('2019-12-24 11:55:00',NULL,NULL,0,120,'b225b36d-6434-4e89-b302-2de775754069',NULL,'disk_format','qcow2'),('2019-12-24 11:55:00',NULL,NULL,0,123,'b225b36d-6434-4e89-b302-2de775754069',NULL,'image_name','cirros'),('2019-12-24 11:55:00',NULL,NULL,0,126,'b225b36d-6434-4e89-b302-2de775754069',NULL,'image_id','5ee759d1-e9e3-4bda-a9c6-50bcfe5cc355'),('2019-12-24 11:55:00',NULL,NULL,0,129,'b225b36d-6434-4e89-b302-2de775754069',NULL,'checksum','443b7623e27ecf03dc9e01ee93f67afe'),('2019-12-24 11:55:00',NULL,NULL,0,132,'b225b36d-6434-4e89-b302-2de775754069',NULL,'min_disk','0'),('2019-12-24 11:55:00',NULL,NULL,0,135,'b225b36d-6434-4e89-b302-2de775754069',NULL,'size','12716032'),('2019-12-24 11:58:30',NULL,'2019-12-25 08:32:38',1,138,'2d26bdaa-b52f-4505-a4d8-b2074a5355d8',NULL,'signature_verified','False'),('2019-12-24 11:58:34',NULL,'2019-12-25 08:32:38',1,141,'2d26bdaa-b52f-4505-a4d8-b2074a5355d8',NULL,'container_format','bare'),('2019-12-24 11:58:34',NULL,'2019-12-25 08:32:38',1,144,'2d26bdaa-b52f-4505-a4d8-b2074a5355d8',NULL,'min_ram','0'),('2019-12-24 11:58:34',NULL,'2019-12-25 08:32:38',1,147,'2d26bdaa-b52f-4505-a4d8-b2074a5355d8',NULL,'disk_format','qcow2'),('2019-12-24 11:58:34',NULL,'2019-12-25 08:32:38',1,150,'2d26bdaa-b52f-4505-a4d8-b2074a5355d8',NULL,'image_name','cirros'),('2019-12-24 11:58:34',NULL,'2019-12-25 08:32:38',1,153,'2d26bdaa-b52f-4505-a4d8-b2074a5355d8',NULL,'image_id','5ee759d1-e9e3-4bda-a9c6-50bcfe5cc355'),('2019-12-24 11:58:34',NULL,'2019-12-25 08:32:38',1,156,'2d26bdaa-b52f-4505-a4d8-b2074a5355d8',NULL,'checksum','443b7623e27ecf03dc9e01ee93f67afe'),('2019-12-24 11:58:34',NULL,'2019-12-25 08:32:38',1,159,'2d26bdaa-b52f-4505-a4d8-b2074a5355d8',NULL,'min_disk','0'),('2019-12-24 11:58:34',NULL,'2019-12-25 08:32:38',1,162,'2d26bdaa-b52f-4505-a4d8-b2074a5355d8',NULL,'size','12716032'),('2019-12-24 11:59:40',NULL,NULL,0,165,'3f96d033-5734-467b-9777-7d85f80933b7',NULL,'signature_verified','False'),('2019-12-24 11:59:53',NULL,NULL,0,168,'3f96d033-5734-467b-9777-7d85f80933b7',NULL,'container_format','bare'),('2019-12-24 11:59:53',NULL,NULL,0,171,'3f96d033-5734-467b-9777-7d85f80933b7',NULL,'min_ram','0'),('2019-12-24 11:59:53',NULL,NULL,0,174,'3f96d033-5734-467b-9777-7d85f80933b7',NULL,'disk_format','qcow2'),('2019-12-24 11:59:53',NULL,NULL,0,177,'3f96d033-5734-467b-9777-7d85f80933b7',NULL,'image_name','centos7'),('2019-12-24 11:59:53',NULL,NULL,0,180,'3f96d033-5734-467b-9777-7d85f80933b7',NULL,'image_id','4246efca-c550-48f8-aa0e-7a368df98da6'),('2019-12-24 11:59:53',NULL,NULL,0,183,'3f96d033-5734-467b-9777-7d85f80933b7',NULL,'checksum','160aa274e7a69f2edb50e2d89f54270b'),('2019-12-24 11:59:53',NULL,NULL,0,186,'3f96d033-5734-467b-9777-7d85f80933b7',NULL,'min_disk','0'),('2019-12-24 11:59:53',NULL,NULL,0,189,'3f96d033-5734-467b-9777-7d85f80933b7',NULL,'size','942407680'),('2019-12-25 02:43:07',NULL,'2019-12-25 08:32:41',1,192,'d47ce62a-91a9-4876-8907-b601d19d69b8',NULL,'signature_verified','False'),('2019-12-25 03:02:00',NULL,NULL,0,195,NULL,'a37e1787-05f1-4d9a-b8d3-09f1db015f14','signature_verified','False'),('2019-12-25 03:02:00',NULL,NULL,0,198,NULL,'a37e1787-05f1-4d9a-b8d3-09f1db015f14','container_format','bare'),('2019-12-25 03:02:00',NULL,NULL,0,201,NULL,'a37e1787-05f1-4d9a-b8d3-09f1db015f14','min_ram','0'),('2019-12-25 03:02:00',NULL,NULL,0,204,NULL,'a37e1787-05f1-4d9a-b8d3-09f1db015f14','disk_format','qcow2'),('2019-12-25 03:02:00',NULL,NULL,0,207,NULL,'a37e1787-05f1-4d9a-b8d3-09f1db015f14','image_name','centos7'),('2019-12-25 03:02:00',NULL,NULL,0,210,NULL,'a37e1787-05f1-4d9a-b8d3-09f1db015f14','image_id','4246efca-c550-48f8-aa0e-7a368df98da6'),('2019-12-25 03:02:00',NULL,NULL,0,213,NULL,'a37e1787-05f1-4d9a-b8d3-09f1db015f14','checksum','160aa274e7a69f2edb50e2d89f54270b'),('2019-12-25 03:02:00',NULL,NULL,0,216,NULL,'a37e1787-05f1-4d9a-b8d3-09f1db015f14','min_disk','0'),('2019-12-25 03:02:00',NULL,NULL,0,219,NULL,'a37e1787-05f1-4d9a-b8d3-09f1db015f14','size','942407680'),('2019-12-25 03:04:03',NULL,'2019-12-25 07:12:47',1,222,'99afd14f-9028-4d77-bf9f-3c12ac9a1df2',NULL,'signature_verified','False'),('2019-12-25 03:04:03',NULL,'2019-12-25 07:12:47',1,225,'99afd14f-9028-4d77-bf9f-3c12ac9a1df2',NULL,'container_format','bare'),('2019-12-25 03:04:03',NULL,'2019-12-25 07:12:47',1,228,'99afd14f-9028-4d77-bf9f-3c12ac9a1df2',NULL,'min_ram','0'),('2019-12-25 03:04:03',NULL,'2019-12-25 07:12:47',1,231,'99afd14f-9028-4d77-bf9f-3c12ac9a1df2',NULL,'disk_format','qcow2'),('2019-12-25 03:04:03',NULL,'2019-12-25 07:12:47',1,234,'99afd14f-9028-4d77-bf9f-3c12ac9a1df2',NULL,'image_name','centos7'),('2019-12-25 03:04:03',NULL,'2019-12-25 07:12:47',1,237,'99afd14f-9028-4d77-bf9f-3c12ac9a1df2',NULL,'image_id','4246efca-c550-48f8-aa0e-7a368df98da6'),('2019-12-25 03:04:03',NULL,'2019-12-25 07:12:47',1,240,'99afd14f-9028-4d77-bf9f-3c12ac9a1df2',NULL,'checksum','160aa274e7a69f2edb50e2d89f54270b'),('2019-12-25 03:04:03',NULL,'2019-12-25 07:12:47',1,243,'99afd14f-9028-4d77-bf9f-3c12ac9a1df2',NULL,'min_disk','0'),('2019-12-25 03:04:03',NULL,'2019-12-25 07:12:47',1,246,'99afd14f-9028-4d77-bf9f-3c12ac9a1df2',NULL,'size','942407680'),('2019-12-25 07:22:04',NULL,NULL,0,249,'01aea4a1-b0c5-41fb-b184-2b1d9e8d1a18',NULL,'signature_verified','False'),('2019-12-25 07:22:36',NULL,NULL,0,252,'01aea4a1-b0c5-41fb-b184-2b1d9e8d1a18',NULL,'container_format','bare'),('2019-12-25 07:22:36',NULL,NULL,0,255,'01aea4a1-b0c5-41fb-b184-2b1d9e8d1a18',NULL,'min_ram','0'),('2019-12-25 07:22:36',NULL,NULL,0,258,'01aea4a1-b0c5-41fb-b184-2b1d9e8d1a18',NULL,'disk_format','qcow2'),('2019-12-25 07:22:36',NULL,NULL,0,261,'01aea4a1-b0c5-41fb-b184-2b1d9e8d1a18',NULL,'image_name','wwin2k19'),('2019-12-25 07:22:36',NULL,NULL,0,264,'01aea4a1-b0c5-41fb-b184-2b1d9e8d1a18',NULL,'image_id','e8a9d0c4-bbfb-4f67-a445-46e1bae3809f'),('2019-12-25 07:22:36',NULL,NULL,0,267,'01aea4a1-b0c5-41fb-b184-2b1d9e8d1a18',NULL,'checksum','b09a92961371c16fdbb0086e8dbdfd27'),('2019-12-25 07:22:36',NULL,NULL,0,270,'01aea4a1-b0c5-41fb-b184-2b1d9e8d1a18',NULL,'min_disk','0'),('2019-12-25 07:22:36',NULL,NULL,0,273,'01aea4a1-b0c5-41fb-b184-2b1d9e8d1a18',NULL,'size','9454157824'),('2019-12-26 03:31:44',NULL,'2019-12-27 02:29:37',1,276,'55976623-d1fe-4370-8aa5-7e6d9234fffa',NULL,'signature_verified','False'),('2019-12-26 03:32:14',NULL,'2019-12-27 02:29:37',1,279,'55976623-d1fe-4370-8aa5-7e6d9234fffa',NULL,'container_format','bare'),('2019-12-26 03:32:14',NULL,'2019-12-27 02:29:37',1,282,'55976623-d1fe-4370-8aa5-7e6d9234fffa',NULL,'min_ram','0'),('2019-12-26 03:32:14',NULL,'2019-12-27 02:29:37',1,285,'55976623-d1fe-4370-8aa5-7e6d9234fffa',NULL,'disk_format','qcow2'),('2019-12-26 03:32:14',NULL,'2019-12-27 02:29:37',1,288,'55976623-d1fe-4370-8aa5-7e6d9234fffa',NULL,'image_name','win2k19'),('2019-12-26 03:32:14',NULL,'2019-12-27 02:29:37',1,291,'55976623-d1fe-4370-8aa5-7e6d9234fffa',NULL,'image_id','e8a9d0c4-bbfb-4f67-a445-46e1bae3809f'),('2019-12-26 03:32:14',NULL,'2019-12-27 02:29:37',1,294,'55976623-d1fe-4370-8aa5-7e6d9234fffa',NULL,'checksum','b09a92961371c16fdbb0086e8dbdfd27'),('2019-12-26 03:32:14',NULL,'2019-12-27 02:29:37',1,297,'55976623-d1fe-4370-8aa5-7e6d9234fffa',NULL,'min_disk','0'),('2019-12-26 03:32:14',NULL,'2019-12-27 02:29:37',1,300,'55976623-d1fe-4370-8aa5-7e6d9234fffa',NULL,'size','9454157824'),('2019-12-26 09:54:53',NULL,'2019-12-26 10:10:39',1,303,'7a28cd3d-ef34-4d34-8d0f-b8f0abd3e93c',NULL,'signature_verified','False'),('2019-12-26 09:54:54',NULL,'2019-12-26 10:10:39',1,306,'0f940da7-9b0d-40b3-b62b-9a17157ccb17',NULL,'signature_verified','False'),('2019-12-26 09:56:14',NULL,'2019-12-26 10:10:39',1,309,'0f940da7-9b0d-40b3-b62b-9a17157ccb17',NULL,'container_format','bare'),('2019-12-26 09:56:14',NULL,'2019-12-26 10:10:39',1,312,'0f940da7-9b0d-40b3-b62b-9a17157ccb17',NULL,'min_ram','0'),('2019-12-26 09:56:14',NULL,'2019-12-26 10:10:39',1,315,'0f940da7-9b0d-40b3-b62b-9a17157ccb17',NULL,'disk_format','qcow2'),('2019-12-26 09:56:14',NULL,'2019-12-26 10:10:39',1,318,'0f940da7-9b0d-40b3-b62b-9a17157ccb17',NULL,'image_name','win2k19'),('2019-12-26 09:56:14',NULL,'2019-12-26 10:10:39',1,321,'7a28cd3d-ef34-4d34-8d0f-b8f0abd3e93c',NULL,'container_format','bare'),('2019-12-26 09:56:14',NULL,'2019-12-26 10:10:39',1,324,'0f940da7-9b0d-40b3-b62b-9a17157ccb17',NULL,'image_id','e8a9d0c4-bbfb-4f67-a445-46e1bae3809f'),('2019-12-26 09:56:14',NULL,'2019-12-26 10:10:39',1,327,'7a28cd3d-ef34-4d34-8d0f-b8f0abd3e93c',NULL,'min_ram','0'),('2019-12-26 09:56:14',NULL,'2019-12-26 10:10:39',1,330,'0f940da7-9b0d-40b3-b62b-9a17157ccb17',NULL,'checksum','b09a92961371c16fdbb0086e8dbdfd27'),('2019-12-26 09:56:14',NULL,'2019-12-26 10:10:39',1,333,'7a28cd3d-ef34-4d34-8d0f-b8f0abd3e93c',NULL,'disk_format','qcow2'),('2019-12-26 09:56:14',NULL,'2019-12-26 10:10:39',1,336,'0f940da7-9b0d-40b3-b62b-9a17157ccb17',NULL,'min_disk','0'),('2019-12-26 09:56:14',NULL,'2019-12-26 10:10:39',1,339,'7a28cd3d-ef34-4d34-8d0f-b8f0abd3e93c',NULL,'image_name','win2k19'),('2019-12-26 09:56:14',NULL,'2019-12-26 10:10:39',1,342,'0f940da7-9b0d-40b3-b62b-9a17157ccb17',NULL,'size','9454157824'),('2019-12-26 09:56:14',NULL,'2019-12-26 10:10:39',1,345,'7a28cd3d-ef34-4d34-8d0f-b8f0abd3e93c',NULL,'image_id','e8a9d0c4-bbfb-4f67-a445-46e1bae3809f'),('2019-12-26 09:56:14',NULL,'2019-12-26 10:10:39',1,348,'7a28cd3d-ef34-4d34-8d0f-b8f0abd3e93c',NULL,'checksum','b09a92961371c16fdbb0086e8dbdfd27'),('2019-12-26 09:56:14',NULL,'2019-12-26 10:10:39',1,351,'7a28cd3d-ef34-4d34-8d0f-b8f0abd3e93c',NULL,'min_disk','0'),('2019-12-26 09:56:14',NULL,'2019-12-26 10:10:39',1,354,'7a28cd3d-ef34-4d34-8d0f-b8f0abd3e93c',NULL,'size','9454157824'),('2019-12-26 09:57:14',NULL,'2019-12-26 10:10:40',1,357,'8b9cf4ea-ee8d-439b-9065-57605d92bedd',NULL,'signature_verified','False'),('2019-12-26 09:57:14',NULL,'2019-12-26 10:10:40',1,360,'6a8ba377-1d60-4b6d-9b2e-9770090c59a9',NULL,'signature_verified','False'),('2019-12-26 09:57:14',NULL,'2019-12-26 10:10:40',1,363,'f41e0be3-a7e3-41b1-9307-048c29f1077c',NULL,'signature_verified','False'),('2019-12-26 09:57:15',NULL,'2019-12-26 10:10:39',1,366,'4719f59f-a9c4-4f66-863d-651c58805883',NULL,'signature_verified','False'),('2019-12-26 09:57:16',NULL,'2019-12-26 10:10:39',1,369,'95ca280b-54ec-4e81-b2d1-3b4255b6dfc9',NULL,'signature_verified','False'),('2019-12-26 09:57:18',NULL,'2019-12-26 10:10:39',1,372,'2e0fad69-854e-452c-ba4b-1f61c6cfd9ea',NULL,'signature_verified','False'),('2019-12-26 09:57:20',NULL,'2019-12-26 10:04:46',1,375,'77dd9637-e608-46a3-9d06-f6b031c0b60b',NULL,'signature_verified','False'),('2019-12-26 09:57:24',NULL,'2019-12-26 10:10:39',1,378,'50e482f2-0997-44dc-b244-3de18185146c',NULL,'signature_verified','False'),('2019-12-26 10:04:08',NULL,'2019-12-26 10:10:40',1,381,'8b9cf4ea-ee8d-439b-9065-57605d92bedd',NULL,'container_format','bare'),('2019-12-26 10:04:08',NULL,'2019-12-26 10:10:40',1,384,'6a8ba377-1d60-4b6d-9b2e-9770090c59a9',NULL,'container_format','bare'),('2019-12-26 10:04:08',NULL,'2019-12-26 10:10:40',1,387,'f41e0be3-a7e3-41b1-9307-048c29f1077c',NULL,'container_format','bare'),('2019-12-26 10:04:08',NULL,'2019-12-26 10:10:40',1,390,'8b9cf4ea-ee8d-439b-9065-57605d92bedd',NULL,'min_ram','0'),('2019-12-26 10:04:08',NULL,'2019-12-26 10:10:40',1,393,'6a8ba377-1d60-4b6d-9b2e-9770090c59a9',NULL,'min_ram','0'),('2019-12-26 10:04:08',NULL,'2019-12-26 10:10:40',1,396,'f41e0be3-a7e3-41b1-9307-048c29f1077c',NULL,'min_ram','0'),('2019-12-26 10:04:08',NULL,'2019-12-26 10:10:40',1,399,'8b9cf4ea-ee8d-439b-9065-57605d92bedd',NULL,'disk_format','qcow2'),('2019-12-26 10:04:08',NULL,'2019-12-26 10:10:40',1,402,'6a8ba377-1d60-4b6d-9b2e-9770090c59a9',NULL,'disk_format','qcow2'),('2019-12-26 10:04:08',NULL,'2019-12-26 10:10:40',1,405,'f41e0be3-a7e3-41b1-9307-048c29f1077c',NULL,'disk_format','qcow2'),('2019-12-26 10:04:08',NULL,'2019-12-26 10:10:40',1,408,'8b9cf4ea-ee8d-439b-9065-57605d92bedd',NULL,'image_name','win2k19'),('2019-12-26 10:04:08',NULL,'2019-12-26 10:10:40',1,411,'6a8ba377-1d60-4b6d-9b2e-9770090c59a9',NULL,'image_name','win2k19'),('2019-12-26 10:04:08',NULL,'2019-12-26 10:10:40',1,414,'8b9cf4ea-ee8d-439b-9065-57605d92bedd',NULL,'image_id','e8a9d0c4-bbfb-4f67-a445-46e1bae3809f'),('2019-12-26 10:04:08',NULL,'2019-12-26 10:10:40',1,417,'f41e0be3-a7e3-41b1-9307-048c29f1077c',NULL,'image_name','win2k19'),('2019-12-26 10:04:08',NULL,'2019-12-26 10:10:40',1,420,'6a8ba377-1d60-4b6d-9b2e-9770090c59a9',NULL,'image_id','e8a9d0c4-bbfb-4f67-a445-46e1bae3809f'),('2019-12-26 10:04:08',NULL,'2019-12-26 10:10:40',1,423,'8b9cf4ea-ee8d-439b-9065-57605d92bedd',NULL,'checksum','b09a92961371c16fdbb0086e8dbdfd27'),('2019-12-26 10:04:08',NULL,'2019-12-26 10:10:40',1,426,'f41e0be3-a7e3-41b1-9307-048c29f1077c',NULL,'image_id','e8a9d0c4-bbfb-4f67-a445-46e1bae3809f'),('2019-12-26 10:04:08',NULL,'2019-12-26 10:10:40',1,429,'6a8ba377-1d60-4b6d-9b2e-9770090c59a9',NULL,'checksum','b09a92961371c16fdbb0086e8dbdfd27'),('2019-12-26 10:04:08',NULL,'2019-12-26 10:10:40',1,432,'f41e0be3-a7e3-41b1-9307-048c29f1077c',NULL,'checksum','b09a92961371c16fdbb0086e8dbdfd27'),('2019-12-26 10:04:08',NULL,'2019-12-26 10:10:40',1,435,'8b9cf4ea-ee8d-439b-9065-57605d92bedd',NULL,'min_disk','0'),('2019-12-26 10:04:08',NULL,'2019-12-26 10:10:40',1,438,'6a8ba377-1d60-4b6d-9b2e-9770090c59a9',NULL,'min_disk','0'),('2019-12-26 10:04:08',NULL,'2019-12-26 10:10:40',1,441,'8b9cf4ea-ee8d-439b-9065-57605d92bedd',NULL,'size','9454157824'),('2019-12-26 10:04:08',NULL,'2019-12-26 10:10:40',1,444,'f41e0be3-a7e3-41b1-9307-048c29f1077c',NULL,'min_disk','0'),('2019-12-26 10:04:08',NULL,'2019-12-26 10:10:40',1,447,'6a8ba377-1d60-4b6d-9b2e-9770090c59a9',NULL,'size','9454157824'),('2019-12-26 10:04:08',NULL,'2019-12-26 10:10:40',1,450,'f41e0be3-a7e3-41b1-9307-048c29f1077c',NULL,'size','9454157824'),('2019-12-26 10:04:39',NULL,'2019-12-26 10:10:39',1,453,'2e0fad69-854e-452c-ba4b-1f61c6cfd9ea',NULL,'container_format','bare'),('2019-12-26 10:04:39',NULL,'2019-12-26 10:10:39',1,456,'4719f59f-a9c4-4f66-863d-651c58805883',NULL,'container_format','bare'),('2019-12-26 10:04:39',NULL,'2019-12-26 10:10:39',1,459,'2e0fad69-854e-452c-ba4b-1f61c6cfd9ea',NULL,'min_ram','0'),('2019-12-26 10:04:39',NULL,'2019-12-26 10:10:39',1,462,'4719f59f-a9c4-4f66-863d-651c58805883',NULL,'min_ram','0'),('2019-12-26 10:04:39',NULL,'2019-12-26 10:10:39',1,465,'2e0fad69-854e-452c-ba4b-1f61c6cfd9ea',NULL,'disk_format','qcow2'),('2019-12-26 10:04:39',NULL,'2019-12-26 10:10:39',1,468,'2e0fad69-854e-452c-ba4b-1f61c6cfd9ea',NULL,'image_name','win2k19'),('2019-12-26 10:04:39',NULL,'2019-12-26 10:10:39',1,471,'4719f59f-a9c4-4f66-863d-651c58805883',NULL,'disk_format','qcow2'),('2019-12-26 10:04:39',NULL,'2019-12-26 10:10:39',1,474,'95ca280b-54ec-4e81-b2d1-3b4255b6dfc9',NULL,'container_format','bare'),('2019-12-26 10:04:40',NULL,'2019-12-26 10:10:39',1,477,'2e0fad69-854e-452c-ba4b-1f61c6cfd9ea',NULL,'image_id','e8a9d0c4-bbfb-4f67-a445-46e1bae3809f'),('2019-12-26 10:04:40',NULL,'2019-12-26 10:10:39',1,480,'4719f59f-a9c4-4f66-863d-651c58805883',NULL,'image_name','win2k19'),('2019-12-26 10:04:40',NULL,'2019-12-26 10:10:39',1,483,'95ca280b-54ec-4e81-b2d1-3b4255b6dfc9',NULL,'min_ram','0'),('2019-12-26 10:04:40',NULL,'2019-12-26 10:10:39',1,486,'95ca280b-54ec-4e81-b2d1-3b4255b6dfc9',NULL,'disk_format','qcow2'),('2019-12-26 10:04:40',NULL,'2019-12-26 10:10:39',1,489,'2e0fad69-854e-452c-ba4b-1f61c6cfd9ea',NULL,'checksum','b09a92961371c16fdbb0086e8dbdfd27'),('2019-12-26 10:04:40',NULL,'2019-12-26 10:10:39',1,492,'4719f59f-a9c4-4f66-863d-651c58805883',NULL,'image_id','e8a9d0c4-bbfb-4f67-a445-46e1bae3809f'),('2019-12-26 10:04:40',NULL,'2019-12-26 10:10:39',1,495,'95ca280b-54ec-4e81-b2d1-3b4255b6dfc9',NULL,'image_name','win2k19'),('2019-12-26 10:04:40',NULL,'2019-12-26 10:10:39',1,498,'95ca280b-54ec-4e81-b2d1-3b4255b6dfc9',NULL,'image_id','e8a9d0c4-bbfb-4f67-a445-46e1bae3809f'),('2019-12-26 10:04:40',NULL,'2019-12-26 10:10:39',1,501,'2e0fad69-854e-452c-ba4b-1f61c6cfd9ea',NULL,'min_disk','0'),('2019-12-26 10:04:40',NULL,'2019-12-26 10:10:39',1,504,'4719f59f-a9c4-4f66-863d-651c58805883',NULL,'checksum','b09a92961371c16fdbb0086e8dbdfd27'),('2019-12-26 10:04:40',NULL,'2019-12-26 10:10:39',1,507,'95ca280b-54ec-4e81-b2d1-3b4255b6dfc9',NULL,'checksum','b09a92961371c16fdbb0086e8dbdfd27'),('2019-12-26 10:04:40',NULL,'2019-12-26 10:10:39',1,510,'2e0fad69-854e-452c-ba4b-1f61c6cfd9ea',NULL,'size','9454157824'),('2019-12-26 10:04:40',NULL,'2019-12-26 10:10:39',1,513,'95ca280b-54ec-4e81-b2d1-3b4255b6dfc9',NULL,'min_disk','0'),('2019-12-26 10:04:40',NULL,'2019-12-26 10:10:39',1,516,'4719f59f-a9c4-4f66-863d-651c58805883',NULL,'min_disk','0'),('2019-12-26 10:04:40',NULL,'2019-12-26 10:10:39',1,519,'95ca280b-54ec-4e81-b2d1-3b4255b6dfc9',NULL,'size','9454157824'),('2019-12-26 10:04:40',NULL,'2019-12-26 10:10:39',1,522,'4719f59f-a9c4-4f66-863d-651c58805883',NULL,'size','9454157824'),('2019-12-26 10:04:42',NULL,'2019-12-26 10:04:46',1,525,'77dd9637-e608-46a3-9d06-f6b031c0b60b',NULL,'container_format','bare'),('2019-12-26 10:04:42',NULL,'2019-12-26 10:04:46',1,528,'77dd9637-e608-46a3-9d06-f6b031c0b60b',NULL,'min_ram','0'),('2019-12-26 10:04:42',NULL,'2019-12-26 10:04:46',1,531,'77dd9637-e608-46a3-9d06-f6b031c0b60b',NULL,'disk_format','qcow2'),('2019-12-26 10:04:42',NULL,'2019-12-26 10:04:46',1,534,'77dd9637-e608-46a3-9d06-f6b031c0b60b',NULL,'image_name','win2k19'),('2019-12-26 10:04:42',NULL,'2019-12-26 10:04:46',1,537,'77dd9637-e608-46a3-9d06-f6b031c0b60b',NULL,'image_id','e8a9d0c4-bbfb-4f67-a445-46e1bae3809f'),('2019-12-26 10:04:42',NULL,'2019-12-26 10:04:46',1,540,'77dd9637-e608-46a3-9d06-f6b031c0b60b',NULL,'checksum','b09a92961371c16fdbb0086e8dbdfd27'),('2019-12-26 10:04:42',NULL,'2019-12-26 10:04:46',1,543,'77dd9637-e608-46a3-9d06-f6b031c0b60b',NULL,'min_disk','0'),('2019-12-26 10:04:42',NULL,'2019-12-26 10:04:46',1,546,'77dd9637-e608-46a3-9d06-f6b031c0b60b',NULL,'size','9454157824'),('2019-12-27 08:30:27',NULL,'2019-12-27 08:36:19',1,547,'075db1a2-aa5f-4e6e-a68e-3a691dfb74d7',NULL,'signature_verified','False'),('2019-12-27 08:30:27',NULL,'2019-12-27 08:36:19',1,550,'ceed9274-ba03-4575-bbfe-a98e7940bdc0',NULL,'signature_verified','False'),('2019-12-27 08:30:28',NULL,'2019-12-27 08:36:19',1,553,'b6fd5119-6d56-4705-91da-f78448569780',NULL,'signature_verified','False'),('2019-12-27 08:30:37',NULL,'2019-12-27 08:36:19',1,556,'68f2ab0a-5517-416d-af2a-44fe2ad923ed',NULL,'signature_verified','False'),('2019-12-27 08:30:39',NULL,'2019-12-27 08:36:19',1,559,'5bb083b9-68fc-4fdd-b810-28fabbc8246a',NULL,'signature_verified','False'),('2019-12-27 08:30:41',NULL,'2019-12-27 08:36:19',1,562,'5714a593-89db-4d93-9b3c-b4e58e78e4ca',NULL,'signature_verified','False'),('2019-12-27 08:32:12',NULL,'2019-12-27 08:36:20',1,565,'583b15a2-8447-4420-b598-2f9db6a6eadf',NULL,'signature_verified','False'),('2019-12-27 08:32:12',NULL,'2019-12-27 08:36:20',1,568,'3207c63a-674c-4edd-9602-131bd257550e',NULL,'signature_verified','False'),('2019-12-27 08:32:12',NULL,'2019-12-27 08:36:19',1,571,'ac311be4-b288-4d7a-8abf-fc0b823460e5',NULL,'signature_verified','False'),('2019-12-27 08:32:12',NULL,'2019-12-27 08:36:19',1,574,'3fb02922-30ae-4391-935a-93e3e3618787',NULL,'signature_verified','False'),('2019-12-27 08:33:44',NULL,'2019-12-27 08:36:19',1,577,'075db1a2-aa5f-4e6e-a68e-3a691dfb74d7',NULL,'container_format','bare'),('2019-12-27 08:33:44',NULL,'2019-12-27 08:36:19',1,580,'b6fd5119-6d56-4705-91da-f78448569780',NULL,'container_format','bare'),('2019-12-27 08:33:44',NULL,'2019-12-27 08:36:19',1,583,'075db1a2-aa5f-4e6e-a68e-3a691dfb74d7',NULL,'min_ram','0'),('2019-12-27 08:33:44',NULL,'2019-12-27 08:36:19',1,586,'b6fd5119-6d56-4705-91da-f78448569780',NULL,'min_ram','0'),('2019-12-27 08:33:44',NULL,'2019-12-27 08:36:19',1,589,'075db1a2-aa5f-4e6e-a68e-3a691dfb74d7',NULL,'disk_format','qcow2'),('2019-12-27 08:33:44',NULL,'2019-12-27 08:36:19',1,592,'b6fd5119-6d56-4705-91da-f78448569780',NULL,'disk_format','qcow2'),('2019-12-27 08:33:44',NULL,'2019-12-27 08:36:19',1,595,'b6fd5119-6d56-4705-91da-f78448569780',NULL,'image_name','win2k19'),('2019-12-27 08:33:44',NULL,'2019-12-27 08:36:19',1,598,'075db1a2-aa5f-4e6e-a68e-3a691dfb74d7',NULL,'image_name','win2k19'),('2019-12-27 08:33:44',NULL,'2019-12-27 08:36:19',1,601,'b6fd5119-6d56-4705-91da-f78448569780',NULL,'image_id','e8a9d0c4-bbfb-4f67-a445-46e1bae3809f'),('2019-12-27 08:33:44',NULL,'2019-12-27 08:36:19',1,604,'075db1a2-aa5f-4e6e-a68e-3a691dfb74d7',NULL,'image_id','e8a9d0c4-bbfb-4f67-a445-46e1bae3809f'),('2019-12-27 08:33:44',NULL,'2019-12-27 08:36:19',1,607,'b6fd5119-6d56-4705-91da-f78448569780',NULL,'checksum','b09a92961371c16fdbb0086e8dbdfd27'),('2019-12-27 08:33:44',NULL,'2019-12-27 08:36:19',1,610,'075db1a2-aa5f-4e6e-a68e-3a691dfb74d7',NULL,'checksum','b09a92961371c16fdbb0086e8dbdfd27'),('2019-12-27 08:33:44',NULL,'2019-12-27 08:36:19',1,613,'ceed9274-ba03-4575-bbfe-a98e7940bdc0',NULL,'container_format','bare'),('2019-12-27 08:33:44',NULL,'2019-12-27 08:36:19',1,616,'b6fd5119-6d56-4705-91da-f78448569780',NULL,'min_disk','0'),('2019-12-27 08:33:44',NULL,'2019-12-27 08:36:19',1,619,'ceed9274-ba03-4575-bbfe-a98e7940bdc0',NULL,'min_ram','0'),('2019-12-27 08:33:44',NULL,'2019-12-27 08:36:19',1,622,'b6fd5119-6d56-4705-91da-f78448569780',NULL,'size','9454157824'),('2019-12-27 08:33:44',NULL,'2019-12-27 08:36:19',1,625,'ceed9274-ba03-4575-bbfe-a98e7940bdc0',NULL,'disk_format','qcow2'),('2019-12-27 08:33:44',NULL,'2019-12-27 08:36:19',1,628,'ceed9274-ba03-4575-bbfe-a98e7940bdc0',NULL,'image_name','win2k19'),('2019-12-27 08:33:44',NULL,'2019-12-27 08:36:19',1,631,'ceed9274-ba03-4575-bbfe-a98e7940bdc0',NULL,'image_id','e8a9d0c4-bbfb-4f67-a445-46e1bae3809f'),('2019-12-27 08:33:44',NULL,'2019-12-27 08:36:19',1,634,'ceed9274-ba03-4575-bbfe-a98e7940bdc0',NULL,'checksum','b09a92961371c16fdbb0086e8dbdfd27'),('2019-12-27 08:33:44',NULL,'2019-12-27 08:36:19',1,637,'ceed9274-ba03-4575-bbfe-a98e7940bdc0',NULL,'min_disk','0'),('2019-12-27 08:33:44',NULL,'2019-12-27 08:36:19',1,640,'ceed9274-ba03-4575-bbfe-a98e7940bdc0',NULL,'size','9454157824'),('2019-12-27 08:33:44',NULL,'2019-12-27 08:36:19',1,643,'075db1a2-aa5f-4e6e-a68e-3a691dfb74d7',NULL,'min_disk','0'),('2019-12-27 08:33:45',NULL,'2019-12-27 08:36:19',1,646,'075db1a2-aa5f-4e6e-a68e-3a691dfb74d7',NULL,'size','9454157824'),('2019-12-27 08:33:48',NULL,'2019-12-27 08:36:19',1,649,'5714a593-89db-4d93-9b3c-b4e58e78e4ca',NULL,'container_format','bare'),('2019-12-27 08:33:48',NULL,'2019-12-27 08:36:19',1,652,'68f2ab0a-5517-416d-af2a-44fe2ad923ed',NULL,'container_format','bare'),('2019-12-27 08:33:48',NULL,'2019-12-27 08:36:19',1,655,'5bb083b9-68fc-4fdd-b810-28fabbc8246a',NULL,'container_format','bare'),('2019-12-27 08:33:48',NULL,'2019-12-27 08:36:19',1,658,'5714a593-89db-4d93-9b3c-b4e58e78e4ca',NULL,'min_ram','0'),('2019-12-27 08:33:48',NULL,'2019-12-27 08:36:19',1,661,'5714a593-89db-4d93-9b3c-b4e58e78e4ca',NULL,'disk_format','qcow2'),('2019-12-27 08:33:48',NULL,'2019-12-27 08:36:19',1,664,'68f2ab0a-5517-416d-af2a-44fe2ad923ed',NULL,'min_ram','0'),('2019-12-27 08:33:48',NULL,'2019-12-27 08:36:19',1,667,'5bb083b9-68fc-4fdd-b810-28fabbc8246a',NULL,'min_ram','0'),('2019-12-27 08:33:48',NULL,'2019-12-27 08:36:19',1,670,'5714a593-89db-4d93-9b3c-b4e58e78e4ca',NULL,'image_name','win2k19'),('2019-12-27 08:33:48',NULL,'2019-12-27 08:36:19',1,673,'68f2ab0a-5517-416d-af2a-44fe2ad923ed',NULL,'disk_format','qcow2'),('2019-12-27 08:33:48',NULL,'2019-12-27 08:36:19',1,676,'5bb083b9-68fc-4fdd-b810-28fabbc8246a',NULL,'disk_format','qcow2'),('2019-12-27 08:33:48',NULL,'2019-12-27 08:36:19',1,679,'5714a593-89db-4d93-9b3c-b4e58e78e4ca',NULL,'image_id','e8a9d0c4-bbfb-4f67-a445-46e1bae3809f'),('2019-12-27 08:33:48',NULL,'2019-12-27 08:36:19',1,682,'5714a593-89db-4d93-9b3c-b4e58e78e4ca',NULL,'checksum','b09a92961371c16fdbb0086e8dbdfd27'),('2019-12-27 08:33:48',NULL,'2019-12-27 08:36:19',1,685,'68f2ab0a-5517-416d-af2a-44fe2ad923ed',NULL,'image_name','win2k19'),('2019-12-27 08:33:48',NULL,'2019-12-27 08:36:19',1,688,'5bb083b9-68fc-4fdd-b810-28fabbc8246a',NULL,'image_name','win2k19'),('2019-12-27 08:33:48',NULL,'2019-12-27 08:36:19',1,691,'5714a593-89db-4d93-9b3c-b4e58e78e4ca',NULL,'min_disk','0'),('2019-12-27 08:33:48',NULL,'2019-12-27 08:36:19',1,694,'5bb083b9-68fc-4fdd-b810-28fabbc8246a',NULL,'image_id','e8a9d0c4-bbfb-4f67-a445-46e1bae3809f'),('2019-12-27 08:33:48',NULL,'2019-12-27 08:36:19',1,697,'68f2ab0a-5517-416d-af2a-44fe2ad923ed',NULL,'image_id','e8a9d0c4-bbfb-4f67-a445-46e1bae3809f'),('2019-12-27 08:33:48',NULL,'2019-12-27 08:36:19',1,700,'5714a593-89db-4d93-9b3c-b4e58e78e4ca',NULL,'size','9454157824'),('2019-12-27 08:33:48',NULL,'2019-12-27 08:36:19',1,703,'5bb083b9-68fc-4fdd-b810-28fabbc8246a',NULL,'checksum','b09a92961371c16fdbb0086e8dbdfd27'),('2019-12-27 08:33:48',NULL,'2019-12-27 08:36:19',1,706,'68f2ab0a-5517-416d-af2a-44fe2ad923ed',NULL,'checksum','b09a92961371c16fdbb0086e8dbdfd27'),('2019-12-27 08:33:48',NULL,'2019-12-27 08:36:19',1,709,'5bb083b9-68fc-4fdd-b810-28fabbc8246a',NULL,'min_disk','0'),('2019-12-27 08:33:48',NULL,'2019-12-27 08:36:19',1,712,'68f2ab0a-5517-416d-af2a-44fe2ad923ed',NULL,'min_disk','0'),('2019-12-27 08:33:48',NULL,'2019-12-27 08:36:19',1,715,'5bb083b9-68fc-4fdd-b810-28fabbc8246a',NULL,'size','9454157824'),('2019-12-27 08:33:48',NULL,'2019-12-27 08:36:19',1,718,'68f2ab0a-5517-416d-af2a-44fe2ad923ed',NULL,'size','9454157824'),('2019-12-27 08:34:49',NULL,'2019-12-27 08:36:20',1,721,'3207c63a-674c-4edd-9602-131bd257550e',NULL,'container_format','bare'),('2019-12-27 08:34:49',NULL,'2019-12-27 08:36:20',1,724,'3207c63a-674c-4edd-9602-131bd257550e',NULL,'min_ram','0'),('2019-12-27 08:34:49',NULL,'2019-12-27 08:36:20',1,727,'583b15a2-8447-4420-b598-2f9db6a6eadf',NULL,'container_format','bare'),('2019-12-27 08:34:49',NULL,'2019-12-27 08:36:20',1,730,'3207c63a-674c-4edd-9602-131bd257550e',NULL,'disk_format','qcow2'),('2019-12-27 08:34:49',NULL,'2019-12-27 08:36:20',1,733,'583b15a2-8447-4420-b598-2f9db6a6eadf',NULL,'min_ram','0'),('2019-12-27 08:34:49',NULL,'2019-12-27 08:36:20',1,736,'3207c63a-674c-4edd-9602-131bd257550e',NULL,'image_name','win2k19'),('2019-12-27 08:34:49',NULL,'2019-12-27 08:36:20',1,739,'583b15a2-8447-4420-b598-2f9db6a6eadf',NULL,'disk_format','qcow2'),('2019-12-27 08:34:49',NULL,'2019-12-27 08:36:20',1,742,'3207c63a-674c-4edd-9602-131bd257550e',NULL,'image_id','e8a9d0c4-bbfb-4f67-a445-46e1bae3809f'),('2019-12-27 08:34:49',NULL,'2019-12-27 08:36:20',1,745,'583b15a2-8447-4420-b598-2f9db6a6eadf',NULL,'image_name','win2k19'),('2019-12-27 08:34:49',NULL,'2019-12-27 08:36:20',1,748,'583b15a2-8447-4420-b598-2f9db6a6eadf',NULL,'image_id','e8a9d0c4-bbfb-4f67-a445-46e1bae3809f'),('2019-12-27 08:34:49',NULL,'2019-12-27 08:36:20',1,751,'3207c63a-674c-4edd-9602-131bd257550e',NULL,'checksum','b09a92961371c16fdbb0086e8dbdfd27'),('2019-12-27 08:34:49',NULL,'2019-12-27 08:36:20',1,754,'583b15a2-8447-4420-b598-2f9db6a6eadf',NULL,'checksum','b09a92961371c16fdbb0086e8dbdfd27'),('2019-12-27 08:34:49',NULL,'2019-12-27 08:36:20',1,757,'3207c63a-674c-4edd-9602-131bd257550e',NULL,'min_disk','0'),('2019-12-27 08:34:49',NULL,'2019-12-27 08:36:20',1,760,'583b15a2-8447-4420-b598-2f9db6a6eadf',NULL,'min_disk','0'),('2019-12-27 08:34:49',NULL,'2019-12-27 08:36:19',1,763,'3fb02922-30ae-4391-935a-93e3e3618787',NULL,'container_format','bare'),('2019-12-27 08:34:49',NULL,'2019-12-27 08:36:20',1,766,'583b15a2-8447-4420-b598-2f9db6a6eadf',NULL,'size','9454157824'),('2019-12-27 08:34:49',NULL,'2019-12-27 08:36:20',1,769,'3207c63a-674c-4edd-9602-131bd257550e',NULL,'size','9454157824'),('2019-12-27 08:34:49',NULL,'2019-12-27 08:36:19',1,772,'3fb02922-30ae-4391-935a-93e3e3618787',NULL,'min_ram','0'),('2019-12-27 08:34:49',NULL,'2019-12-27 08:36:19',1,775,'3fb02922-30ae-4391-935a-93e3e3618787',NULL,'disk_format','qcow2'),('2019-12-27 08:34:49',NULL,'2019-12-27 08:36:19',1,778,'3fb02922-30ae-4391-935a-93e3e3618787',NULL,'image_name','win2k19'),('2019-12-27 08:34:49',NULL,'2019-12-27 08:36:19',1,781,'3fb02922-30ae-4391-935a-93e3e3618787',NULL,'image_id','e8a9d0c4-bbfb-4f67-a445-46e1bae3809f'),('2019-12-27 08:34:49',NULL,'2019-12-27 08:36:19',1,784,'3fb02922-30ae-4391-935a-93e3e3618787',NULL,'checksum','b09a92961371c16fdbb0086e8dbdfd27'),('2019-12-27 08:34:49',NULL,'2019-12-27 08:36:19',1,787,'3fb02922-30ae-4391-935a-93e3e3618787',NULL,'min_disk','0'),('2019-12-27 08:34:49',NULL,'2019-12-27 08:36:19',1,790,'3fb02922-30ae-4391-935a-93e3e3618787',NULL,'size','9454157824'),('2019-12-27 08:34:51',NULL,'2019-12-27 08:36:19',1,793,'ac311be4-b288-4d7a-8abf-fc0b823460e5',NULL,'container_format','bare'),('2019-12-27 08:34:51',NULL,'2019-12-27 08:36:19',1,796,'ac311be4-b288-4d7a-8abf-fc0b823460e5',NULL,'min_ram','0'),('2019-12-27 08:34:51',NULL,'2019-12-27 08:36:19',1,799,'ac311be4-b288-4d7a-8abf-fc0b823460e5',NULL,'disk_format','qcow2'),('2019-12-27 08:34:51',NULL,'2019-12-27 08:36:19',1,802,'ac311be4-b288-4d7a-8abf-fc0b823460e5',NULL,'image_name','win2k19'),('2019-12-27 08:34:51',NULL,'2019-12-27 08:36:19',1,805,'ac311be4-b288-4d7a-8abf-fc0b823460e5',NULL,'image_id','e8a9d0c4-bbfb-4f67-a445-46e1bae3809f'),('2019-12-27 08:34:51',NULL,'2019-12-27 08:36:19',1,808,'ac311be4-b288-4d7a-8abf-fc0b823460e5',NULL,'checksum','b09a92961371c16fdbb0086e8dbdfd27'),('2019-12-27 08:34:51',NULL,'2019-12-27 08:36:19',1,811,'ac311be4-b288-4d7a-8abf-fc0b823460e5',NULL,'min_disk','0'),('2019-12-27 08:34:51',NULL,'2019-12-27 08:36:19',1,814,'ac311be4-b288-4d7a-8abf-fc0b823460e5',NULL,'size','9454157824'),('2019-12-27 08:56:43',NULL,NULL,0,817,'e3e4ebfd-4da1-4c1f-b79f-6071a02816ef',NULL,'signature_verified','False'),('2019-12-27 08:56:43',NULL,NULL,0,820,'9396d79a-4a8e-45f9-907d-b30ba6299c5f',NULL,'signature_verified','False'),('2019-12-27 08:56:44',NULL,NULL,0,823,'f76a0505-f942-4cd4-82ce-6cef82279616',NULL,'signature_verified','False'),('2019-12-27 08:56:56',NULL,NULL,0,826,'8be45146-a7e7-4d43-b368-b8c18e6fcbbb',NULL,'signature_verified','False'),('2019-12-27 08:56:57',NULL,NULL,0,829,'418ef8f2-c31f-4b9f-a570-98679812e5bf',NULL,'signature_verified','False'),('2019-12-27 08:56:58',NULL,NULL,0,832,'2dc173b4-996c-4f66-b221-1dcfacd10f3d',NULL,'signature_verified','False'),('2019-12-27 08:58:25',NULL,NULL,0,835,'92365e82-3632-4469-b67d-69e6115c6944',NULL,'signature_verified','False'),('2019-12-27 08:58:25',NULL,NULL,0,838,'526de067-9664-459e-b973-f03990d85147',NULL,'signature_verified','False'),('2019-12-27 08:58:25',NULL,NULL,0,841,'625c33db-3326-456e-accc-080f46ebba5d',NULL,'signature_verified','False'),('2019-12-27 08:58:26',NULL,NULL,0,844,'c9dbc7bb-c6c6-483a-80e9-6796f47f2f03',NULL,'signature_verified','False'),('2019-12-27 09:00:59',NULL,NULL,0,847,'9396d79a-4a8e-45f9-907d-b30ba6299c5f',NULL,'container_format','bare'),('2019-12-27 09:00:59',NULL,NULL,0,850,'9396d79a-4a8e-45f9-907d-b30ba6299c5f',NULL,'min_ram','0'),('2019-12-27 09:00:59',NULL,NULL,0,853,'9396d79a-4a8e-45f9-907d-b30ba6299c5f',NULL,'disk_format','qcow2'),('2019-12-27 09:00:59',NULL,NULL,0,856,'9396d79a-4a8e-45f9-907d-b30ba6299c5f',NULL,'image_name','win2k19'),('2019-12-27 09:00:59',NULL,NULL,0,859,'9396d79a-4a8e-45f9-907d-b30ba6299c5f',NULL,'image_id','e8a9d0c4-bbfb-4f67-a445-46e1bae3809f'),('2019-12-27 09:00:59',NULL,NULL,0,862,'9396d79a-4a8e-45f9-907d-b30ba6299c5f',NULL,'checksum','b09a92961371c16fdbb0086e8dbdfd27'),('2019-12-27 09:00:59',NULL,NULL,0,865,'9396d79a-4a8e-45f9-907d-b30ba6299c5f',NULL,'min_disk','0'),('2019-12-27 09:00:59',NULL,NULL,0,868,'9396d79a-4a8e-45f9-907d-b30ba6299c5f',NULL,'size','9454157824'),('2019-12-27 09:00:59',NULL,NULL,0,871,'f76a0505-f942-4cd4-82ce-6cef82279616',NULL,'container_format','bare'),('2019-12-27 09:00:59',NULL,NULL,0,874,'e3e4ebfd-4da1-4c1f-b79f-6071a02816ef',NULL,'container_format','bare'),('2019-12-27 09:00:59',NULL,NULL,0,877,'f76a0505-f942-4cd4-82ce-6cef82279616',NULL,'min_ram','0'),('2019-12-27 09:00:59',NULL,NULL,0,880,'e3e4ebfd-4da1-4c1f-b79f-6071a02816ef',NULL,'min_ram','0'),('2019-12-27 09:00:59',NULL,NULL,0,883,'f76a0505-f942-4cd4-82ce-6cef82279616',NULL,'disk_format','qcow2'),('2019-12-27 09:00:59',NULL,NULL,0,886,'e3e4ebfd-4da1-4c1f-b79f-6071a02816ef',NULL,'disk_format','qcow2'),('2019-12-27 09:00:59',NULL,NULL,0,889,'f76a0505-f942-4cd4-82ce-6cef82279616',NULL,'image_name','win2k19'),('2019-12-27 09:00:59',NULL,NULL,0,892,'e3e4ebfd-4da1-4c1f-b79f-6071a02816ef',NULL,'image_name','win2k19'),('2019-12-27 09:00:59',NULL,NULL,0,895,'f76a0505-f942-4cd4-82ce-6cef82279616',NULL,'image_id','e8a9d0c4-bbfb-4f67-a445-46e1bae3809f'),('2019-12-27 09:00:59',NULL,NULL,0,898,'e3e4ebfd-4da1-4c1f-b79f-6071a02816ef',NULL,'image_id','e8a9d0c4-bbfb-4f67-a445-46e1bae3809f'),('2019-12-27 09:00:59',NULL,NULL,0,901,'f76a0505-f942-4cd4-82ce-6cef82279616',NULL,'checksum','b09a92961371c16fdbb0086e8dbdfd27'),('2019-12-27 09:00:59',NULL,NULL,0,904,'e3e4ebfd-4da1-4c1f-b79f-6071a02816ef',NULL,'checksum','b09a92961371c16fdbb0086e8dbdfd27'),('2019-12-27 09:00:59',NULL,NULL,0,907,'f76a0505-f942-4cd4-82ce-6cef82279616',NULL,'min_disk','0'),('2019-12-27 09:00:59',NULL,NULL,0,910,'e3e4ebfd-4da1-4c1f-b79f-6071a02816ef',NULL,'min_disk','0'),('2019-12-27 09:00:59',NULL,NULL,0,913,'f76a0505-f942-4cd4-82ce-6cef82279616',NULL,'size','9454157824'),('2019-12-27 09:00:59',NULL,NULL,0,916,'e3e4ebfd-4da1-4c1f-b79f-6071a02816ef',NULL,'size','9454157824'),('2019-12-27 09:01:03',NULL,NULL,0,919,'8be45146-a7e7-4d43-b368-b8c18e6fcbbb',NULL,'container_format','bare'),('2019-12-27 09:01:03',NULL,NULL,0,922,'8be45146-a7e7-4d43-b368-b8c18e6fcbbb',NULL,'min_ram','0'),('2019-12-27 09:01:03',NULL,NULL,0,925,'8be45146-a7e7-4d43-b368-b8c18e6fcbbb',NULL,'disk_format','qcow2'),('2019-12-27 09:01:03',NULL,NULL,0,928,'8be45146-a7e7-4d43-b368-b8c18e6fcbbb',NULL,'image_name','win2k19'),('2019-12-27 09:01:03',NULL,NULL,0,931,'8be45146-a7e7-4d43-b368-b8c18e6fcbbb',NULL,'image_id','e8a9d0c4-bbfb-4f67-a445-46e1bae3809f'),('2019-12-27 09:01:03',NULL,NULL,0,934,'8be45146-a7e7-4d43-b368-b8c18e6fcbbb',NULL,'checksum','b09a92961371c16fdbb0086e8dbdfd27'),('2019-12-27 09:01:03',NULL,NULL,0,937,'8be45146-a7e7-4d43-b368-b8c18e6fcbbb',NULL,'min_disk','0'),('2019-12-27 09:01:03',NULL,NULL,0,940,'8be45146-a7e7-4d43-b368-b8c18e6fcbbb',NULL,'size','9454157824'),('2019-12-27 09:01:03',NULL,NULL,0,943,'418ef8f2-c31f-4b9f-a570-98679812e5bf',NULL,'container_format','bare'),('2019-12-27 09:01:03',NULL,NULL,0,946,'418ef8f2-c31f-4b9f-a570-98679812e5bf',NULL,'min_ram','0'),('2019-12-27 09:01:03',NULL,NULL,0,949,'418ef8f2-c31f-4b9f-a570-98679812e5bf',NULL,'disk_format','qcow2'),('2019-12-27 09:01:03',NULL,NULL,0,952,'418ef8f2-c31f-4b9f-a570-98679812e5bf',NULL,'image_name','win2k19'),('2019-12-27 09:01:03',NULL,NULL,0,955,'418ef8f2-c31f-4b9f-a570-98679812e5bf',NULL,'image_id','e8a9d0c4-bbfb-4f67-a445-46e1bae3809f'),('2019-12-27 09:01:03',NULL,NULL,0,958,'418ef8f2-c31f-4b9f-a570-98679812e5bf',NULL,'checksum','b09a92961371c16fdbb0086e8dbdfd27'),('2019-12-27 09:01:03',NULL,NULL,0,961,'418ef8f2-c31f-4b9f-a570-98679812e5bf',NULL,'min_disk','0'),('2019-12-27 09:01:03',NULL,NULL,0,964,'418ef8f2-c31f-4b9f-a570-98679812e5bf',NULL,'size','9454157824'),('2019-12-27 09:01:04',NULL,NULL,0,967,'2dc173b4-996c-4f66-b221-1dcfacd10f3d',NULL,'container_format','bare'),('2019-12-27 09:01:04',NULL,NULL,0,970,'2dc173b4-996c-4f66-b221-1dcfacd10f3d',NULL,'min_ram','0'),('2019-12-27 09:01:04',NULL,NULL,0,973,'2dc173b4-996c-4f66-b221-1dcfacd10f3d',NULL,'disk_format','qcow2'),('2019-12-27 09:01:04',NULL,NULL,0,976,'2dc173b4-996c-4f66-b221-1dcfacd10f3d',NULL,'image_name','win2k19'),('2019-12-27 09:01:04',NULL,NULL,0,979,'2dc173b4-996c-4f66-b221-1dcfacd10f3d',NULL,'image_id','e8a9d0c4-bbfb-4f67-a445-46e1bae3809f'),('2019-12-27 09:01:04',NULL,NULL,0,982,'2dc173b4-996c-4f66-b221-1dcfacd10f3d',NULL,'checksum','b09a92961371c16fdbb0086e8dbdfd27'),('2019-12-27 09:01:04',NULL,NULL,0,985,'2dc173b4-996c-4f66-b221-1dcfacd10f3d',NULL,'min_disk','0'),('2019-12-27 09:01:04',NULL,NULL,0,988,'2dc173b4-996c-4f66-b221-1dcfacd10f3d',NULL,'size','9454157824'),('2019-12-27 09:01:42',NULL,NULL,0,991,'526de067-9664-459e-b973-f03990d85147',NULL,'container_format','bare'),('2019-12-27 09:01:43',NULL,NULL,0,994,'92365e82-3632-4469-b67d-69e6115c6944',NULL,'container_format','bare'),('2019-12-27 09:01:43',NULL,NULL,0,997,'526de067-9664-459e-b973-f03990d85147',NULL,'min_ram','0'),('2019-12-27 09:01:43',NULL,NULL,0,1000,'526de067-9664-459e-b973-f03990d85147',NULL,'disk_format','qcow2'),('2019-12-27 09:01:43',NULL,NULL,0,1003,'625c33db-3326-456e-accc-080f46ebba5d',NULL,'container_format','bare'),('2019-12-27 09:01:43',NULL,NULL,0,1006,'92365e82-3632-4469-b67d-69e6115c6944',NULL,'min_ram','0'),('2019-12-27 09:01:43',NULL,NULL,0,1009,'526de067-9664-459e-b973-f03990d85147',NULL,'image_name','win2k19'),('2019-12-27 09:01:43',NULL,NULL,0,1012,'625c33db-3326-456e-accc-080f46ebba5d',NULL,'min_ram','0'),('2019-12-27 09:01:43',NULL,NULL,0,1015,'92365e82-3632-4469-b67d-69e6115c6944',NULL,'disk_format','qcow2'),('2019-12-27 09:01:43',NULL,NULL,0,1018,'526de067-9664-459e-b973-f03990d85147',NULL,'image_id','e8a9d0c4-bbfb-4f67-a445-46e1bae3809f'),('2019-12-27 09:01:43',NULL,NULL,0,1021,'92365e82-3632-4469-b67d-69e6115c6944',NULL,'image_name','win2k19'),('2019-12-27 09:01:43',NULL,NULL,0,1024,'625c33db-3326-456e-accc-080f46ebba5d',NULL,'disk_format','qcow2'),('2019-12-27 09:01:43',NULL,NULL,0,1027,'526de067-9664-459e-b973-f03990d85147',NULL,'checksum','b09a92961371c16fdbb0086e8dbdfd27'),('2019-12-27 09:01:43',NULL,NULL,0,1030,'92365e82-3632-4469-b67d-69e6115c6944',NULL,'image_id','e8a9d0c4-bbfb-4f67-a445-46e1bae3809f'),('2019-12-27 09:01:43',NULL,NULL,0,1033,'625c33db-3326-456e-accc-080f46ebba5d',NULL,'image_name','win2k19'),('2019-12-27 09:01:43',NULL,NULL,0,1036,'526de067-9664-459e-b973-f03990d85147',NULL,'min_disk','0'),('2019-12-27 09:01:43',NULL,NULL,0,1039,'92365e82-3632-4469-b67d-69e6115c6944',NULL,'checksum','b09a92961371c16fdbb0086e8dbdfd27'),('2019-12-27 09:01:43',NULL,NULL,0,1042,'625c33db-3326-456e-accc-080f46ebba5d',NULL,'image_id','e8a9d0c4-bbfb-4f67-a445-46e1bae3809f'),('2019-12-27 09:01:43',NULL,NULL,0,1045,'526de067-9664-459e-b973-f03990d85147',NULL,'size','9454157824'),('2019-12-27 09:01:43',NULL,NULL,0,1048,'92365e82-3632-4469-b67d-69e6115c6944',NULL,'min_disk','0'),('2019-12-27 09:01:43',NULL,NULL,0,1051,'625c33db-3326-456e-accc-080f46ebba5d',NULL,'checksum','b09a92961371c16fdbb0086e8dbdfd27'),('2019-12-27 09:01:43',NULL,NULL,0,1054,'92365e82-3632-4469-b67d-69e6115c6944',NULL,'size','9454157824'),('2019-12-27 09:01:43',NULL,NULL,0,1057,'625c33db-3326-456e-accc-080f46ebba5d',NULL,'min_disk','0'),('2019-12-27 09:01:43',NULL,NULL,0,1060,'c9dbc7bb-c6c6-483a-80e9-6796f47f2f03',NULL,'container_format','bare'),('2019-12-27 09:01:43',NULL,NULL,0,1063,'625c33db-3326-456e-accc-080f46ebba5d',NULL,'size','9454157824'),('2019-12-27 09:01:43',NULL,NULL,0,1066,'c9dbc7bb-c6c6-483a-80e9-6796f47f2f03',NULL,'min_ram','0'),('2019-12-27 09:01:43',NULL,NULL,0,1069,'c9dbc7bb-c6c6-483a-80e9-6796f47f2f03',NULL,'disk_format','qcow2'),('2019-12-27 09:01:43',NULL,NULL,0,1072,'c9dbc7bb-c6c6-483a-80e9-6796f47f2f03',NULL,'image_name','win2k19'),('2019-12-27 09:01:43',NULL,NULL,0,1075,'c9dbc7bb-c6c6-483a-80e9-6796f47f2f03',NULL,'image_id','e8a9d0c4-bbfb-4f67-a445-46e1bae3809f'),('2019-12-27 09:01:43',NULL,NULL,0,1078,'c9dbc7bb-c6c6-483a-80e9-6796f47f2f03',NULL,'checksum','b09a92961371c16fdbb0086e8dbdfd27'),('2019-12-27 09:01:43',NULL,NULL,0,1081,'c9dbc7bb-c6c6-483a-80e9-6796f47f2f03',NULL,'min_disk','0'),('2019-12-27 09:01:43',NULL,NULL,0,1084,'c9dbc7bb-c6c6-483a-80e9-6796f47f2f03',NULL,'size','9454157824');
/*!40000 ALTER TABLE `volume_glance_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volume_metadata`
--

DROP TABLE IF EXISTS `volume_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volume_metadata` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `volume_id` varchar(36) NOT NULL,
  `key` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_volume_metadata_volume_id` (`volume_id`),
  CONSTRAINT `volume_metadata_ibfk_1` FOREIGN KEY (`volume_id`) REFERENCES `volumes` (`id`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`deleted` in (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volume_metadata`
--

LOCK TABLES `volume_metadata` WRITE;
/*!40000 ALTER TABLE `volume_metadata` DISABLE KEYS */;
/*!40000 ALTER TABLE `volume_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volume_type_extra_specs`
--

DROP TABLE IF EXISTS `volume_type_extra_specs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volume_type_extra_specs` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `volume_type_id` varchar(36) NOT NULL,
  `key` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_volume_type_extra_specs_volume_type_id` (`volume_type_id`),
  CONSTRAINT `volume_type_extra_specs_ibfk_1` FOREIGN KEY (`volume_type_id`) REFERENCES `volume_types` (`id`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`deleted` in (0,1))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volume_type_extra_specs`
--

LOCK TABLES `volume_type_extra_specs` WRITE;
/*!40000 ALTER TABLE `volume_type_extra_specs` DISABLE KEYS */;
INSERT INTO `volume_type_extra_specs` VALUES ('2019-12-06 16:08:18',NULL,NULL,0,3,'9f73ec18-eca5-487d-9ebf-c7cc0811922d','volume_backend_name','ceph');
/*!40000 ALTER TABLE `volume_type_extra_specs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volume_type_projects`
--

DROP TABLE IF EXISTS `volume_type_projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volume_type_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `volume_type_id` varchar(36) DEFAULT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `volume_type_id` (`volume_type_id`,`project_id`,`deleted`),
  CONSTRAINT `volume_type_projects_ibfk_1` FOREIGN KEY (`volume_type_id`) REFERENCES `volume_types` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volume_type_projects`
--

LOCK TABLES `volume_type_projects` WRITE;
/*!40000 ALTER TABLE `volume_type_projects` DISABLE KEYS */;
/*!40000 ALTER TABLE `volume_type_projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volume_types`
--

DROP TABLE IF EXISTS `volume_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volume_types` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `id` varchar(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `qos_specs_id` varchar(36) DEFAULT NULL,
  `is_public` tinyint(1) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_volume_types_qos_specs_id` (`qos_specs_id`),
  CONSTRAINT `volume_types_ibfk_1` FOREIGN KEY (`qos_specs_id`) REFERENCES `quality_of_service_specs` (`id`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`deleted` in (0,1)),
  CONSTRAINT `CONSTRAINT_2` CHECK (`is_public` in (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volume_types`
--

LOCK TABLES `volume_types` WRITE;
/*!40000 ALTER TABLE `volume_types` DISABLE KEYS */;
INSERT INTO `volume_types` VALUES ('2019-12-04 03:56:17','2019-12-04 03:56:17',NULL,0,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d','__DEFAULT__',NULL,1,'Default Volume Type'),('2019-12-06 16:08:17',NULL,NULL,0,'9f73ec18-eca5-487d-9ebf-c7cc0811922d','volume_from_ceph',NULL,1,NULL);
/*!40000 ALTER TABLE `volume_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volumes` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `id` varchar(36) NOT NULL,
  `ec2_id` varchar(255) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `host` varchar(255) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `availability_zone` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `attach_status` varchar(255) DEFAULT NULL,
  `scheduled_at` datetime DEFAULT NULL,
  `launched_at` datetime DEFAULT NULL,
  `terminated_at` datetime DEFAULT NULL,
  `display_name` varchar(255) DEFAULT NULL,
  `display_description` varchar(255) DEFAULT NULL,
  `provider_location` varchar(256) DEFAULT NULL,
  `provider_auth` varchar(256) DEFAULT NULL,
  `snapshot_id` varchar(36) DEFAULT NULL,
  `volume_type_id` varchar(36) DEFAULT NULL,
  `source_volid` varchar(36) DEFAULT NULL,
  `bootable` tinyint(1) DEFAULT NULL,
  `provider_geometry` varchar(255) DEFAULT NULL,
  `_name_id` varchar(36) DEFAULT NULL,
  `encryption_key_id` varchar(36) DEFAULT NULL,
  `migration_status` varchar(255) DEFAULT NULL,
  `replication_status` varchar(255) DEFAULT NULL,
  `replication_extended_status` varchar(255) DEFAULT NULL,
  `replication_driver_data` varchar(255) DEFAULT NULL,
  `consistencygroup_id` varchar(36) DEFAULT NULL,
  `provider_id` varchar(255) DEFAULT NULL,
  `multiattach` tinyint(1) DEFAULT NULL,
  `previous_status` varchar(255) DEFAULT NULL,
  `cluster_name` varchar(255) DEFAULT NULL,
  `group_id` varchar(36) DEFAULT NULL,
  `service_uuid` varchar(36) DEFAULT NULL,
  `shared_targets` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `volumes_service_uuid_idx` (`service_uuid`,`deleted`),
  KEY `ix_volumes_consistencygroup_id` (`consistencygroup_id`),
  KEY `ix_volumes_group_id` (`group_id`),
  CONSTRAINT `volumes_ibfk_1` FOREIGN KEY (`consistencygroup_id`) REFERENCES `consistencygroups` (`id`),
  CONSTRAINT `volumes_ibfk_2` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`),
  CONSTRAINT `volumes_ibfk_3` FOREIGN KEY (`service_uuid`) REFERENCES `services` (`uuid`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`deleted` in (0,1)),
  CONSTRAINT `CONSTRAINT_2` CHECK (`bootable` in (0,1)),
  CONSTRAINT `CONSTRAINT_3` CHECK (`multiattach` in (0,1)),
  CONSTRAINT `CONSTRAINT_4` CHECK (`shared_targets` in (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
INSERT INTO `volumes` VALUES ('2019-12-25 07:20:32','2019-12-25 09:55:39',NULL,1,'01aea4a1-b0c5-41fb-b184-2b1d9e8d1a18',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller02@ceph#ceph',40,'nova','1','detached','2019-12-25 07:20:34','2019-12-25 07:22:36','2019-12-25 09:52:47','','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'4c273a2c-2ab7-49f4-bfb1-43d437efef31',0),('2019-12-24 09:58:19','2019-12-24 11:37:08','2019-12-24 11:41:24',1,'02631a95-5721-4d00-bd32-5ba6d03f93f5',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0',NULL,40,'nova','1','detached','2019-12-24 11:37:07',NULL,NULL,'','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,1),('2019-12-27 08:27:13','2019-12-27 08:36:17','2019-12-27 08:36:19',1,'075db1a2-aa5f-4e6e-a68e-3a691dfb74d7',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller02@ceph#ceph',40,'nova','deleted','detached','2019-12-27 08:27:14','2019-12-27 08:33:49','2019-12-27 08:36:17','','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'4c273a2c-2ab7-49f4-bfb1-43d437efef31',0),('2019-12-24 09:51:23','2019-12-24 11:37:09','2019-12-24 11:41:25',1,'08532237-1837-459d-8bcd-4aebb803ffa2',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0',NULL,100,'nova','1','detached','2019-12-24 11:37:09',NULL,NULL,'','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,1),('2019-12-26 09:52:15','2019-12-26 10:10:37','2019-12-26 10:10:39',1,'0f940da7-9b0d-40b3-b62b-9a17157ccb17',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller02@ceph#ceph',40,'nova','1','detached','2019-12-26 09:52:15','2019-12-26 09:56:14','2019-12-26 10:10:37','','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'4c273a2c-2ab7-49f4-bfb1-43d437efef31',0),('2019-12-25 10:07:16',NULL,NULL,1,'27177a1e-ebea-4420-8749-84f55f99abd5',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0',NULL,40,'nova','1','detached',NULL,NULL,NULL,'','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,1),('2019-12-24 11:58:29','2019-12-25 08:32:37','2019-12-25 08:32:38',1,'2d26bdaa-b52f-4505-a4d8-b2074a5355d8',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller01@ceph#ceph',10,'nova','1','detached','2019-12-24 11:58:29','2019-12-24 11:58:34','2019-12-25 08:32:37','','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'cf1d8b24-363c-4865-9ff2-c45c718ecc1c',0),('2019-12-27 08:53:28','2019-12-27 09:01:09',NULL,0,'2dc173b4-996c-4f66-b221-1dcfacd10f3d',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller03@ceph#ceph',40,'nova','in-use','attached','2019-12-27 08:53:29','2019-12-27 09:01:04',NULL,'','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'de32308f-bc2b-41f2-9819-2bd248f2c02d',0),('2019-12-26 09:52:15','2019-12-26 10:10:37','2019-12-26 10:10:39',1,'2e0fad69-854e-452c-ba4b-1f61c6cfd9ea',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller03@ceph#ceph',40,'nova','1','detached','2019-12-26 09:52:16','2019-12-26 10:04:40','2019-12-26 10:10:37','','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'de32308f-bc2b-41f2-9819-2bd248f2c02d',0),('2019-12-24 10:27:02','2019-12-24 11:37:09','2019-12-24 11:41:24',1,'30d35d98-9a9d-41be-a88c-7a7a72a2830b',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0',NULL,10,'nova','1','detached','2019-12-24 11:37:08',NULL,NULL,'','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,1),('2019-12-27 08:27:11','2019-12-27 08:36:17','2019-12-27 08:36:20',1,'3207c63a-674c-4edd-9602-131bd257550e',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller01@ceph#ceph',40,'nova','deleted','detached','2019-12-27 08:27:11','2019-12-27 08:34:49','2019-12-27 08:36:17','','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'cf1d8b24-363c-4865-9ff2-c45c718ecc1c',0),('2019-12-24 11:59:28','2019-12-27 10:16:38','2019-12-27 10:16:38',1,'3f96d033-5734-467b-9777-7d85f80933b7',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller01@ceph#ceph',40,'nova','deleted','detached','2019-12-24 11:59:28','2019-12-24 11:59:53','2019-12-27 10:16:38','','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'cf1d8b24-363c-4865-9ff2-c45c718ecc1c',0),('2019-12-27 08:27:14','2019-12-27 08:36:16','2019-12-27 08:36:19',1,'3fb02922-30ae-4391-935a-93e3e3618787',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller01@ceph#ceph',40,'nova','deleted','detached','2019-12-27 08:27:15','2019-12-27 08:34:49','2019-12-27 08:36:16','','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'cf1d8b24-363c-4865-9ff2-c45c718ecc1c',0),('2019-12-27 08:53:28','2019-12-27 09:01:08',NULL,0,'418ef8f2-c31f-4b9f-a570-98679812e5bf',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller03@ceph#ceph',40,'nova','in-use','attached','2019-12-27 08:53:28','2019-12-27 09:01:04',NULL,'','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'de32308f-bc2b-41f2-9819-2bd248f2c02d',0),('2019-12-26 09:52:12','2019-12-26 10:10:37','2019-12-26 10:10:40',1,'4719f59f-a9c4-4f66-863d-651c58805883',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller03@ceph#ceph',40,'nova','1','detached','2019-12-26 09:52:12','2019-12-26 10:04:40','2019-12-26 10:10:37','','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'de32308f-bc2b-41f2-9819-2bd248f2c02d',0),('2019-12-26 09:52:13','2019-12-26 10:10:37','2019-12-26 10:10:39',1,'50e482f2-0997-44dc-b244-3de18185146c',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller03@ceph#ceph',40,'nova','1','detached','2019-12-26 09:52:14',NULL,'2019-12-26 10:10:37','','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,1),('2019-12-27 08:53:27','2019-12-27 09:01:46',NULL,0,'526de067-9664-459e-b973-f03990d85147',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller01@ceph#ceph',40,'nova','in-use','attached','2019-12-27 08:53:28','2019-12-27 09:01:43',NULL,'','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'cf1d8b24-363c-4865-9ff2-c45c718ecc1c',0),('2019-12-26 03:30:04','2019-12-27 02:29:36','2019-12-27 02:29:37',1,'55976623-d1fe-4370-8aa5-7e6d9234fffa',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller03@ceph#ceph',40,'nova','1','detached','2019-12-26 03:30:05','2019-12-26 03:32:14','2019-12-27 02:29:36','','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'de32308f-bc2b-41f2-9819-2bd248f2c02d',0),('2019-12-27 08:27:13','2019-12-27 08:36:16','2019-12-27 08:36:19',1,'5714a593-89db-4d93-9b3c-b4e58e78e4ca',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller03@ceph#ceph',40,'nova','deleted','detached','2019-12-27 08:27:13','2019-12-27 08:33:51','2019-12-27 08:36:16','','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'de32308f-bc2b-41f2-9819-2bd248f2c02d',0),('2019-12-27 08:27:11','2019-12-27 08:36:17','2019-12-27 08:36:20',1,'583b15a2-8447-4420-b598-2f9db6a6eadf',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller01@ceph#ceph',40,'nova','deleted','detached','2019-12-27 08:27:12','2019-12-27 08:34:49','2019-12-27 08:36:17','','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'cf1d8b24-363c-4865-9ff2-c45c718ecc1c',0),('2019-12-27 08:27:12','2019-12-27 08:36:17','2019-12-27 08:36:19',1,'5bb083b9-68fc-4fdd-b810-28fabbc8246a',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller03@ceph#ceph',40,'nova','deleted','detached','2019-12-27 08:27:13','2019-12-27 08:33:51','2019-12-27 08:36:17','','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'de32308f-bc2b-41f2-9819-2bd248f2c02d',0),('2019-12-27 08:53:27','2019-12-27 09:01:46',NULL,0,'625c33db-3326-456e-accc-080f46ebba5d',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller01@ceph#ceph',40,'nova','in-use','attached','2019-12-27 08:53:28','2019-12-27 09:01:43',NULL,'','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'cf1d8b24-363c-4865-9ff2-c45c718ecc1c',0),('2019-12-24 11:42:09','2019-12-25 09:50:47',NULL,1,'62ffb3fe-1bb6-4837-af63-833641330dd1',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller01@ceph#ceph',10,'nova','1','detached','2019-12-24 11:42:09','2019-12-24 11:42:13','2019-12-25 08:32:37','','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'cf1d8b24-363c-4865-9ff2-c45c718ecc1c',0),('2019-12-24 10:14:14','2019-12-24 11:37:09','2019-12-24 11:41:24',1,'63c2058f-8cee-4f9b-bc57-568ea24d74d5',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0',NULL,10,'nova','1','detached','2019-12-24 11:37:08',NULL,NULL,'','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,1),('2019-12-27 08:27:12','2019-12-27 08:36:17','2019-12-27 08:36:19',1,'68f2ab0a-5517-416d-af2a-44fe2ad923ed',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller03@ceph#ceph',40,'nova','deleted','detached','2019-12-27 08:27:12','2019-12-27 08:33:51','2019-12-27 08:36:17','','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'de32308f-bc2b-41f2-9819-2bd248f2c02d',0),('2019-12-26 09:52:10','2019-12-26 10:10:38','2019-12-26 10:10:40',1,'6a8ba377-1d60-4b6d-9b2e-9770090c59a9',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller01@ceph#ceph',40,'nova','1','detached','2019-12-26 09:52:11','2019-12-26 10:04:08','2019-12-26 10:10:38','','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'cf1d8b24-363c-4865-9ff2-c45c718ecc1c',0),('2019-12-25 10:14:07',NULL,NULL,1,'6c71c6ef-f0b7-4b7a-8d7f-590d148781d0',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0',NULL,10,'nova','1','detached',NULL,NULL,NULL,'','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,1),('2019-12-26 09:52:16','2019-12-26 10:04:42','2019-12-26 10:04:46',1,'77dd9637-e608-46a3-9d06-f6b031c0b60b',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller03@ceph#ceph',40,'nova','1','detached','2019-12-26 09:52:16','2019-12-26 10:04:42','2019-12-26 10:04:13','','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'de32308f-bc2b-41f2-9819-2bd248f2c02d',0),('2019-12-26 09:52:13','2019-12-26 10:10:37','2019-12-26 10:10:39',1,'7a28cd3d-ef34-4d34-8d0f-b8f0abd3e93c',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller02@ceph#ceph',40,'nova','1','detached','2019-12-26 09:52:14','2019-12-26 09:56:14','2019-12-26 10:10:37','','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'4c273a2c-2ab7-49f4-bfb1-43d437efef31',0),('2019-12-24 10:04:25','2019-12-24 11:37:09','2019-12-24 11:41:24',1,'803a4c2b-b2d1-4a2c-bd3e-0b505675ee9e',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0',NULL,10,'nova','1','detached','2019-12-24 11:37:08',NULL,NULL,'','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,1),('2019-12-26 09:52:10','2019-12-26 10:10:37','2019-12-26 10:10:40',1,'8b9cf4ea-ee8d-439b-9065-57605d92bedd',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller01@ceph#ceph',40,'nova','1','detached','2019-12-26 09:52:11','2019-12-26 10:04:08','2019-12-26 10:10:37','','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'cf1d8b24-363c-4865-9ff2-c45c718ecc1c',0),('2019-12-27 08:53:28','2019-12-27 09:01:07',NULL,0,'8be45146-a7e7-4d43-b368-b8c18e6fcbbb',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller03@ceph#ceph',40,'nova','in-use','attached','2019-12-27 08:53:29','2019-12-27 09:01:04',NULL,'','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'de32308f-bc2b-41f2-9819-2bd248f2c02d',0),('2019-12-27 08:53:27','2019-12-27 09:01:45',NULL,0,'92365e82-3632-4469-b67d-69e6115c6944',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller01@ceph#ceph',40,'nova','in-use','attached','2019-12-27 08:53:27','2019-12-27 09:01:43',NULL,'','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'cf1d8b24-363c-4865-9ff2-c45c718ecc1c',0),('2019-12-27 08:53:30','2019-12-27 09:01:06',NULL,0,'9396d79a-4a8e-45f9-907d-b30ba6299c5f',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller02@ceph#ceph',40,'nova','in-use','attached','2019-12-27 08:53:30','2019-12-27 09:00:59',NULL,'','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'4c273a2c-2ab7-49f4-bfb1-43d437efef31',0),('2019-12-24 11:50:48','2019-12-25 09:51:07',NULL,1,'93f9710f-3de5-4c26-bed3-4c827308c5ad',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller01@ceph#ceph',10,'nova','1','detached','2019-12-24 11:50:48','2019-12-24 11:50:53','2019-12-25 08:32:37','','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'cf1d8b24-363c-4865-9ff2-c45c718ecc1c',0),('2019-12-26 09:52:13','2019-12-26 10:10:37','2019-12-26 10:10:39',1,'95ca280b-54ec-4e81-b2d1-3b4255b6dfc9',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller03@ceph#ceph',40,'nova','1','detached','2019-12-26 09:52:14','2019-12-26 10:04:40','2019-12-26 10:10:37','','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'de32308f-bc2b-41f2-9819-2bd248f2c02d',0),('2019-12-25 03:04:02','2019-12-25 07:12:45','2019-12-25 07:12:47',1,'99afd14f-9028-4d77-bf9f-3c12ac9a1df2',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller01@ceph#ceph',40,'nova','1','detached','2019-12-25 03:04:02','2019-12-25 03:04:03','2019-12-25 07:12:45','base-centos','',NULL,NULL,'a37e1787-05f1-4d9a-b8d3-09f1db015f14','6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'cf1d8b24-363c-4865-9ff2-c45c718ecc1c',0),('2019-12-27 08:27:11','2019-12-27 08:36:17','2019-12-27 08:36:19',1,'ac311be4-b288-4d7a-8abf-fc0b823460e5',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller01@ceph#ceph',40,'nova','deleted','detached','2019-12-27 08:27:11','2019-12-27 08:34:51','2019-12-27 08:36:17','','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'cf1d8b24-363c-4865-9ff2-c45c718ecc1c',0),('2019-12-24 11:54:56','2019-12-25 09:51:18',NULL,1,'b225b36d-6434-4e89-b302-2de775754069',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller01@ceph#ceph',10,'nova','1','detached','2019-12-24 11:54:56','2019-12-24 11:55:00','2019-12-25 08:32:37','','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'cf1d8b24-363c-4865-9ff2-c45c718ecc1c',0),('2019-12-06 16:07:49','2019-12-27 10:17:57','2019-12-27 10:17:57',1,'b62ce1aa-5172-4b58-bb12-c0d99ee0d7f0',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller01@ceph#ceph',2,'nova','deleted','detached','2019-12-06 16:07:49','2019-12-06 16:07:51','2019-12-27 10:17:57','volume_test_0612','after integrate CEPH',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'cf1d8b24-363c-4865-9ff2-c45c718ecc1c',0),('2019-12-27 08:27:14','2019-12-27 08:36:16','2019-12-27 08:36:19',1,'b6fd5119-6d56-4705-91da-f78448569780',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller02@ceph#ceph',40,'nova','deleted','detached','2019-12-27 08:27:14','2019-12-27 08:33:48','2019-12-27 08:36:16','','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'4c273a2c-2ab7-49f4-bfb1-43d437efef31',0),('2019-12-24 09:56:02','2019-12-24 11:37:09','2019-12-24 11:41:24',1,'c9ccd3a2-86bf-4f2b-a088-772217a89c35',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0',NULL,100,'nova','1','detached','2019-12-24 11:37:09',NULL,NULL,'','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,1),('2019-12-27 08:53:30','2019-12-27 09:01:45',NULL,0,'c9dbc7bb-c6c6-483a-80e9-6796f47f2f03',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller01@ceph#ceph',40,'nova','in-use','attached','2019-12-27 08:53:31','2019-12-27 09:01:43',NULL,'','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'cf1d8b24-363c-4865-9ff2-c45c718ecc1c',0),('2019-12-27 08:27:14','2019-12-27 08:36:16','2019-12-27 08:36:19',1,'ceed9274-ba03-4575-bbfe-a98e7940bdc0',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller02@ceph#ceph',40,'nova','deleted','detached','2019-12-27 08:27:14','2019-12-27 08:33:49','2019-12-27 08:36:16','','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'4c273a2c-2ab7-49f4-bfb1-43d437efef31',0),('2019-12-06 16:20:47','2019-12-25 09:51:32',NULL,1,'d2806e0b-a6f3-49eb-b805-f0c68963de1c',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller01@ceph#ceph',10,'nova','1','detached','2019-12-06 16:20:47','2019-12-06 16:20:51','2019-12-25 08:32:38','','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'cf1d8b24-363c-4865-9ff2-c45c718ecc1c',0),('2019-12-25 02:41:54','2019-12-25 08:32:37','2019-12-25 08:32:41',1,'d47ce62a-91a9-4876-8907-b601d19d69b8',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller01@ceph#ceph',100,'nova','1','detached','2019-12-25 02:41:54',NULL,'2019-12-25 08:32:37','','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,1),('2019-12-24 11:20:14','2019-12-24 11:41:24','2019-12-24 11:41:24',1,'d7793fc9-2fcc-4253-97ad-93372dd336f2',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller01@ceph#ceph',10,'nova','1','detached','2019-12-24 11:37:04','2019-12-24 11:37:05','2019-12-24 11:41:24','volume-test-after-integrate-2',NULL,NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'cf1d8b24-363c-4865-9ff2-c45c718ecc1c',0),('2019-12-24 09:51:24','2019-12-24 11:37:09','2019-12-24 11:41:25',1,'dc8f7150-698a-4c6c-beff-e89dab0fb8e7',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0',NULL,40,'nova','1','detached','2019-12-24 11:37:09',NULL,NULL,'','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,1),('2019-12-27 08:53:29','2019-12-27 09:01:05',NULL,0,'e3e4ebfd-4da1-4c1f-b79f-6071a02816ef',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller02@ceph#ceph',40,'nova','in-use','attached','2019-12-27 08:53:30','2019-12-27 09:01:01',NULL,'','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'4c273a2c-2ab7-49f4-bfb1-43d437efef31',0),('2019-12-26 09:52:12','2019-12-26 10:10:37','2019-12-26 10:10:40',1,'f41e0be3-a7e3-41b1-9307-048c29f1077c',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller01@ceph#ceph',40,'nova','1','detached','2019-12-26 09:52:12','2019-12-26 10:04:08','2019-12-26 10:10:37','','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'cf1d8b24-363c-4865-9ff2-c45c718ecc1c',0),('2019-12-27 08:53:30','2019-12-27 09:01:05',NULL,0,'f76a0505-f942-4cd4-82ce-6cef82279616',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller02@ceph#ceph',40,'nova','in-use','attached','2019-12-27 08:53:31','2019-12-27 09:01:00',NULL,'','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'4c273a2c-2ab7-49f4-bfb1-43d437efef31',0),('2019-12-24 11:47:20','2019-12-25 09:51:43',NULL,1,'fae19897-e732-43fc-a73f-21f971de7173',NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','controller01@ceph#ceph',10,'nova','1','detached','2019-12-24 11:47:20','2019-12-24 11:47:25','2019-12-25 08:32:37','','',NULL,NULL,NULL,'6c5d6205-bfa0-4fb7-b2d6-fda7fa33f94d',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'cf1d8b24-363c-4865-9ff2-c45c718ecc1c',0);
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workers`
--

DROP TABLE IF EXISTS `workers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workers` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resource_type` varchar(40) NOT NULL,
  `resource_id` varchar(36) NOT NULL,
  `status` varchar(255) NOT NULL,
  `service_id` int(11) DEFAULT NULL,
  `race_preventer` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `resource_type` (`resource_type`,`resource_id`),
  KEY `ix_workers_service_id` (`service_id`),
  CONSTRAINT `workers_ibfk_1` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`deleted` in (0,1))
) ENGINE=InnoDB AUTO_INCREMENT=319 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workers`
--

LOCK TABLES `workers` WRITE;
/*!40000 ALTER TABLE `workers` DISABLE KEYS */;
INSERT INTO `workers` VALUES ('2019-12-04 03:56:17','2019-12-04 03:56:17.000123',NULL,0,1,'SENTINEL','SUB-SECOND','OK',NULL,0),('2019-12-25 08:32:37','2019-12-25 08:32:37.667215',NULL,0,141,'Volume','b225b36d-6434-4e89-b302-2de775754069','deleting',NULL,0),('2019-12-25 08:32:37','2019-12-25 08:32:37.766230',NULL,0,144,'Volume','93f9710f-3de5-4c26-bed3-4c827308c5ad','deleting',NULL,0),('2019-12-25 08:32:37','2019-12-25 08:32:37.857971',NULL,0,147,'Volume','fae19897-e732-43fc-a73f-21f971de7173','deleting',NULL,0),('2019-12-25 08:32:37','2019-12-25 08:32:37.948678',NULL,0,150,'Volume','62ffb3fe-1bb6-4837-af63-833641330dd1','deleting',NULL,0),('2019-12-25 08:32:38','2019-12-25 08:32:38.046593',NULL,0,153,'Volume','d2806e0b-a6f3-49eb-b805-f0c68963de1c','deleting',NULL,0);
/*!40000 ALTER TABLE `workers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-30  0:00:01
