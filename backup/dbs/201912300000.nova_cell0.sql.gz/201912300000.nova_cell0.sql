-- MariaDB dump 10.17  Distrib 10.4.10-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: nova_cell0
-- ------------------------------------------------------
-- Server version	10.4.10-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `nova_cell0`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `nova_cell0` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `nova_cell0`;

--
-- Table structure for table `agent_builds`
--

DROP TABLE IF EXISTS `agent_builds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agent_builds` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hypervisor` varchar(255) DEFAULT NULL,
  `os` varchar(255) DEFAULT NULL,
  `architecture` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `md5hash` varchar(255) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_agent_builds0hypervisor0os0architecture0deleted` (`hypervisor`,`os`,`architecture`,`deleted`),
  KEY `agent_builds_hypervisor_os_arch_idx` (`hypervisor`,`os`,`architecture`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_builds`
--

LOCK TABLES `agent_builds` WRITE;
/*!40000 ALTER TABLE `agent_builds` DISABLE KEYS */;
/*!40000 ALTER TABLE `agent_builds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aggregate_hosts`
--

DROP TABLE IF EXISTS `aggregate_hosts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aggregate_hosts` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `host` varchar(255) DEFAULT NULL,
  `aggregate_id` int(11) NOT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_aggregate_hosts0host0aggregate_id0deleted` (`host`,`aggregate_id`,`deleted`),
  KEY `aggregate_id` (`aggregate_id`),
  CONSTRAINT `aggregate_hosts_ibfk_1` FOREIGN KEY (`aggregate_id`) REFERENCES `aggregates` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aggregate_hosts`
--

LOCK TABLES `aggregate_hosts` WRITE;
/*!40000 ALTER TABLE `aggregate_hosts` DISABLE KEYS */;
/*!40000 ALTER TABLE `aggregate_hosts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aggregate_metadata`
--

DROP TABLE IF EXISTS `aggregate_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aggregate_metadata` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aggregate_id` int(11) NOT NULL,
  `key` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_aggregate_metadata0aggregate_id0key0deleted` (`aggregate_id`,`key`,`deleted`),
  KEY `aggregate_metadata_key_idx` (`key`),
  KEY `aggregate_metadata_value_idx` (`value`),
  CONSTRAINT `aggregate_metadata_ibfk_1` FOREIGN KEY (`aggregate_id`) REFERENCES `aggregates` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aggregate_metadata`
--

LOCK TABLES `aggregate_metadata` WRITE;
/*!40000 ALTER TABLE `aggregate_metadata` DISABLE KEYS */;
/*!40000 ALTER TABLE `aggregate_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aggregates`
--

DROP TABLE IF EXISTS `aggregates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aggregates` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `uuid` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `aggregate_uuid_idx` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aggregates`
--

LOCK TABLES `aggregates` WRITE;
/*!40000 ALTER TABLE `aggregates` DISABLE KEYS */;
/*!40000 ALTER TABLE `aggregates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `allocations`
--

DROP TABLE IF EXISTS `allocations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `allocations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resource_provider_id` int(11) NOT NULL,
  `consumer_id` varchar(36) NOT NULL,
  `resource_class_id` int(11) NOT NULL,
  `used` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `allocations_consumer_id_idx` (`consumer_id`),
  KEY `allocations_resource_class_id_idx` (`resource_class_id`),
  KEY `allocations_resource_provider_class_used_idx` (`resource_provider_id`,`resource_class_id`,`used`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `allocations`
--

LOCK TABLES `allocations` WRITE;
/*!40000 ALTER TABLE `allocations` DISABLE KEYS */;
/*!40000 ALTER TABLE `allocations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `block_device_mapping`
--

DROP TABLE IF EXISTS `block_device_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `block_device_mapping` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_name` varchar(255) DEFAULT NULL,
  `delete_on_termination` tinyint(1) DEFAULT NULL,
  `snapshot_id` varchar(36) DEFAULT NULL,
  `volume_id` varchar(36) DEFAULT NULL,
  `volume_size` int(11) DEFAULT NULL,
  `no_device` tinyint(1) DEFAULT NULL,
  `connection_info` mediumtext DEFAULT NULL,
  `instance_uuid` varchar(36) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `source_type` varchar(255) DEFAULT NULL,
  `destination_type` varchar(255) DEFAULT NULL,
  `guest_format` varchar(255) DEFAULT NULL,
  `device_type` varchar(255) DEFAULT NULL,
  `disk_bus` varchar(255) DEFAULT NULL,
  `boot_index` int(11) DEFAULT NULL,
  `image_id` varchar(36) DEFAULT NULL,
  `tag` varchar(255) DEFAULT NULL,
  `attachment_id` varchar(36) DEFAULT NULL,
  `uuid` varchar(36) DEFAULT NULL,
  `volume_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_block_device_mapping0uuid` (`uuid`),
  KEY `snapshot_id` (`snapshot_id`),
  KEY `volume_id` (`volume_id`),
  KEY `block_device_mapping_instance_uuid_idx` (`instance_uuid`),
  KEY `block_device_mapping_instance_uuid_device_name_idx` (`instance_uuid`,`device_name`),
  KEY `block_device_mapping_instance_uuid_volume_id_idx` (`instance_uuid`,`volume_id`),
  CONSTRAINT `block_device_mapping_instance_uuid_fkey` FOREIGN KEY (`instance_uuid`) REFERENCES `instances` (`uuid`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`delete_on_termination` in (0,1)),
  CONSTRAINT `CONSTRAINT_2` CHECK (`no_device` in (0,1))
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `block_device_mapping`
--

LOCK TABLES `block_device_mapping` WRITE;
/*!40000 ALTER TABLE `block_device_mapping` DISABLE KEYS */;
INSERT INTO `block_device_mapping` VALUES ('2019-12-25 03:12:55',NULL,'2019-12-25 03:23:04',3,NULL,1,NULL,NULL,NULL,0,NULL,'1c4bd9e1-1e4b-4a25-b1a7-9eb58076edd3',3,'image','local',NULL,'disk',NULL,0,'4246efca-c550-48f8-aa0e-7a368df98da6',NULL,NULL,'f1415a2a-8f8e-4882-8310-063b12612ccc',NULL),('2019-12-25 08:30:04',NULL,'2019-12-25 08:30:59',6,NULL,0,NULL,NULL,60,0,NULL,'c4d322a8-26a3-4768-8f62-2445471fbe71',6,'image','volume',NULL,NULL,NULL,0,'e8a9d0c4-bbfb-4f67-a445-46e1bae3809f',NULL,NULL,'164841e9-f4e9-45e4-944e-ec20d9cd1044',NULL),('2019-12-25 08:44:19',NULL,'2019-12-25 09:01:08',9,NULL,0,NULL,NULL,40,0,NULL,'571c378c-b250-4b18-a00e-cc71c79d8d95',9,'image','volume',NULL,NULL,NULL,0,'e8a9d0c4-bbfb-4f67-a445-46e1bae3809f',NULL,NULL,'dcb1bc9c-3d61-4b21-85c2-d4b37d732e44',NULL),('2019-12-25 08:51:22',NULL,'2019-12-25 09:01:06',12,NULL,1,NULL,NULL,NULL,0,NULL,'ae77ef6c-9ca5-497b-92c0-d4bfcb29ccdf',12,'image','local',NULL,'disk',NULL,0,'4246efca-c550-48f8-aa0e-7a368df98da6',NULL,NULL,'3169e46c-841d-412d-aa51-a23e4b88859e',NULL),('2019-12-25 10:20:35',NULL,'2019-12-25 11:01:17',15,NULL,1,NULL,NULL,NULL,0,NULL,'5f6ee10e-4a04-4a19-8199-5d4b458048a5',15,'image','local',NULL,'disk',NULL,0,'5ee759d1-e9e3-4bda-a9c6-50bcfe5cc355',NULL,NULL,'8b6330be-e30c-449d-8d35-d5d4f3245c80',NULL),('2019-12-25 10:22:26',NULL,'2019-12-25 11:01:16',18,NULL,1,NULL,NULL,NULL,0,NULL,'886c28dc-a479-4573-ad77-fdcc201be823',18,'image','local',NULL,'disk',NULL,0,'5ee759d1-e9e3-4bda-a9c6-50bcfe5cc355',NULL,NULL,'1c648007-5054-4c29-93ef-9d125db94214',NULL),('2019-12-25 10:32:26',NULL,'2019-12-25 11:01:15',21,NULL,1,NULL,NULL,NULL,0,NULL,'2dea7cba-4024-41b5-9302-9ac7345384aa',21,'image','local',NULL,'disk',NULL,0,'5ee759d1-e9e3-4bda-a9c6-50bcfe5cc355',NULL,NULL,'648cbae6-b545-4ecd-9c15-7ec8f2ee17f1',NULL),('2019-12-25 11:00:06',NULL,'2019-12-25 11:01:14',24,NULL,1,NULL,NULL,NULL,0,NULL,'7a8aee11-c444-49d4-a97b-cd4a42104932',24,'image','local',NULL,'disk',NULL,0,'5ee759d1-e9e3-4bda-a9c6-50bcfe5cc355',NULL,NULL,'3d482009-904d-461d-8368-020719546700',NULL),('2019-12-25 11:33:53',NULL,'2019-12-26 02:40:15',27,NULL,1,NULL,NULL,NULL,0,NULL,'a8ce01ca-c34e-45c1-bd48-09e95666a776',27,'image','local',NULL,'disk',NULL,0,'5ee759d1-e9e3-4bda-a9c6-50bcfe5cc355',NULL,NULL,'20226fba-ede7-4a8d-886a-891fc6188147',NULL),('2019-12-26 02:12:11',NULL,'2019-12-26 02:40:13',30,NULL,1,NULL,NULL,NULL,0,NULL,'57320b78-98c3-43b0-8170-87007ada0c6d',30,'image','local',NULL,'disk',NULL,0,'5ee759d1-e9e3-4bda-a9c6-50bcfe5cc355',NULL,NULL,'72bdb73f-ddf4-487d-a77a-dace0801d512',NULL),('2019-12-26 02:57:20',NULL,'2019-12-26 03:04:41',33,NULL,1,NULL,NULL,NULL,0,NULL,'d73201b6-62d3-4260-99ed-0e20374178bc',33,'image','local',NULL,'disk',NULL,0,'5ee759d1-e9e3-4bda-a9c6-50bcfe5cc355',NULL,NULL,'716bab9c-7529-4862-8aef-cca6b4c02b2d',NULL),('2019-12-26 09:37:47',NULL,'2019-12-27 02:19:02',36,NULL,1,NULL,NULL,NULL,0,NULL,'26a41a6e-7da0-43b0-8ad1-54b6bdba8d39',36,'image','local',NULL,'disk',NULL,0,'5ee759d1-e9e3-4bda-a9c6-50bcfe5cc355',NULL,NULL,'ecc83f64-d1e5-4b1f-af64-8014b1146c40',NULL);
/*!40000 ALTER TABLE `block_device_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bw_usage_cache`
--

DROP TABLE IF EXISTS `bw_usage_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bw_usage_cache` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `start_period` datetime NOT NULL,
  `last_refreshed` datetime DEFAULT NULL,
  `bw_in` bigint(20) DEFAULT NULL,
  `bw_out` bigint(20) DEFAULT NULL,
  `mac` varchar(255) DEFAULT NULL,
  `uuid` varchar(36) DEFAULT NULL,
  `last_ctr_in` bigint(20) DEFAULT NULL,
  `last_ctr_out` bigint(20) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `bw_usage_cache_uuid_start_period_idx` (`uuid`,`start_period`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bw_usage_cache`
--

LOCK TABLES `bw_usage_cache` WRITE;
/*!40000 ALTER TABLE `bw_usage_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `bw_usage_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cells`
--

DROP TABLE IF EXISTS `cells`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cells` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `api_url` varchar(255) DEFAULT NULL,
  `weight_offset` float DEFAULT NULL,
  `weight_scale` float DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `is_parent` tinyint(1) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `transport_url` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_cells0name0deleted` (`name`,`deleted`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`is_parent` in (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cells`
--

LOCK TABLES `cells` WRITE;
/*!40000 ALTER TABLE `cells` DISABLE KEYS */;
/*!40000 ALTER TABLE `cells` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `certificates`
--

DROP TABLE IF EXISTS `certificates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `certificates` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(255) DEFAULT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `certificates_project_id_deleted_idx` (`project_id`,`deleted`),
  KEY `certificates_user_id_deleted_idx` (`user_id`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `certificates`
--

LOCK TABLES `certificates` WRITE;
/*!40000 ALTER TABLE `certificates` DISABLE KEYS */;
/*!40000 ALTER TABLE `certificates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `compute_nodes`
--

DROP TABLE IF EXISTS `compute_nodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `compute_nodes` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_id` int(11) DEFAULT NULL,
  `vcpus` int(11) NOT NULL,
  `memory_mb` int(11) NOT NULL,
  `local_gb` int(11) NOT NULL,
  `vcpus_used` int(11) NOT NULL,
  `memory_mb_used` int(11) NOT NULL,
  `local_gb_used` int(11) NOT NULL,
  `hypervisor_type` mediumtext NOT NULL,
  `hypervisor_version` int(11) NOT NULL,
  `cpu_info` mediumtext NOT NULL,
  `disk_available_least` int(11) DEFAULT NULL,
  `free_ram_mb` int(11) DEFAULT NULL,
  `free_disk_gb` int(11) DEFAULT NULL,
  `current_workload` int(11) DEFAULT NULL,
  `running_vms` int(11) DEFAULT NULL,
  `hypervisor_hostname` varchar(255) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `host_ip` varchar(39) DEFAULT NULL,
  `supported_instances` text DEFAULT NULL,
  `pci_stats` text DEFAULT NULL,
  `metrics` text DEFAULT NULL,
  `extra_resources` text DEFAULT NULL,
  `stats` text DEFAULT NULL,
  `numa_topology` text DEFAULT NULL,
  `host` varchar(255) DEFAULT NULL,
  `ram_allocation_ratio` float DEFAULT NULL,
  `cpu_allocation_ratio` float DEFAULT NULL,
  `uuid` varchar(36) DEFAULT NULL,
  `disk_allocation_ratio` float DEFAULT NULL,
  `mapped` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_compute_nodes0host0hypervisor_hostname0deleted` (`host`,`hypervisor_hostname`,`deleted`),
  UNIQUE KEY `compute_nodes_uuid_idx` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compute_nodes`
--

LOCK TABLES `compute_nodes` WRITE;
/*!40000 ALTER TABLE `compute_nodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `compute_nodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `console_auth_tokens`
--

DROP TABLE IF EXISTS `console_auth_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `console_auth_tokens` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token_hash` varchar(255) NOT NULL,
  `console_type` varchar(255) NOT NULL,
  `host` varchar(255) NOT NULL,
  `port` int(11) NOT NULL,
  `internal_access_path` varchar(255) DEFAULT NULL,
  `instance_uuid` varchar(36) NOT NULL,
  `expires` int(11) NOT NULL,
  `access_url_base` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_console_auth_tokens0token_hash` (`token_hash`),
  KEY `console_auth_tokens_instance_uuid_idx` (`instance_uuid`),
  KEY `console_auth_tokens_host_expires_idx` (`host`,`expires`),
  KEY `console_auth_tokens_token_hash_idx` (`token_hash`),
  KEY `console_auth_tokens_token_hash_instance_uuid_idx` (`token_hash`,`instance_uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `console_auth_tokens`
--

LOCK TABLES `console_auth_tokens` WRITE;
/*!40000 ALTER TABLE `console_auth_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `console_auth_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `console_pools`
--

DROP TABLE IF EXISTS `console_pools`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `console_pools` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `address` varchar(39) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `console_type` varchar(255) DEFAULT NULL,
  `public_hostname` varchar(255) DEFAULT NULL,
  `host` varchar(255) DEFAULT NULL,
  `compute_host` varchar(255) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_console_pools0host0console_type0compute_host0deleted` (`host`,`console_type`,`compute_host`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `console_pools`
--

LOCK TABLES `console_pools` WRITE;
/*!40000 ALTER TABLE `console_pools` DISABLE KEYS */;
/*!40000 ALTER TABLE `console_pools` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consoles`
--

DROP TABLE IF EXISTS `consoles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consoles` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `instance_name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `port` int(11) DEFAULT NULL,
  `pool_id` int(11) DEFAULT NULL,
  `instance_uuid` varchar(36) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pool_id` (`pool_id`),
  KEY `consoles_instance_uuid_idx` (`instance_uuid`),
  CONSTRAINT `consoles_ibfk_1` FOREIGN KEY (`pool_id`) REFERENCES `console_pools` (`id`),
  CONSTRAINT `consoles_instance_uuid_fkey` FOREIGN KEY (`instance_uuid`) REFERENCES `instances` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consoles`
--

LOCK TABLES `consoles` WRITE;
/*!40000 ALTER TABLE `consoles` DISABLE KEYS */;
/*!40000 ALTER TABLE `consoles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dns_domains`
--

DROP TABLE IF EXISTS `dns_domains`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dns_domains` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `domain` varchar(255) NOT NULL,
  `scope` varchar(255) DEFAULT NULL,
  `availability_zone` varchar(255) DEFAULT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`domain`),
  KEY `dns_domains_domain_deleted_idx` (`domain`,`deleted`),
  KEY `dns_domains_project_id_idx` (`project_id`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`deleted` in (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dns_domains`
--

LOCK TABLES `dns_domains` WRITE;
/*!40000 ALTER TABLE `dns_domains` DISABLE KEYS */;
/*!40000 ALTER TABLE `dns_domains` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fixed_ips`
--

DROP TABLE IF EXISTS `fixed_ips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fixed_ips` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `address` varchar(39) DEFAULT NULL,
  `network_id` int(11) DEFAULT NULL,
  `allocated` tinyint(1) DEFAULT NULL,
  `leased` tinyint(1) DEFAULT NULL,
  `reserved` tinyint(1) DEFAULT NULL,
  `virtual_interface_id` int(11) DEFAULT NULL,
  `host` varchar(255) DEFAULT NULL,
  `instance_uuid` varchar(36) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_fixed_ips0address0deleted` (`address`,`deleted`),
  KEY `network_id` (`network_id`),
  KEY `fixed_ips_virtual_interface_id_fkey` (`virtual_interface_id`),
  KEY `address` (`address`),
  KEY `fixed_ips_instance_uuid_fkey` (`instance_uuid`),
  KEY `fixed_ips_host_idx` (`host`),
  KEY `fixed_ips_network_id_host_deleted_idx` (`network_id`,`host`,`deleted`),
  KEY `fixed_ips_address_reserved_network_id_deleted_idx` (`address`,`reserved`,`network_id`,`deleted`),
  KEY `fixed_ips_deleted_allocated_idx` (`address`,`deleted`,`allocated`),
  KEY `fixed_ips_deleted_allocated_updated_at_idx` (`deleted`,`allocated`,`updated_at`),
  CONSTRAINT `fixed_ips_instance_uuid_fkey` FOREIGN KEY (`instance_uuid`) REFERENCES `instances` (`uuid`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`allocated` in (0,1)),
  CONSTRAINT `CONSTRAINT_2` CHECK (`leased` in (0,1)),
  CONSTRAINT `CONSTRAINT_3` CHECK (`reserved` in (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fixed_ips`
--

LOCK TABLES `fixed_ips` WRITE;
/*!40000 ALTER TABLE `fixed_ips` DISABLE KEYS */;
/*!40000 ALTER TABLE `fixed_ips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `floating_ips`
--

DROP TABLE IF EXISTS `floating_ips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `floating_ips` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `address` varchar(39) DEFAULT NULL,
  `fixed_ip_id` int(11) DEFAULT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `host` varchar(255) DEFAULT NULL,
  `auto_assigned` tinyint(1) DEFAULT NULL,
  `pool` varchar(255) DEFAULT NULL,
  `interface` varchar(255) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_floating_ips0address0deleted` (`address`,`deleted`),
  KEY `fixed_ip_id` (`fixed_ip_id`),
  KEY `floating_ips_host_idx` (`host`),
  KEY `floating_ips_project_id_idx` (`project_id`),
  KEY `floating_ips_pool_deleted_fixed_ip_id_project_id_idx` (`pool`,`deleted`,`fixed_ip_id`,`project_id`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`auto_assigned` in (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `floating_ips`
--

LOCK TABLES `floating_ips` WRITE;
/*!40000 ALTER TABLE `floating_ips` DISABLE KEYS */;
/*!40000 ALTER TABLE `floating_ips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instance_actions`
--

DROP TABLE IF EXISTS `instance_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `instance_actions` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action` varchar(255) DEFAULT NULL,
  `instance_uuid` varchar(36) DEFAULT NULL,
  `request_id` varchar(255) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `finish_time` datetime DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `instance_uuid_idx` (`instance_uuid`),
  KEY `request_id_idx` (`request_id`),
  KEY `instance_actions_instance_uuid_updated_at_idx` (`instance_uuid`,`updated_at`),
  CONSTRAINT `fk_instance_actions_instance_uuid` FOREIGN KEY (`instance_uuid`) REFERENCES `instances` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instance_actions`
--

LOCK TABLES `instance_actions` WRITE;
/*!40000 ALTER TABLE `instance_actions` DISABLE KEYS */;
/*!40000 ALTER TABLE `instance_actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instance_actions_events`
--

DROP TABLE IF EXISTS `instance_actions_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `instance_actions_events` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event` varchar(255) DEFAULT NULL,
  `action_id` int(11) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `finish_time` datetime DEFAULT NULL,
  `result` varchar(255) DEFAULT NULL,
  `traceback` text DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `host` varchar(255) DEFAULT NULL,
  `details` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `action_id` (`action_id`),
  CONSTRAINT `instance_actions_events_ibfk_1` FOREIGN KEY (`action_id`) REFERENCES `instance_actions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instance_actions_events`
--

LOCK TABLES `instance_actions_events` WRITE;
/*!40000 ALTER TABLE `instance_actions_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `instance_actions_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instance_extra`
--

DROP TABLE IF EXISTS `instance_extra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `instance_extra` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `instance_uuid` varchar(36) NOT NULL,
  `numa_topology` text DEFAULT NULL,
  `pci_requests` text DEFAULT NULL,
  `flavor` text DEFAULT NULL,
  `vcpu_model` text DEFAULT NULL,
  `migration_context` text DEFAULT NULL,
  `keypairs` text DEFAULT NULL,
  `device_metadata` text DEFAULT NULL,
  `trusted_certs` text DEFAULT NULL,
  `vpmems` text DEFAULT NULL,
  `resources` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `instance_extra_idx` (`instance_uuid`),
  CONSTRAINT `instance_extra_instance_uuid_fkey` FOREIGN KEY (`instance_uuid`) REFERENCES `instances` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instance_extra`
--

LOCK TABLES `instance_extra` WRITE;
/*!40000 ALTER TABLE `instance_extra` DISABLE KEYS */;
INSERT INTO `instance_extra` VALUES ('2019-12-25 03:12:55',NULL,'2019-12-25 03:23:05',3,3,'1c4bd9e1-1e4b-4a25-b1a7-9eb58076edd3',NULL,'[]','{\"new\": null, \"old\": null, \"cur\": {\"nova_object.version\": \"1.2\", \"nova_object.name\": \"Flavor\", \"nova_object.data\": {\"disabled\": false, \"root_gb\": 40, \"description\": null, \"flavorid\": \"1\", \"deleted\": false, \"created_at\": \"2019-12-24T09:39:51Z\", \"ephemeral_gb\": 0, \"updated_at\": null, \"memory_mb\": 4096, \"vcpus\": 4, \"extra_specs\": {}, \"swap\": 0, \"rxtx_factor\": 1.0, \"is_public\": true, \"deleted_at\": null, \"vcpu_weight\": 0, \"id\": 3, \"name\": \"goi1\"}, \"nova_object.namespace\": \"nova\"}}',NULL,NULL,'{\"nova_object.version\": \"1.3\", \"nova_object.name\": \"KeyPairList\", \"nova_object.data\": {\"objects\": [{\"nova_object.version\": \"1.4\", \"nova_object.name\": \"KeyPair\", \"nova_object.data\": {\"public_key\": \"ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDCvkVwCj0HsRBuORHdiLSUYLX+smlUj/vM8N4aLCJhiR83FvA6P5845Vslb5pYvBi/+6NnHxeh1SMV6uYtJ6jMpo7UjmdBKw+N14G+8ZMepmTpMNQpX9pLmlb3LuMju/rJmpzH4li2/VNmeZf/ls23FDJjRx0cLoyif+u1S7CHoFn2KPGYqr64tP+FYlUwVXJwVZsJS79x1OUNzZEg49DmYHDKUW/jNLsJpzIGCMVf2e6czKOhOBhYjUzxRmwkv0aFtOSVRBjm4h+DcisTCV5LO2X8Z1ij0bqM2f++x7x8vtZJY2olSUGW90z0mHFkRyVAsmAdoJzdidi1XukJ7n8j root@controller01\\n\", \"user_id\": \"871c3da4707d4524af705b7eff6e34a2\", \"name\": \"key1\", \"deleted\": false, \"created_at\": \"2019-12-24T09:24:57Z\", \"updated_at\": null, \"fingerprint\": \"31:a5:c8:12:63:3a:61:d8:9c:a4:30:24:74:5d:6d:40\", \"deleted_at\": null, \"type\": \"ssh\", \"id\": 3}, \"nova_object.namespace\": \"nova\"}]}, \"nova_object.namespace\": \"nova\"}',NULL,NULL,NULL,NULL),('2019-12-25 08:30:04',NULL,'2019-12-25 08:31:01',6,6,'c4d322a8-26a3-4768-8f62-2445471fbe71',NULL,'[]','{\"new\": null, \"old\": null, \"cur\": {\"nova_object.version\": \"1.2\", \"nova_object.name\": \"Flavor\", \"nova_object.data\": {\"disabled\": false, \"root_gb\": 60, \"description\": null, \"flavorid\": \"2\", \"deleted\": false, \"created_at\": \"2019-12-24T09:39:53Z\", \"ephemeral_gb\": 0, \"updated_at\": null, \"memory_mb\": 6144, \"vcpus\": 4, \"extra_specs\": {}, \"swap\": 0, \"rxtx_factor\": 1.0, \"is_public\": true, \"deleted_at\": null, \"vcpu_weight\": 0, \"id\": 6, \"name\": \"goi2\"}, \"nova_object.namespace\": \"nova\"}}',NULL,NULL,'{\"nova_object.version\": \"1.3\", \"nova_object.name\": \"KeyPairList\", \"nova_object.data\": {\"objects\": [{\"nova_object.version\": \"1.4\", \"nova_object.name\": \"KeyPair\", \"nova_object.data\": {\"public_key\": \"ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDCvkVwCj0HsRBuORHdiLSUYLX+smlUj/vM8N4aLCJhiR83FvA6P5845Vslb5pYvBi/+6NnHxeh1SMV6uYtJ6jMpo7UjmdBKw+N14G+8ZMepmTpMNQpX9pLmlb3LuMju/rJmpzH4li2/VNmeZf/ls23FDJjRx0cLoyif+u1S7CHoFn2KPGYqr64tP+FYlUwVXJwVZsJS79x1OUNzZEg49DmYHDKUW/jNLsJpzIGCMVf2e6czKOhOBhYjUzxRmwkv0aFtOSVRBjm4h+DcisTCV5LO2X8Z1ij0bqM2f++x7x8vtZJY2olSUGW90z0mHFkRyVAsmAdoJzdidi1XukJ7n8j root@controller01\\n\", \"user_id\": \"871c3da4707d4524af705b7eff6e34a2\", \"name\": \"key1\", \"deleted\": false, \"created_at\": \"2019-12-24T09:24:57Z\", \"updated_at\": null, \"fingerprint\": \"31:a5:c8:12:63:3a:61:d8:9c:a4:30:24:74:5d:6d:40\", \"deleted_at\": null, \"type\": \"ssh\", \"id\": 3}, \"nova_object.namespace\": \"nova\"}]}, \"nova_object.namespace\": \"nova\"}',NULL,NULL,NULL,NULL),('2019-12-25 08:44:19',NULL,'2019-12-25 09:01:08',9,9,'571c378c-b250-4b18-a00e-cc71c79d8d95',NULL,'[]','{\"new\": null, \"old\": null, \"cur\": {\"nova_object.version\": \"1.2\", \"nova_object.name\": \"Flavor\", \"nova_object.data\": {\"disabled\": false, \"root_gb\": 40, \"description\": null, \"flavorid\": \"1\", \"deleted\": false, \"created_at\": \"2019-12-24T09:39:51Z\", \"ephemeral_gb\": 0, \"updated_at\": null, \"memory_mb\": 4096, \"vcpus\": 4, \"extra_specs\": {}, \"swap\": 0, \"rxtx_factor\": 1.0, \"is_public\": true, \"deleted_at\": null, \"vcpu_weight\": 0, \"id\": 3, \"name\": \"goi1\"}, \"nova_object.namespace\": \"nova\"}}',NULL,NULL,'{\"nova_object.version\": \"1.3\", \"nova_object.name\": \"KeyPairList\", \"nova_object.data\": {\"objects\": [{\"nova_object.version\": \"1.4\", \"nova_object.name\": \"KeyPair\", \"nova_object.data\": {\"public_key\": \"ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDCvkVwCj0HsRBuORHdiLSUYLX+smlUj/vM8N4aLCJhiR83FvA6P5845Vslb5pYvBi/+6NnHxeh1SMV6uYtJ6jMpo7UjmdBKw+N14G+8ZMepmTpMNQpX9pLmlb3LuMju/rJmpzH4li2/VNmeZf/ls23FDJjRx0cLoyif+u1S7CHoFn2KPGYqr64tP+FYlUwVXJwVZsJS79x1OUNzZEg49DmYHDKUW/jNLsJpzIGCMVf2e6czKOhOBhYjUzxRmwkv0aFtOSVRBjm4h+DcisTCV5LO2X8Z1ij0bqM2f++x7x8vtZJY2olSUGW90z0mHFkRyVAsmAdoJzdidi1XukJ7n8j root@controller01\\n\", \"user_id\": \"871c3da4707d4524af705b7eff6e34a2\", \"name\": \"key1\", \"deleted\": false, \"created_at\": \"2019-12-24T09:24:57Z\", \"updated_at\": null, \"fingerprint\": \"31:a5:c8:12:63:3a:61:d8:9c:a4:30:24:74:5d:6d:40\", \"deleted_at\": null, \"type\": \"ssh\", \"id\": 3}, \"nova_object.namespace\": \"nova\"}]}, \"nova_object.namespace\": \"nova\"}',NULL,NULL,NULL,NULL),('2019-12-25 08:51:22',NULL,'2019-12-25 09:01:07',12,12,'ae77ef6c-9ca5-497b-92c0-d4bfcb29ccdf',NULL,'[]','{\"new\": null, \"old\": null, \"cur\": {\"nova_object.version\": \"1.2\", \"nova_object.name\": \"Flavor\", \"nova_object.data\": {\"disabled\": false, \"root_gb\": 40, \"description\": null, \"flavorid\": \"1\", \"deleted\": false, \"created_at\": \"2019-12-24T09:39:51Z\", \"ephemeral_gb\": 0, \"updated_at\": null, \"memory_mb\": 4096, \"vcpus\": 4, \"extra_specs\": {}, \"swap\": 0, \"rxtx_factor\": 1.0, \"is_public\": true, \"deleted_at\": null, \"vcpu_weight\": 0, \"id\": 3, \"name\": \"goi1\"}, \"nova_object.namespace\": \"nova\"}}',NULL,NULL,'{\"nova_object.version\": \"1.3\", \"nova_object.name\": \"KeyPairList\", \"nova_object.data\": {\"objects\": [{\"nova_object.version\": \"1.4\", \"nova_object.name\": \"KeyPair\", \"nova_object.data\": {\"public_key\": \"ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDCvkVwCj0HsRBuORHdiLSUYLX+smlUj/vM8N4aLCJhiR83FvA6P5845Vslb5pYvBi/+6NnHxeh1SMV6uYtJ6jMpo7UjmdBKw+N14G+8ZMepmTpMNQpX9pLmlb3LuMju/rJmpzH4li2/VNmeZf/ls23FDJjRx0cLoyif+u1S7CHoFn2KPGYqr64tP+FYlUwVXJwVZsJS79x1OUNzZEg49DmYHDKUW/jNLsJpzIGCMVf2e6czKOhOBhYjUzxRmwkv0aFtOSVRBjm4h+DcisTCV5LO2X8Z1ij0bqM2f++x7x8vtZJY2olSUGW90z0mHFkRyVAsmAdoJzdidi1XukJ7n8j root@controller01\\n\", \"user_id\": \"871c3da4707d4524af705b7eff6e34a2\", \"name\": \"key1\", \"deleted\": false, \"created_at\": \"2019-12-24T09:24:57Z\", \"updated_at\": null, \"fingerprint\": \"31:a5:c8:12:63:3a:61:d8:9c:a4:30:24:74:5d:6d:40\", \"deleted_at\": null, \"type\": \"ssh\", \"id\": 3}, \"nova_object.namespace\": \"nova\"}]}, \"nova_object.namespace\": \"nova\"}',NULL,NULL,NULL,NULL),('2019-12-25 10:20:35',NULL,'2019-12-25 11:01:17',15,15,'5f6ee10e-4a04-4a19-8199-5d4b458048a5',NULL,'[]','{\"new\": null, \"old\": null, \"cur\": {\"nova_object.version\": \"1.2\", \"nova_object.name\": \"Flavor\", \"nova_object.data\": {\"disabled\": false, \"root_gb\": 10, \"description\": null, \"flavorid\": \"0\", \"deleted\": false, \"created_at\": \"2019-12-03T08:40:03Z\", \"ephemeral_gb\": 0, \"updated_at\": null, \"memory_mb\": 2048, \"vcpus\": 1, \"extra_specs\": {}, \"swap\": 0, \"rxtx_factor\": 1.0, \"is_public\": true, \"deleted_at\": null, \"vcpu_weight\": 0, \"id\": 1, \"name\": \"m1.small\"}, \"nova_object.namespace\": \"nova\"}}',NULL,NULL,'{\"nova_object.version\": \"1.3\", \"nova_object.name\": \"KeyPairList\", \"nova_object.data\": {\"objects\": [{\"nova_object.version\": \"1.4\", \"nova_object.name\": \"KeyPair\", \"nova_object.data\": {\"public_key\": \"ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDCvkVwCj0HsRBuORHdiLSUYLX+smlUj/vM8N4aLCJhiR83FvA6P5845Vslb5pYvBi/+6NnHxeh1SMV6uYtJ6jMpo7UjmdBKw+N14G+8ZMepmTpMNQpX9pLmlb3LuMju/rJmpzH4li2/VNmeZf/ls23FDJjRx0cLoyif+u1S7CHoFn2KPGYqr64tP+FYlUwVXJwVZsJS79x1OUNzZEg49DmYHDKUW/jNLsJpzIGCMVf2e6czKOhOBhYjUzxRmwkv0aFtOSVRBjm4h+DcisTCV5LO2X8Z1ij0bqM2f++x7x8vtZJY2olSUGW90z0mHFkRyVAsmAdoJzdidi1XukJ7n8j root@controller01\\n\", \"user_id\": \"871c3da4707d4524af705b7eff6e34a2\", \"name\": \"key1\", \"deleted\": false, \"created_at\": \"2019-12-24T09:24:57Z\", \"updated_at\": null, \"fingerprint\": \"31:a5:c8:12:63:3a:61:d8:9c:a4:30:24:74:5d:6d:40\", \"deleted_at\": null, \"type\": \"ssh\", \"id\": 3}, \"nova_object.namespace\": \"nova\"}]}, \"nova_object.namespace\": \"nova\"}',NULL,NULL,NULL,NULL),('2019-12-25 10:22:26',NULL,'2019-12-25 11:01:16',18,18,'886c28dc-a479-4573-ad77-fdcc201be823',NULL,'[]','{\"new\": null, \"old\": null, \"cur\": {\"nova_object.version\": \"1.2\", \"nova_object.name\": \"Flavor\", \"nova_object.data\": {\"disabled\": false, \"root_gb\": 10, \"description\": null, \"flavorid\": \"0\", \"deleted\": false, \"created_at\": \"2019-12-03T08:40:03Z\", \"ephemeral_gb\": 0, \"updated_at\": null, \"memory_mb\": 2048, \"vcpus\": 1, \"extra_specs\": {}, \"swap\": 0, \"rxtx_factor\": 1.0, \"is_public\": true, \"deleted_at\": null, \"vcpu_weight\": 0, \"id\": 1, \"name\": \"m1.small\"}, \"nova_object.namespace\": \"nova\"}}',NULL,NULL,'{\"nova_object.version\": \"1.3\", \"nova_object.name\": \"KeyPairList\", \"nova_object.data\": {\"objects\": [{\"nova_object.version\": \"1.4\", \"nova_object.name\": \"KeyPair\", \"nova_object.data\": {\"public_key\": \"ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDCvkVwCj0HsRBuORHdiLSUYLX+smlUj/vM8N4aLCJhiR83FvA6P5845Vslb5pYvBi/+6NnHxeh1SMV6uYtJ6jMpo7UjmdBKw+N14G+8ZMepmTpMNQpX9pLmlb3LuMju/rJmpzH4li2/VNmeZf/ls23FDJjRx0cLoyif+u1S7CHoFn2KPGYqr64tP+FYlUwVXJwVZsJS79x1OUNzZEg49DmYHDKUW/jNLsJpzIGCMVf2e6czKOhOBhYjUzxRmwkv0aFtOSVRBjm4h+DcisTCV5LO2X8Z1ij0bqM2f++x7x8vtZJY2olSUGW90z0mHFkRyVAsmAdoJzdidi1XukJ7n8j root@controller01\\n\", \"user_id\": \"871c3da4707d4524af705b7eff6e34a2\", \"name\": \"key1\", \"deleted\": false, \"created_at\": \"2019-12-24T09:24:57Z\", \"updated_at\": null, \"fingerprint\": \"31:a5:c8:12:63:3a:61:d8:9c:a4:30:24:74:5d:6d:40\", \"deleted_at\": null, \"type\": \"ssh\", \"id\": 3}, \"nova_object.namespace\": \"nova\"}]}, \"nova_object.namespace\": \"nova\"}',NULL,NULL,NULL,NULL),('2019-12-25 10:32:26',NULL,'2019-12-25 11:01:16',21,21,'2dea7cba-4024-41b5-9302-9ac7345384aa',NULL,'[]','{\"new\": null, \"old\": null, \"cur\": {\"nova_object.version\": \"1.2\", \"nova_object.name\": \"Flavor\", \"nova_object.data\": {\"disabled\": false, \"root_gb\": 10, \"description\": null, \"flavorid\": \"0\", \"deleted\": false, \"created_at\": \"2019-12-03T08:40:03Z\", \"ephemeral_gb\": 0, \"updated_at\": null, \"memory_mb\": 2048, \"vcpus\": 1, \"extra_specs\": {}, \"swap\": 0, \"rxtx_factor\": 1.0, \"is_public\": true, \"deleted_at\": null, \"vcpu_weight\": 0, \"id\": 1, \"name\": \"m1.small\"}, \"nova_object.namespace\": \"nova\"}}',NULL,NULL,'{\"nova_object.version\": \"1.3\", \"nova_object.name\": \"KeyPairList\", \"nova_object.data\": {\"objects\": [{\"nova_object.version\": \"1.4\", \"nova_object.name\": \"KeyPair\", \"nova_object.data\": {\"public_key\": \"ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDCvkVwCj0HsRBuORHdiLSUYLX+smlUj/vM8N4aLCJhiR83FvA6P5845Vslb5pYvBi/+6NnHxeh1SMV6uYtJ6jMpo7UjmdBKw+N14G+8ZMepmTpMNQpX9pLmlb3LuMju/rJmpzH4li2/VNmeZf/ls23FDJjRx0cLoyif+u1S7CHoFn2KPGYqr64tP+FYlUwVXJwVZsJS79x1OUNzZEg49DmYHDKUW/jNLsJpzIGCMVf2e6czKOhOBhYjUzxRmwkv0aFtOSVRBjm4h+DcisTCV5LO2X8Z1ij0bqM2f++x7x8vtZJY2olSUGW90z0mHFkRyVAsmAdoJzdidi1XukJ7n8j root@controller01\\n\", \"user_id\": \"871c3da4707d4524af705b7eff6e34a2\", \"name\": \"key1\", \"deleted\": false, \"created_at\": \"2019-12-24T09:24:57Z\", \"updated_at\": null, \"fingerprint\": \"31:a5:c8:12:63:3a:61:d8:9c:a4:30:24:74:5d:6d:40\", \"deleted_at\": null, \"type\": \"ssh\", \"id\": 3}, \"nova_object.namespace\": \"nova\"}]}, \"nova_object.namespace\": \"nova\"}',NULL,NULL,NULL,NULL),('2019-12-25 11:00:06',NULL,'2019-12-25 11:01:15',24,24,'7a8aee11-c444-49d4-a97b-cd4a42104932',NULL,'[]','{\"new\": null, \"old\": null, \"cur\": {\"nova_object.version\": \"1.2\", \"nova_object.name\": \"Flavor\", \"nova_object.data\": {\"disabled\": false, \"root_gb\": 10, \"description\": null, \"flavorid\": \"0\", \"deleted\": false, \"created_at\": \"2019-12-03T08:40:03Z\", \"ephemeral_gb\": 0, \"updated_at\": null, \"memory_mb\": 2048, \"vcpus\": 1, \"extra_specs\": {}, \"swap\": 0, \"rxtx_factor\": 1.0, \"is_public\": true, \"deleted_at\": null, \"vcpu_weight\": 0, \"id\": 1, \"name\": \"m1.small\"}, \"nova_object.namespace\": \"nova\"}}',NULL,NULL,'{\"nova_object.version\": \"1.3\", \"nova_object.name\": \"KeyPairList\", \"nova_object.data\": {\"objects\": [{\"nova_object.version\": \"1.4\", \"nova_object.name\": \"KeyPair\", \"nova_object.data\": {\"public_key\": \"ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDCvkVwCj0HsRBuORHdiLSUYLX+smlUj/vM8N4aLCJhiR83FvA6P5845Vslb5pYvBi/+6NnHxeh1SMV6uYtJ6jMpo7UjmdBKw+N14G+8ZMepmTpMNQpX9pLmlb3LuMju/rJmpzH4li2/VNmeZf/ls23FDJjRx0cLoyif+u1S7CHoFn2KPGYqr64tP+FYlUwVXJwVZsJS79x1OUNzZEg49DmYHDKUW/jNLsJpzIGCMVf2e6czKOhOBhYjUzxRmwkv0aFtOSVRBjm4h+DcisTCV5LO2X8Z1ij0bqM2f++x7x8vtZJY2olSUGW90z0mHFkRyVAsmAdoJzdidi1XukJ7n8j root@controller01\\n\", \"user_id\": \"871c3da4707d4524af705b7eff6e34a2\", \"name\": \"key1\", \"deleted\": false, \"created_at\": \"2019-12-24T09:24:57Z\", \"updated_at\": null, \"fingerprint\": \"31:a5:c8:12:63:3a:61:d8:9c:a4:30:24:74:5d:6d:40\", \"deleted_at\": null, \"type\": \"ssh\", \"id\": 3}, \"nova_object.namespace\": \"nova\"}]}, \"nova_object.namespace\": \"nova\"}',NULL,NULL,NULL,NULL),('2019-12-25 11:33:53',NULL,'2019-12-26 02:40:16',27,27,'a8ce01ca-c34e-45c1-bd48-09e95666a776',NULL,'[]','{\"new\": null, \"old\": null, \"cur\": {\"nova_object.version\": \"1.2\", \"nova_object.name\": \"Flavor\", \"nova_object.data\": {\"disabled\": false, \"root_gb\": 10, \"description\": null, \"flavorid\": \"0\", \"deleted\": false, \"created_at\": \"2019-12-03T08:40:03Z\", \"ephemeral_gb\": 0, \"updated_at\": null, \"memory_mb\": 2048, \"vcpus\": 1, \"extra_specs\": {}, \"swap\": 0, \"rxtx_factor\": 1.0, \"is_public\": true, \"deleted_at\": null, \"vcpu_weight\": 0, \"id\": 1, \"name\": \"m1.small\"}, \"nova_object.namespace\": \"nova\"}}',NULL,NULL,'{\"nova_object.version\": \"1.3\", \"nova_object.name\": \"KeyPairList\", \"nova_object.data\": {\"objects\": [{\"nova_object.version\": \"1.4\", \"nova_object.name\": \"KeyPair\", \"nova_object.data\": {\"public_key\": \"ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDCvkVwCj0HsRBuORHdiLSUYLX+smlUj/vM8N4aLCJhiR83FvA6P5845Vslb5pYvBi/+6NnHxeh1SMV6uYtJ6jMpo7UjmdBKw+N14G+8ZMepmTpMNQpX9pLmlb3LuMju/rJmpzH4li2/VNmeZf/ls23FDJjRx0cLoyif+u1S7CHoFn2KPGYqr64tP+FYlUwVXJwVZsJS79x1OUNzZEg49DmYHDKUW/jNLsJpzIGCMVf2e6czKOhOBhYjUzxRmwkv0aFtOSVRBjm4h+DcisTCV5LO2X8Z1ij0bqM2f++x7x8vtZJY2olSUGW90z0mHFkRyVAsmAdoJzdidi1XukJ7n8j root@controller01\\n\", \"user_id\": \"871c3da4707d4524af705b7eff6e34a2\", \"name\": \"key1\", \"deleted\": false, \"created_at\": \"2019-12-24T09:24:57Z\", \"updated_at\": null, \"fingerprint\": \"31:a5:c8:12:63:3a:61:d8:9c:a4:30:24:74:5d:6d:40\", \"deleted_at\": null, \"type\": \"ssh\", \"id\": 3}, \"nova_object.namespace\": \"nova\"}]}, \"nova_object.namespace\": \"nova\"}',NULL,NULL,NULL,NULL),('2019-12-26 02:12:11',NULL,'2019-12-26 02:40:14',30,30,'57320b78-98c3-43b0-8170-87007ada0c6d',NULL,'[]','{\"new\": null, \"old\": null, \"cur\": {\"nova_object.version\": \"1.2\", \"nova_object.name\": \"Flavor\", \"nova_object.data\": {\"disabled\": false, \"root_gb\": 10, \"description\": null, \"flavorid\": \"0\", \"deleted\": false, \"created_at\": \"2019-12-03T08:40:03Z\", \"ephemeral_gb\": 0, \"updated_at\": null, \"memory_mb\": 2048, \"vcpus\": 1, \"extra_specs\": {}, \"swap\": 0, \"rxtx_factor\": 1.0, \"is_public\": true, \"deleted_at\": null, \"vcpu_weight\": 0, \"id\": 1, \"name\": \"m1.small\"}, \"nova_object.namespace\": \"nova\"}}',NULL,NULL,'{\"nova_object.version\": \"1.3\", \"nova_object.name\": \"KeyPairList\", \"nova_object.data\": {\"objects\": [{\"nova_object.version\": \"1.4\", \"nova_object.name\": \"KeyPair\", \"nova_object.data\": {\"public_key\": \"ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDCvkVwCj0HsRBuORHdiLSUYLX+smlUj/vM8N4aLCJhiR83FvA6P5845Vslb5pYvBi/+6NnHxeh1SMV6uYtJ6jMpo7UjmdBKw+N14G+8ZMepmTpMNQpX9pLmlb3LuMju/rJmpzH4li2/VNmeZf/ls23FDJjRx0cLoyif+u1S7CHoFn2KPGYqr64tP+FYlUwVXJwVZsJS79x1OUNzZEg49DmYHDKUW/jNLsJpzIGCMVf2e6czKOhOBhYjUzxRmwkv0aFtOSVRBjm4h+DcisTCV5LO2X8Z1ij0bqM2f++x7x8vtZJY2olSUGW90z0mHFkRyVAsmAdoJzdidi1XukJ7n8j root@controller01\\n\", \"user_id\": \"871c3da4707d4524af705b7eff6e34a2\", \"name\": \"key1\", \"deleted\": false, \"created_at\": \"2019-12-24T09:24:57Z\", \"updated_at\": null, \"fingerprint\": \"31:a5:c8:12:63:3a:61:d8:9c:a4:30:24:74:5d:6d:40\", \"deleted_at\": null, \"type\": \"ssh\", \"id\": 3}, \"nova_object.namespace\": \"nova\"}]}, \"nova_object.namespace\": \"nova\"}',NULL,NULL,NULL,NULL),('2019-12-26 02:57:20',NULL,'2019-12-26 03:04:42',33,33,'d73201b6-62d3-4260-99ed-0e20374178bc',NULL,'[]','{\"new\": null, \"old\": null, \"cur\": {\"nova_object.version\": \"1.2\", \"nova_object.name\": \"Flavor\", \"nova_object.data\": {\"disabled\": false, \"root_gb\": 10, \"description\": null, \"flavorid\": \"0\", \"deleted\": false, \"created_at\": \"2019-12-03T08:40:03Z\", \"ephemeral_gb\": 0, \"updated_at\": null, \"memory_mb\": 2048, \"vcpus\": 1, \"extra_specs\": {}, \"swap\": 0, \"rxtx_factor\": 1.0, \"is_public\": true, \"deleted_at\": null, \"vcpu_weight\": 0, \"id\": 1, \"name\": \"m1.small\"}, \"nova_object.namespace\": \"nova\"}}',NULL,NULL,'{\"nova_object.version\": \"1.3\", \"nova_object.name\": \"KeyPairList\", \"nova_object.data\": {\"objects\": [{\"nova_object.version\": \"1.4\", \"nova_object.name\": \"KeyPair\", \"nova_object.data\": {\"public_key\": \"ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDCvkVwCj0HsRBuORHdiLSUYLX+smlUj/vM8N4aLCJhiR83FvA6P5845Vslb5pYvBi/+6NnHxeh1SMV6uYtJ6jMpo7UjmdBKw+N14G+8ZMepmTpMNQpX9pLmlb3LuMju/rJmpzH4li2/VNmeZf/ls23FDJjRx0cLoyif+u1S7CHoFn2KPGYqr64tP+FYlUwVXJwVZsJS79x1OUNzZEg49DmYHDKUW/jNLsJpzIGCMVf2e6czKOhOBhYjUzxRmwkv0aFtOSVRBjm4h+DcisTCV5LO2X8Z1ij0bqM2f++x7x8vtZJY2olSUGW90z0mHFkRyVAsmAdoJzdidi1XukJ7n8j root@controller01\\n\", \"user_id\": \"871c3da4707d4524af705b7eff6e34a2\", \"name\": \"key1\", \"deleted\": false, \"created_at\": \"2019-12-24T09:24:57Z\", \"updated_at\": null, \"fingerprint\": \"31:a5:c8:12:63:3a:61:d8:9c:a4:30:24:74:5d:6d:40\", \"deleted_at\": null, \"type\": \"ssh\", \"id\": 3}, \"nova_object.namespace\": \"nova\"}]}, \"nova_object.namespace\": \"nova\"}',NULL,NULL,NULL,NULL),('2019-12-26 09:37:47',NULL,'2019-12-27 02:19:02',36,36,'26a41a6e-7da0-43b0-8ad1-54b6bdba8d39',NULL,'[]','{\"new\": null, \"old\": null, \"cur\": {\"nova_object.version\": \"1.2\", \"nova_object.name\": \"Flavor\", \"nova_object.data\": {\"disabled\": false, \"root_gb\": 10, \"description\": null, \"flavorid\": \"0\", \"deleted\": false, \"created_at\": \"2019-12-03T08:40:03Z\", \"ephemeral_gb\": 0, \"updated_at\": null, \"memory_mb\": 2048, \"vcpus\": 1, \"extra_specs\": {}, \"swap\": 0, \"rxtx_factor\": 1.0, \"is_public\": true, \"deleted_at\": null, \"vcpu_weight\": 0, \"id\": 1, \"name\": \"m1.small\"}, \"nova_object.namespace\": \"nova\"}}',NULL,NULL,'{\"nova_object.version\": \"1.3\", \"nova_object.name\": \"KeyPairList\", \"nova_object.data\": {\"objects\": [{\"nova_object.version\": \"1.4\", \"nova_object.name\": \"KeyPair\", \"nova_object.data\": {\"public_key\": \"ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDCvkVwCj0HsRBuORHdiLSUYLX+smlUj/vM8N4aLCJhiR83FvA6P5845Vslb5pYvBi/+6NnHxeh1SMV6uYtJ6jMpo7UjmdBKw+N14G+8ZMepmTpMNQpX9pLmlb3LuMju/rJmpzH4li2/VNmeZf/ls23FDJjRx0cLoyif+u1S7CHoFn2KPGYqr64tP+FYlUwVXJwVZsJS79x1OUNzZEg49DmYHDKUW/jNLsJpzIGCMVf2e6czKOhOBhYjUzxRmwkv0aFtOSVRBjm4h+DcisTCV5LO2X8Z1ij0bqM2f++x7x8vtZJY2olSUGW90z0mHFkRyVAsmAdoJzdidi1XukJ7n8j root@controller01\\n\", \"user_id\": \"871c3da4707d4524af705b7eff6e34a2\", \"name\": \"key1\", \"deleted\": false, \"created_at\": \"2019-12-24T09:24:57Z\", \"updated_at\": null, \"fingerprint\": \"31:a5:c8:12:63:3a:61:d8:9c:a4:30:24:74:5d:6d:40\", \"deleted_at\": null, \"type\": \"ssh\", \"id\": 3}, \"nova_object.namespace\": \"nova\"}]}, \"nova_object.namespace\": \"nova\"}',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `instance_extra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instance_faults`
--

DROP TABLE IF EXISTS `instance_faults`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `instance_faults` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `instance_uuid` varchar(36) DEFAULT NULL,
  `code` int(11) NOT NULL,
  `message` varchar(255) DEFAULT NULL,
  `details` mediumtext DEFAULT NULL,
  `host` varchar(255) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `instance_faults_host_idx` (`host`),
  KEY `instance_faults_instance_uuid_deleted_created_at_idx` (`instance_uuid`,`deleted`,`created_at`),
  CONSTRAINT `fk_instance_faults_instance_uuid` FOREIGN KEY (`instance_uuid`) REFERENCES `instances` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instance_faults`
--

LOCK TABLES `instance_faults` WRITE;
/*!40000 ALTER TABLE `instance_faults` DISABLE KEYS */;
INSERT INTO `instance_faults` VALUES ('2019-12-25 03:12:56',NULL,'2019-12-25 03:23:05',3,'1c4bd9e1-1e4b-4a25-b1a7-9eb58076edd3',500,'No valid host was found. No such host - host: compute1 node: compute1 ','Traceback (most recent call last):\n  File \"/usr/lib/python2.7/site-packages/nova/conductor/manager.py\", line 1333, in schedule_and_build_instances\n    instance_uuids, return_alternates=True)\n  File \"/usr/lib/python2.7/site-packages/nova/conductor/manager.py\", line 839, in _schedule_instances\n    return_alternates=return_alternates)\n  File \"/usr/lib/python2.7/site-packages/nova/scheduler/client/query.py\", line 42, in select_destinations\n    instance_uuids, return_objects, return_alternates)\n  File \"/usr/lib/python2.7/site-packages/nova/scheduler/rpcapi.py\", line 160, in select_destinations\n    return cctxt.call(ctxt, \'select_destinations\', **msg_args)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/rpc/client.py\", line 181, in call\n    transport_options=self.transport_options)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/transport.py\", line 129, in _send\n    transport_options=transport_options)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 646, in send\n    transport_options=transport_options)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 636, in _send\n    raise result\nNoValidHost_Remote: No valid host was found. No such host - host: compute1 node: compute1 \nTraceback (most recent call last):\n\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/rpc/server.py\", line 235, in inner\n    return func(*args, **kwargs)\n\n  File \"/usr/lib/python2.7/site-packages/nova/scheduler/manager.py\", line 155, in select_destinations\n    enable_pinning_translate=True)\n\n  File \"/usr/lib/python2.7/site-packages/nova/scheduler/utils.py\", line 598, in resources_from_request_spec\n    raise exception.NoValidHost(reason=reason)\n\nNoValidHost: No valid host was found. No such host - host: compute1 node: compute1 \n\n','controller01',3),('2019-12-25 08:30:04',NULL,'2019-12-25 08:31:01',6,'c4d322a8-26a3-4768-8f62-2445471fbe71',500,'MessagingTimeout','Traceback (most recent call last):\n  File \"/usr/lib/python2.7/site-packages/nova/conductor/manager.py\", line 1333, in schedule_and_build_instances\n    instance_uuids, return_alternates=True)\n  File \"/usr/lib/python2.7/site-packages/nova/conductor/manager.py\", line 839, in _schedule_instances\n    return_alternates=return_alternates)\n  File \"/usr/lib/python2.7/site-packages/nova/scheduler/client/query.py\", line 42, in select_destinations\n    instance_uuids, return_objects, return_alternates)\n  File \"/usr/lib/python2.7/site-packages/nova/scheduler/rpcapi.py\", line 160, in select_destinations\n    return cctxt.call(ctxt, \'select_destinations\', **msg_args)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/rpc/client.py\", line 181, in call\n    transport_options=self.transport_options)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/transport.py\", line 129, in _send\n    transport_options=transport_options)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 646, in send\n    transport_options=transport_options)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 634, in _send\n    call_monitor_timeout)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 523, in wait\n    message = self.waiters.get(msg_id, timeout=timeout)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 401, in get\n    \'to message ID %s\' % msg_id)\nMessagingTimeout: Timed out waiting for a reply to message ID 68f30e73ac094157bd1b3d217305a183\n','controller01',6),('2019-12-25 08:44:19',NULL,'2019-12-25 09:01:08',9,'571c378c-b250-4b18-a00e-cc71c79d8d95',500,'No valid host was found. There are not enough hosts available.','Traceback (most recent call last):\n  File \"/usr/lib/python2.7/site-packages/nova/conductor/manager.py\", line 1333, in schedule_and_build_instances\n    instance_uuids, return_alternates=True)\n  File \"/usr/lib/python2.7/site-packages/nova/conductor/manager.py\", line 839, in _schedule_instances\n    return_alternates=return_alternates)\n  File \"/usr/lib/python2.7/site-packages/nova/scheduler/client/query.py\", line 42, in select_destinations\n    instance_uuids, return_objects, return_alternates)\n  File \"/usr/lib/python2.7/site-packages/nova/scheduler/rpcapi.py\", line 160, in select_destinations\n    return cctxt.call(ctxt, \'select_destinations\', **msg_args)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/rpc/client.py\", line 181, in call\n    transport_options=self.transport_options)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/transport.py\", line 129, in _send\n    transport_options=transport_options)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 646, in send\n    transport_options=transport_options)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 636, in _send\n    raise result\nNoValidHost_Remote: No valid host was found. There are not enough hosts available.\nTraceback (most recent call last):\n\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/rpc/server.py\", line 235, in inner\n    return func(*args, **kwargs)\n\n  File \"/usr/lib/python2.7/site-packages/nova/scheduler/manager.py\", line 214, in select_destinations\n    allocation_request_version, return_alternates)\n\n  File \"/usr/lib/python2.7/site-packages/nova/scheduler/filter_scheduler.py\", line 96, in select_destinations\n    allocation_request_version, return_alternates)\n\n  File \"/usr/lib/python2.7/site-packages/nova/scheduler/filter_scheduler.py\", line 265, in _schedule\n    claimed_instance_uuids)\n\n  File \"/usr/lib/python2.7/site-packages/nova/scheduler/filter_scheduler.py\", line 302, in _ensure_sufficient_hosts\n    raise exception.NoValidHost(reason=reason)\n\nNoValidHost: No valid host was found. There are not enough hosts available.\n\n','controller01',9),('2019-12-25 08:51:22',NULL,'2019-12-25 09:01:07',12,'ae77ef6c-9ca5-497b-92c0-d4bfcb29ccdf',500,'MessagingTimeout','Traceback (most recent call last):\n  File \"/usr/lib/python2.7/site-packages/nova/conductor/manager.py\", line 1333, in schedule_and_build_instances\n    instance_uuids, return_alternates=True)\n  File \"/usr/lib/python2.7/site-packages/nova/conductor/manager.py\", line 839, in _schedule_instances\n    return_alternates=return_alternates)\n  File \"/usr/lib/python2.7/site-packages/nova/scheduler/client/query.py\", line 42, in select_destinations\n    instance_uuids, return_objects, return_alternates)\n  File \"/usr/lib/python2.7/site-packages/nova/scheduler/rpcapi.py\", line 160, in select_destinations\n    return cctxt.call(ctxt, \'select_destinations\', **msg_args)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/rpc/client.py\", line 181, in call\n    transport_options=self.transport_options)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/transport.py\", line 129, in _send\n    transport_options=transport_options)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 646, in send\n    transport_options=transport_options)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 634, in _send\n    call_monitor_timeout)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 523, in wait\n    message = self.waiters.get(msg_id, timeout=timeout)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 401, in get\n    \'to message ID %s\' % msg_id)\nMessagingTimeout: Timed out waiting for a reply to message ID 91173f3a72114edcb752123b72bed527\n','controller03',12),('2019-12-25 10:20:35',NULL,'2019-12-25 11:01:17',15,'5f6ee10e-4a04-4a19-8199-5d4b458048a5',500,'MessagingTimeout','Traceback (most recent call last):\n  File \"/usr/lib/python2.7/site-packages/nova/conductor/manager.py\", line 1333, in schedule_and_build_instances\n    instance_uuids, return_alternates=True)\n  File \"/usr/lib/python2.7/site-packages/nova/conductor/manager.py\", line 839, in _schedule_instances\n    return_alternates=return_alternates)\n  File \"/usr/lib/python2.7/site-packages/nova/scheduler/client/query.py\", line 42, in select_destinations\n    instance_uuids, return_objects, return_alternates)\n  File \"/usr/lib/python2.7/site-packages/nova/scheduler/rpcapi.py\", line 160, in select_destinations\n    return cctxt.call(ctxt, \'select_destinations\', **msg_args)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/rpc/client.py\", line 181, in call\n    transport_options=self.transport_options)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/transport.py\", line 129, in _send\n    transport_options=transport_options)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 646, in send\n    transport_options=transport_options)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 634, in _send\n    call_monitor_timeout)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 523, in wait\n    message = self.waiters.get(msg_id, timeout=timeout)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 401, in get\n    \'to message ID %s\' % msg_id)\nMessagingTimeout: Timed out waiting for a reply to message ID ce8f97c9c8054cb5bf7bdb5dee92cdcf\n','controller02',15),('2019-12-25 10:22:26',NULL,'2019-12-25 11:01:16',18,'886c28dc-a479-4573-ad77-fdcc201be823',500,'MessagingTimeout','Traceback (most recent call last):\n  File \"/usr/lib/python2.7/site-packages/nova/conductor/manager.py\", line 1333, in schedule_and_build_instances\n    instance_uuids, return_alternates=True)\n  File \"/usr/lib/python2.7/site-packages/nova/conductor/manager.py\", line 839, in _schedule_instances\n    return_alternates=return_alternates)\n  File \"/usr/lib/python2.7/site-packages/nova/scheduler/client/query.py\", line 42, in select_destinations\n    instance_uuids, return_objects, return_alternates)\n  File \"/usr/lib/python2.7/site-packages/nova/scheduler/rpcapi.py\", line 160, in select_destinations\n    return cctxt.call(ctxt, \'select_destinations\', **msg_args)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/rpc/client.py\", line 181, in call\n    transport_options=self.transport_options)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/transport.py\", line 129, in _send\n    transport_options=transport_options)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 646, in send\n    transport_options=transport_options)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 634, in _send\n    call_monitor_timeout)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 523, in wait\n    message = self.waiters.get(msg_id, timeout=timeout)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 401, in get\n    \'to message ID %s\' % msg_id)\nMessagingTimeout: Timed out waiting for a reply to message ID 84f97b864d804f04ad7f402676ddcd1b\n','controller02',18),('2019-12-25 10:32:26',NULL,'2019-12-25 11:01:16',21,'2dea7cba-4024-41b5-9302-9ac7345384aa',500,'MessagingTimeout','Traceback (most recent call last):\n  File \"/usr/lib/python2.7/site-packages/nova/conductor/manager.py\", line 1333, in schedule_and_build_instances\n    instance_uuids, return_alternates=True)\n  File \"/usr/lib/python2.7/site-packages/nova/conductor/manager.py\", line 839, in _schedule_instances\n    return_alternates=return_alternates)\n  File \"/usr/lib/python2.7/site-packages/nova/scheduler/client/query.py\", line 42, in select_destinations\n    instance_uuids, return_objects, return_alternates)\n  File \"/usr/lib/python2.7/site-packages/nova/scheduler/rpcapi.py\", line 160, in select_destinations\n    return cctxt.call(ctxt, \'select_destinations\', **msg_args)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/rpc/client.py\", line 181, in call\n    transport_options=self.transport_options)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/transport.py\", line 129, in _send\n    transport_options=transport_options)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 646, in send\n    transport_options=transport_options)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 634, in _send\n    call_monitor_timeout)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 523, in wait\n    message = self.waiters.get(msg_id, timeout=timeout)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 401, in get\n    \'to message ID %s\' % msg_id)\nMessagingTimeout: Timed out waiting for a reply to message ID d63b748da2b74cd9a464e5078136b74a\n','controller01',21),('2019-12-25 11:00:06',NULL,'2019-12-25 11:01:15',24,'7a8aee11-c444-49d4-a97b-cd4a42104932',500,'MessagingTimeout','Traceback (most recent call last):\n  File \"/usr/lib/python2.7/site-packages/nova/conductor/manager.py\", line 1333, in schedule_and_build_instances\n    instance_uuids, return_alternates=True)\n  File \"/usr/lib/python2.7/site-packages/nova/conductor/manager.py\", line 839, in _schedule_instances\n    return_alternates=return_alternates)\n  File \"/usr/lib/python2.7/site-packages/nova/scheduler/client/query.py\", line 42, in select_destinations\n    instance_uuids, return_objects, return_alternates)\n  File \"/usr/lib/python2.7/site-packages/nova/scheduler/rpcapi.py\", line 160, in select_destinations\n    return cctxt.call(ctxt, \'select_destinations\', **msg_args)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/rpc/client.py\", line 181, in call\n    transport_options=self.transport_options)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/transport.py\", line 129, in _send\n    transport_options=transport_options)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 646, in send\n    transport_options=transport_options)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 634, in _send\n    call_monitor_timeout)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 523, in wait\n    message = self.waiters.get(msg_id, timeout=timeout)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 401, in get\n    \'to message ID %s\' % msg_id)\nMessagingTimeout: Timed out waiting for a reply to message ID 0d4b02f18fee4c88bce67eb540fadf2f\n','controller01',24),('2019-12-25 11:33:53',NULL,'2019-12-26 02:40:16',27,'a8ce01ca-c34e-45c1-bd48-09e95666a776',500,'MessagingTimeout','Traceback (most recent call last):\n  File \"/usr/lib/python2.7/site-packages/nova/conductor/manager.py\", line 1333, in schedule_and_build_instances\n    instance_uuids, return_alternates=True)\n  File \"/usr/lib/python2.7/site-packages/nova/conductor/manager.py\", line 839, in _schedule_instances\n    return_alternates=return_alternates)\n  File \"/usr/lib/python2.7/site-packages/nova/scheduler/client/query.py\", line 42, in select_destinations\n    instance_uuids, return_objects, return_alternates)\n  File \"/usr/lib/python2.7/site-packages/nova/scheduler/rpcapi.py\", line 160, in select_destinations\n    return cctxt.call(ctxt, \'select_destinations\', **msg_args)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/rpc/client.py\", line 181, in call\n    transport_options=self.transport_options)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/transport.py\", line 129, in _send\n    transport_options=transport_options)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 646, in send\n    transport_options=transport_options)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 634, in _send\n    call_monitor_timeout)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 523, in wait\n    message = self.waiters.get(msg_id, timeout=timeout)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 401, in get\n    \'to message ID %s\' % msg_id)\nMessagingTimeout: Timed out waiting for a reply to message ID 93fd50a6cc2b46dd81789a09c989fb42\n','controller03',27),('2019-12-26 02:12:11',NULL,'2019-12-26 02:40:14',30,'57320b78-98c3-43b0-8170-87007ada0c6d',500,'MessagingTimeout','Traceback (most recent call last):\n  File \"/usr/lib/python2.7/site-packages/nova/conductor/manager.py\", line 1333, in schedule_and_build_instances\n    instance_uuids, return_alternates=True)\n  File \"/usr/lib/python2.7/site-packages/nova/conductor/manager.py\", line 839, in _schedule_instances\n    return_alternates=return_alternates)\n  File \"/usr/lib/python2.7/site-packages/nova/scheduler/client/query.py\", line 42, in select_destinations\n    instance_uuids, return_objects, return_alternates)\n  File \"/usr/lib/python2.7/site-packages/nova/scheduler/rpcapi.py\", line 160, in select_destinations\n    return cctxt.call(ctxt, \'select_destinations\', **msg_args)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/rpc/client.py\", line 181, in call\n    transport_options=self.transport_options)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/transport.py\", line 129, in _send\n    transport_options=transport_options)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 646, in send\n    transport_options=transport_options)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 634, in _send\n    call_monitor_timeout)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 523, in wait\n    message = self.waiters.get(msg_id, timeout=timeout)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 401, in get\n    \'to message ID %s\' % msg_id)\nMessagingTimeout: Timed out waiting for a reply to message ID efac85e137664474b8930a6b0b2f873f\n','controller03',30),('2019-12-26 02:57:20',NULL,'2019-12-26 03:04:42',33,'d73201b6-62d3-4260-99ed-0e20374178bc',500,'MessagingTimeout','Traceback (most recent call last):\n  File \"/usr/lib/python2.7/site-packages/nova/conductor/manager.py\", line 1333, in schedule_and_build_instances\n    instance_uuids, return_alternates=True)\n  File \"/usr/lib/python2.7/site-packages/nova/conductor/manager.py\", line 839, in _schedule_instances\n    return_alternates=return_alternates)\n  File \"/usr/lib/python2.7/site-packages/nova/scheduler/client/query.py\", line 42, in select_destinations\n    instance_uuids, return_objects, return_alternates)\n  File \"/usr/lib/python2.7/site-packages/nova/scheduler/rpcapi.py\", line 160, in select_destinations\n    return cctxt.call(ctxt, \'select_destinations\', **msg_args)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/rpc/client.py\", line 181, in call\n    transport_options=self.transport_options)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/transport.py\", line 129, in _send\n    transport_options=transport_options)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 646, in send\n    transport_options=transport_options)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 634, in _send\n    call_monitor_timeout)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 523, in wait\n    message = self.waiters.get(msg_id, timeout=timeout)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 401, in get\n    \'to message ID %s\' % msg_id)\nMessagingTimeout: Timed out waiting for a reply to message ID c2650a1254cb4f57993b10f33e03565c\n','controller02',33),('2019-12-26 09:37:47',NULL,'2019-12-27 02:19:02',36,'26a41a6e-7da0-43b0-8ad1-54b6bdba8d39',500,'MessagingTimeout','Traceback (most recent call last):\n  File \"/usr/lib/python2.7/site-packages/nova/conductor/manager.py\", line 1333, in schedule_and_build_instances\n    instance_uuids, return_alternates=True)\n  File \"/usr/lib/python2.7/site-packages/nova/conductor/manager.py\", line 839, in _schedule_instances\n    return_alternates=return_alternates)\n  File \"/usr/lib/python2.7/site-packages/nova/scheduler/client/query.py\", line 42, in select_destinations\n    instance_uuids, return_objects, return_alternates)\n  File \"/usr/lib/python2.7/site-packages/nova/scheduler/rpcapi.py\", line 160, in select_destinations\n    return cctxt.call(ctxt, \'select_destinations\', **msg_args)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/rpc/client.py\", line 181, in call\n    transport_options=self.transport_options)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/transport.py\", line 129, in _send\n    transport_options=transport_options)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 646, in send\n    transport_options=transport_options)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 634, in _send\n    call_monitor_timeout)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 523, in wait\n    message = self.waiters.get(msg_id, timeout=timeout)\n  File \"/usr/lib/python2.7/site-packages/oslo_messaging/_drivers/amqpdriver.py\", line 401, in get\n    \'to message ID %s\' % msg_id)\nMessagingTimeout: Timed out waiting for a reply to message ID ebe7cdabb750446589e89d58b9fcd5a0\n','controller03',36);
/*!40000 ALTER TABLE `instance_faults` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instance_group_member`
--

DROP TABLE IF EXISTS `instance_group_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `instance_group_member` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `instance_id` varchar(255) DEFAULT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`),
  KEY `instance_group_member_instance_idx` (`instance_id`),
  CONSTRAINT `instance_group_member_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `instance_groups` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instance_group_member`
--

LOCK TABLES `instance_group_member` WRITE;
/*!40000 ALTER TABLE `instance_group_member` DISABLE KEYS */;
/*!40000 ALTER TABLE `instance_group_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instance_group_policy`
--

DROP TABLE IF EXISTS `instance_group_policy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `instance_group_policy` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `policy` varchar(255) DEFAULT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`),
  KEY `instance_group_policy_policy_idx` (`policy`),
  CONSTRAINT `instance_group_policy_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `instance_groups` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instance_group_policy`
--

LOCK TABLES `instance_group_policy` WRITE;
/*!40000 ALTER TABLE `instance_group_policy` DISABLE KEYS */;
/*!40000 ALTER TABLE `instance_group_policy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instance_groups`
--

DROP TABLE IF EXISTS `instance_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `instance_groups` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(255) DEFAULT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `uuid` varchar(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_instance_groups0uuid0deleted` (`uuid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instance_groups`
--

LOCK TABLES `instance_groups` WRITE;
/*!40000 ALTER TABLE `instance_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `instance_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instance_id_mappings`
--

DROP TABLE IF EXISTS `instance_id_mappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `instance_id_mappings` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_instance_id_mappings_uuid` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instance_id_mappings`
--

LOCK TABLES `instance_id_mappings` WRITE;
/*!40000 ALTER TABLE `instance_id_mappings` DISABLE KEYS */;
INSERT INTO `instance_id_mappings` VALUES ('2019-12-25 03:12:55',NULL,'2019-12-25 03:23:05',3,'1c4bd9e1-1e4b-4a25-b1a7-9eb58076edd3',3),('2019-12-25 08:30:04',NULL,'2019-12-25 08:31:01',6,'c4d322a8-26a3-4768-8f62-2445471fbe71',6),('2019-12-25 08:44:19',NULL,'2019-12-25 09:01:08',9,'571c378c-b250-4b18-a00e-cc71c79d8d95',9),('2019-12-25 08:51:22',NULL,'2019-12-25 09:01:07',12,'ae77ef6c-9ca5-497b-92c0-d4bfcb29ccdf',12),('2019-12-25 10:20:35',NULL,'2019-12-25 11:01:17',15,'5f6ee10e-4a04-4a19-8199-5d4b458048a5',15),('2019-12-25 10:22:26',NULL,'2019-12-25 11:01:16',18,'886c28dc-a479-4573-ad77-fdcc201be823',18),('2019-12-25 10:32:26',NULL,'2019-12-25 11:01:16',21,'2dea7cba-4024-41b5-9302-9ac7345384aa',21),('2019-12-25 11:00:06',NULL,'2019-12-25 11:01:15',24,'7a8aee11-c444-49d4-a97b-cd4a42104932',24),('2019-12-25 11:33:53',NULL,'2019-12-26 02:40:16',27,'a8ce01ca-c34e-45c1-bd48-09e95666a776',27),('2019-12-26 02:12:11',NULL,'2019-12-26 02:40:14',30,'57320b78-98c3-43b0-8170-87007ada0c6d',30),('2019-12-26 02:57:20',NULL,'2019-12-26 03:04:42',33,'d73201b6-62d3-4260-99ed-0e20374178bc',33),('2019-12-26 09:37:47',NULL,'2019-12-27 02:19:02',36,'26a41a6e-7da0-43b0-8ad1-54b6bdba8d39',36);
/*!40000 ALTER TABLE `instance_id_mappings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instance_info_caches`
--

DROP TABLE IF EXISTS `instance_info_caches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `instance_info_caches` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `network_info` mediumtext DEFAULT NULL,
  `instance_uuid` varchar(36) NOT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_instance_info_caches0instance_uuid` (`instance_uuid`),
  CONSTRAINT `instance_info_caches_instance_uuid_fkey` FOREIGN KEY (`instance_uuid`) REFERENCES `instances` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instance_info_caches`
--

LOCK TABLES `instance_info_caches` WRITE;
/*!40000 ALTER TABLE `instance_info_caches` DISABLE KEYS */;
INSERT INTO `instance_info_caches` VALUES ('2019-12-25 03:12:55',NULL,'2019-12-25 03:23:05',3,'[]','1c4bd9e1-1e4b-4a25-b1a7-9eb58076edd3',3),('2019-12-25 08:30:04',NULL,'2019-12-25 08:31:00',6,'[]','c4d322a8-26a3-4768-8f62-2445471fbe71',6),('2019-12-25 08:44:19',NULL,'2019-12-25 09:01:08',9,'[]','571c378c-b250-4b18-a00e-cc71c79d8d95',9),('2019-12-25 08:51:22',NULL,'2019-12-25 09:01:07',12,'[]','ae77ef6c-9ca5-497b-92c0-d4bfcb29ccdf',12),('2019-12-25 10:20:35',NULL,'2019-12-25 11:01:17',15,'[]','5f6ee10e-4a04-4a19-8199-5d4b458048a5',15),('2019-12-25 10:22:26',NULL,'2019-12-25 11:01:16',18,'[]','886c28dc-a479-4573-ad77-fdcc201be823',18),('2019-12-25 10:32:26',NULL,'2019-12-25 11:01:16',21,'[]','2dea7cba-4024-41b5-9302-9ac7345384aa',21),('2019-12-25 11:00:06',NULL,'2019-12-25 11:01:15',24,'[]','7a8aee11-c444-49d4-a97b-cd4a42104932',24),('2019-12-25 11:33:53',NULL,'2019-12-26 02:40:16',27,'[]','a8ce01ca-c34e-45c1-bd48-09e95666a776',27),('2019-12-26 02:12:11',NULL,'2019-12-26 02:40:14',30,'[]','57320b78-98c3-43b0-8170-87007ada0c6d',30),('2019-12-26 02:57:20',NULL,'2019-12-26 03:04:42',33,'[]','d73201b6-62d3-4260-99ed-0e20374178bc',33),('2019-12-26 09:37:47',NULL,'2019-12-27 02:19:02',36,'[]','26a41a6e-7da0-43b0-8ad1-54b6bdba8d39',36);
/*!40000 ALTER TABLE `instance_info_caches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instance_metadata`
--

DROP TABLE IF EXISTS `instance_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `instance_metadata` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `instance_uuid` varchar(36) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `instance_metadata_instance_uuid_idx` (`instance_uuid`),
  CONSTRAINT `instance_metadata_instance_uuid_fkey` FOREIGN KEY (`instance_uuid`) REFERENCES `instances` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instance_metadata`
--

LOCK TABLES `instance_metadata` WRITE;
/*!40000 ALTER TABLE `instance_metadata` DISABLE KEYS */;
/*!40000 ALTER TABLE `instance_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instance_system_metadata`
--

DROP TABLE IF EXISTS `instance_system_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `instance_system_metadata` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `instance_uuid` varchar(36) NOT NULL,
  `key` varchar(255) NOT NULL,
  `value` varchar(255) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `instance_uuid` (`instance_uuid`),
  CONSTRAINT `instance_system_metadata_ibfk_1` FOREIGN KEY (`instance_uuid`) REFERENCES `instances` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=253 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instance_system_metadata`
--

LOCK TABLES `instance_system_metadata` WRITE;
/*!40000 ALTER TABLE `instance_system_metadata` DISABLE KEYS */;
INSERT INTO `instance_system_metadata` VALUES ('2019-12-25 03:12:55',NULL,'2019-12-25 03:23:05',3,'1c4bd9e1-1e4b-4a25-b1a7-9eb58076edd3','image_min_disk','40',3),('2019-12-25 03:12:55',NULL,'2019-12-25 03:23:05',6,'1c4bd9e1-1e4b-4a25-b1a7-9eb58076edd3','owner_user_name','admin',6),('2019-12-25 03:12:55',NULL,'2019-12-25 03:23:05',9,'1c4bd9e1-1e4b-4a25-b1a7-9eb58076edd3','owner_project_name','admin',9),('2019-12-25 03:12:55',NULL,'2019-12-25 03:23:05',12,'1c4bd9e1-1e4b-4a25-b1a7-9eb58076edd3','image_container_format','bare',12),('2019-12-25 03:12:55',NULL,'2019-12-25 03:23:05',15,'1c4bd9e1-1e4b-4a25-b1a7-9eb58076edd3','image_min_ram','0',15),('2019-12-25 03:12:55',NULL,'2019-12-25 03:23:05',18,'1c4bd9e1-1e4b-4a25-b1a7-9eb58076edd3','image_disk_format','qcow2',18),('2019-12-25 03:12:55',NULL,'2019-12-25 03:23:05',21,'1c4bd9e1-1e4b-4a25-b1a7-9eb58076edd3','image_base_image_ref','4246efca-c550-48f8-aa0e-7a368df98da6',21),('2019-12-25 08:30:04',NULL,'2019-12-25 08:31:01',24,'c4d322a8-26a3-4768-8f62-2445471fbe71','image_min_disk','60',24),('2019-12-25 08:30:04',NULL,'2019-12-25 08:31:01',27,'c4d322a8-26a3-4768-8f62-2445471fbe71','owner_user_name','admin',27),('2019-12-25 08:30:04',NULL,'2019-12-25 08:31:01',30,'c4d322a8-26a3-4768-8f62-2445471fbe71','owner_project_name','admin',30),('2019-12-25 08:30:04',NULL,'2019-12-25 08:31:01',33,'c4d322a8-26a3-4768-8f62-2445471fbe71','image_container_format','bare',33),('2019-12-25 08:30:04',NULL,'2019-12-25 08:31:01',36,'c4d322a8-26a3-4768-8f62-2445471fbe71','image_min_ram','0',36),('2019-12-25 08:30:04',NULL,'2019-12-25 08:31:01',39,'c4d322a8-26a3-4768-8f62-2445471fbe71','image_disk_format','qcow2',39),('2019-12-25 08:30:04',NULL,'2019-12-25 08:31:01',42,'c4d322a8-26a3-4768-8f62-2445471fbe71','image_base_image_ref','',42),('2019-12-25 08:44:19',NULL,'2019-12-25 09:01:08',45,'571c378c-b250-4b18-a00e-cc71c79d8d95','image_min_disk','40',45),('2019-12-25 08:44:19',NULL,'2019-12-25 09:01:08',48,'571c378c-b250-4b18-a00e-cc71c79d8d95','owner_user_name','admin',48),('2019-12-25 08:44:19',NULL,'2019-12-25 09:01:08',51,'571c378c-b250-4b18-a00e-cc71c79d8d95','owner_project_name','admin',51),('2019-12-25 08:44:19',NULL,'2019-12-25 09:01:08',54,'571c378c-b250-4b18-a00e-cc71c79d8d95','image_container_format','bare',54),('2019-12-25 08:44:19',NULL,'2019-12-25 09:01:08',57,'571c378c-b250-4b18-a00e-cc71c79d8d95','image_min_ram','0',57),('2019-12-25 08:44:19',NULL,'2019-12-25 09:01:08',60,'571c378c-b250-4b18-a00e-cc71c79d8d95','image_disk_format','qcow2',60),('2019-12-25 08:44:19',NULL,'2019-12-25 09:01:08',63,'571c378c-b250-4b18-a00e-cc71c79d8d95','image_base_image_ref','',63),('2019-12-25 08:51:22',NULL,'2019-12-25 09:01:07',66,'ae77ef6c-9ca5-497b-92c0-d4bfcb29ccdf','image_min_disk','40',66),('2019-12-25 08:51:22',NULL,'2019-12-25 09:01:07',69,'ae77ef6c-9ca5-497b-92c0-d4bfcb29ccdf','owner_user_name','admin',69),('2019-12-25 08:51:22',NULL,'2019-12-25 09:01:07',72,'ae77ef6c-9ca5-497b-92c0-d4bfcb29ccdf','owner_project_name','admin',72),('2019-12-25 08:51:22',NULL,'2019-12-25 09:01:07',75,'ae77ef6c-9ca5-497b-92c0-d4bfcb29ccdf','image_container_format','bare',75),('2019-12-25 08:51:22',NULL,'2019-12-25 09:01:07',78,'ae77ef6c-9ca5-497b-92c0-d4bfcb29ccdf','image_min_ram','0',78),('2019-12-25 08:51:22',NULL,'2019-12-25 09:01:07',81,'ae77ef6c-9ca5-497b-92c0-d4bfcb29ccdf','image_disk_format','qcow2',81),('2019-12-25 08:51:22',NULL,'2019-12-25 09:01:07',84,'ae77ef6c-9ca5-497b-92c0-d4bfcb29ccdf','image_base_image_ref','4246efca-c550-48f8-aa0e-7a368df98da6',84),('2019-12-25 10:20:35',NULL,'2019-12-25 11:01:17',87,'5f6ee10e-4a04-4a19-8199-5d4b458048a5','image_min_disk','10',87),('2019-12-25 10:20:35',NULL,'2019-12-25 11:01:17',90,'5f6ee10e-4a04-4a19-8199-5d4b458048a5','owner_user_name','admin',90),('2019-12-25 10:20:35',NULL,'2019-12-25 11:01:17',93,'5f6ee10e-4a04-4a19-8199-5d4b458048a5','owner_project_name','admin',93),('2019-12-25 10:20:35',NULL,'2019-12-25 11:01:17',96,'5f6ee10e-4a04-4a19-8199-5d4b458048a5','image_container_format','bare',96),('2019-12-25 10:20:35',NULL,'2019-12-25 11:01:17',99,'5f6ee10e-4a04-4a19-8199-5d4b458048a5','image_min_ram','0',99),('2019-12-25 10:20:35',NULL,'2019-12-25 11:01:17',102,'5f6ee10e-4a04-4a19-8199-5d4b458048a5','image_disk_format','qcow2',102),('2019-12-25 10:20:35',NULL,'2019-12-25 11:01:17',105,'5f6ee10e-4a04-4a19-8199-5d4b458048a5','image_base_image_ref','5ee759d1-e9e3-4bda-a9c6-50bcfe5cc355',105),('2019-12-25 10:22:26',NULL,'2019-12-25 11:01:16',108,'886c28dc-a479-4573-ad77-fdcc201be823','image_min_disk','10',108),('2019-12-25 10:22:26',NULL,'2019-12-25 11:01:16',111,'886c28dc-a479-4573-ad77-fdcc201be823','owner_user_name','admin',111),('2019-12-25 10:22:26',NULL,'2019-12-25 11:01:16',114,'886c28dc-a479-4573-ad77-fdcc201be823','owner_project_name','admin',114),('2019-12-25 10:22:26',NULL,'2019-12-25 11:01:16',117,'886c28dc-a479-4573-ad77-fdcc201be823','image_container_format','bare',117),('2019-12-25 10:22:26',NULL,'2019-12-25 11:01:16',120,'886c28dc-a479-4573-ad77-fdcc201be823','image_min_ram','0',120),('2019-12-25 10:22:26',NULL,'2019-12-25 11:01:16',123,'886c28dc-a479-4573-ad77-fdcc201be823','image_disk_format','qcow2',123),('2019-12-25 10:22:26',NULL,'2019-12-25 11:01:16',126,'886c28dc-a479-4573-ad77-fdcc201be823','image_base_image_ref','5ee759d1-e9e3-4bda-a9c6-50bcfe5cc355',126),('2019-12-25 10:32:26',NULL,'2019-12-25 11:01:16',129,'2dea7cba-4024-41b5-9302-9ac7345384aa','image_min_disk','10',129),('2019-12-25 10:32:26',NULL,'2019-12-25 11:01:16',132,'2dea7cba-4024-41b5-9302-9ac7345384aa','owner_user_name','admin',132),('2019-12-25 10:32:26',NULL,'2019-12-25 11:01:16',135,'2dea7cba-4024-41b5-9302-9ac7345384aa','owner_project_name','admin',135),('2019-12-25 10:32:26',NULL,'2019-12-25 11:01:16',138,'2dea7cba-4024-41b5-9302-9ac7345384aa','image_container_format','bare',138),('2019-12-25 10:32:26',NULL,'2019-12-25 11:01:16',141,'2dea7cba-4024-41b5-9302-9ac7345384aa','image_min_ram','0',141),('2019-12-25 10:32:26',NULL,'2019-12-25 11:01:16',144,'2dea7cba-4024-41b5-9302-9ac7345384aa','image_disk_format','qcow2',144),('2019-12-25 10:32:26',NULL,'2019-12-25 11:01:16',147,'2dea7cba-4024-41b5-9302-9ac7345384aa','image_base_image_ref','5ee759d1-e9e3-4bda-a9c6-50bcfe5cc355',147),('2019-12-25 11:00:06',NULL,'2019-12-25 11:01:15',150,'7a8aee11-c444-49d4-a97b-cd4a42104932','image_min_disk','10',150),('2019-12-25 11:00:06',NULL,'2019-12-25 11:01:15',153,'7a8aee11-c444-49d4-a97b-cd4a42104932','owner_user_name','admin',153),('2019-12-25 11:00:06',NULL,'2019-12-25 11:01:15',156,'7a8aee11-c444-49d4-a97b-cd4a42104932','owner_project_name','admin',156),('2019-12-25 11:00:06',NULL,'2019-12-25 11:01:15',159,'7a8aee11-c444-49d4-a97b-cd4a42104932','image_container_format','bare',159),('2019-12-25 11:00:06',NULL,'2019-12-25 11:01:15',162,'7a8aee11-c444-49d4-a97b-cd4a42104932','image_min_ram','0',162),('2019-12-25 11:00:06',NULL,'2019-12-25 11:01:15',165,'7a8aee11-c444-49d4-a97b-cd4a42104932','image_disk_format','qcow2',165),('2019-12-25 11:00:06',NULL,'2019-12-25 11:01:15',168,'7a8aee11-c444-49d4-a97b-cd4a42104932','image_base_image_ref','5ee759d1-e9e3-4bda-a9c6-50bcfe5cc355',168),('2019-12-25 11:33:53',NULL,'2019-12-26 02:40:16',171,'a8ce01ca-c34e-45c1-bd48-09e95666a776','image_min_disk','10',171),('2019-12-25 11:33:53',NULL,'2019-12-26 02:40:16',174,'a8ce01ca-c34e-45c1-bd48-09e95666a776','owner_user_name','admin',174),('2019-12-25 11:33:53',NULL,'2019-12-26 02:40:16',177,'a8ce01ca-c34e-45c1-bd48-09e95666a776','owner_project_name','admin',177),('2019-12-25 11:33:53',NULL,'2019-12-26 02:40:16',180,'a8ce01ca-c34e-45c1-bd48-09e95666a776','image_container_format','bare',180),('2019-12-25 11:33:53',NULL,'2019-12-26 02:40:16',183,'a8ce01ca-c34e-45c1-bd48-09e95666a776','image_min_ram','0',183),('2019-12-25 11:33:53',NULL,'2019-12-26 02:40:16',186,'a8ce01ca-c34e-45c1-bd48-09e95666a776','image_disk_format','qcow2',186),('2019-12-25 11:33:53',NULL,'2019-12-26 02:40:16',189,'a8ce01ca-c34e-45c1-bd48-09e95666a776','image_base_image_ref','5ee759d1-e9e3-4bda-a9c6-50bcfe5cc355',189),('2019-12-26 02:12:11',NULL,'2019-12-26 02:40:14',192,'57320b78-98c3-43b0-8170-87007ada0c6d','image_min_disk','10',192),('2019-12-26 02:12:11',NULL,'2019-12-26 02:40:14',195,'57320b78-98c3-43b0-8170-87007ada0c6d','owner_user_name','admin',195),('2019-12-26 02:12:11',NULL,'2019-12-26 02:40:14',198,'57320b78-98c3-43b0-8170-87007ada0c6d','owner_project_name','admin',198),('2019-12-26 02:12:11',NULL,'2019-12-26 02:40:14',201,'57320b78-98c3-43b0-8170-87007ada0c6d','image_container_format','bare',201),('2019-12-26 02:12:11',NULL,'2019-12-26 02:40:14',204,'57320b78-98c3-43b0-8170-87007ada0c6d','image_min_ram','0',204),('2019-12-26 02:12:11',NULL,'2019-12-26 02:40:14',207,'57320b78-98c3-43b0-8170-87007ada0c6d','image_disk_format','qcow2',207),('2019-12-26 02:12:11',NULL,'2019-12-26 02:40:14',210,'57320b78-98c3-43b0-8170-87007ada0c6d','image_base_image_ref','5ee759d1-e9e3-4bda-a9c6-50bcfe5cc355',210),('2019-12-26 02:57:20',NULL,'2019-12-26 03:04:42',213,'d73201b6-62d3-4260-99ed-0e20374178bc','image_min_disk','10',213),('2019-12-26 02:57:20',NULL,'2019-12-26 03:04:42',216,'d73201b6-62d3-4260-99ed-0e20374178bc','owner_user_name','admin',216),('2019-12-26 02:57:20',NULL,'2019-12-26 03:04:42',219,'d73201b6-62d3-4260-99ed-0e20374178bc','owner_project_name','admin',219),('2019-12-26 02:57:20',NULL,'2019-12-26 03:04:42',222,'d73201b6-62d3-4260-99ed-0e20374178bc','image_container_format','bare',222),('2019-12-26 02:57:20',NULL,'2019-12-26 03:04:42',225,'d73201b6-62d3-4260-99ed-0e20374178bc','image_min_ram','0',225),('2019-12-26 02:57:20',NULL,'2019-12-26 03:04:42',228,'d73201b6-62d3-4260-99ed-0e20374178bc','image_disk_format','qcow2',228),('2019-12-26 02:57:20',NULL,'2019-12-26 03:04:42',231,'d73201b6-62d3-4260-99ed-0e20374178bc','image_base_image_ref','5ee759d1-e9e3-4bda-a9c6-50bcfe5cc355',231),('2019-12-26 09:37:47',NULL,'2019-12-27 02:19:02',234,'26a41a6e-7da0-43b0-8ad1-54b6bdba8d39','image_min_disk','10',234),('2019-12-26 09:37:47',NULL,'2019-12-27 02:19:02',237,'26a41a6e-7da0-43b0-8ad1-54b6bdba8d39','owner_user_name','admin',237),('2019-12-26 09:37:47',NULL,'2019-12-27 02:19:02',240,'26a41a6e-7da0-43b0-8ad1-54b6bdba8d39','owner_project_name','admin',240),('2019-12-26 09:37:47',NULL,'2019-12-27 02:19:02',243,'26a41a6e-7da0-43b0-8ad1-54b6bdba8d39','image_container_format','bare',243),('2019-12-26 09:37:47',NULL,'2019-12-27 02:19:02',246,'26a41a6e-7da0-43b0-8ad1-54b6bdba8d39','image_min_ram','0',246),('2019-12-26 09:37:47',NULL,'2019-12-27 02:19:02',249,'26a41a6e-7da0-43b0-8ad1-54b6bdba8d39','image_disk_format','qcow2',249),('2019-12-26 09:37:47',NULL,'2019-12-27 02:19:02',252,'26a41a6e-7da0-43b0-8ad1-54b6bdba8d39','image_base_image_ref','5ee759d1-e9e3-4bda-a9c6-50bcfe5cc355',252);
/*!40000 ALTER TABLE `instance_system_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instance_type_extra_specs`
--

DROP TABLE IF EXISTS `instance_type_extra_specs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `instance_type_extra_specs` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `instance_type_id` int(11) NOT NULL,
  `key` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_instance_type_extra_specs0instance_type_id0key0deleted` (`instance_type_id`,`key`,`deleted`),
  KEY `instance_type_extra_specs_instance_type_id_key_idx` (`instance_type_id`,`key`),
  CONSTRAINT `instance_type_extra_specs_ibfk_1` FOREIGN KEY (`instance_type_id`) REFERENCES `instance_types` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instance_type_extra_specs`
--

LOCK TABLES `instance_type_extra_specs` WRITE;
/*!40000 ALTER TABLE `instance_type_extra_specs` DISABLE KEYS */;
/*!40000 ALTER TABLE `instance_type_extra_specs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instance_type_projects`
--

DROP TABLE IF EXISTS `instance_type_projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `instance_type_projects` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `instance_type_id` int(11) NOT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_instance_type_projects0instance_type_id0project_id0deleted` (`instance_type_id`,`project_id`,`deleted`),
  KEY `instance_type_id` (`instance_type_id`),
  CONSTRAINT `instance_type_projects_ibfk_1` FOREIGN KEY (`instance_type_id`) REFERENCES `instance_types` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instance_type_projects`
--

LOCK TABLES `instance_type_projects` WRITE;
/*!40000 ALTER TABLE `instance_type_projects` DISABLE KEYS */;
/*!40000 ALTER TABLE `instance_type_projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instance_types`
--

DROP TABLE IF EXISTS `instance_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `instance_types` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `memory_mb` int(11) NOT NULL,
  `vcpus` int(11) NOT NULL,
  `swap` int(11) NOT NULL,
  `vcpu_weight` int(11) DEFAULT NULL,
  `flavorid` varchar(255) DEFAULT NULL,
  `rxtx_factor` float DEFAULT NULL,
  `root_gb` int(11) DEFAULT NULL,
  `ephemeral_gb` int(11) DEFAULT NULL,
  `disabled` tinyint(1) DEFAULT NULL,
  `is_public` tinyint(1) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_instance_types0name0deleted` (`name`,`deleted`),
  UNIQUE KEY `uniq_instance_types0flavorid0deleted` (`flavorid`,`deleted`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`disabled` in (0,1)),
  CONSTRAINT `CONSTRAINT_2` CHECK (`is_public` in (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instance_types`
--

LOCK TABLES `instance_types` WRITE;
/*!40000 ALTER TABLE `instance_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `instance_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instances`
--

DROP TABLE IF EXISTS `instances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `instances` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `internal_id` int(11) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `image_ref` varchar(255) DEFAULT NULL,
  `kernel_id` varchar(255) DEFAULT NULL,
  `ramdisk_id` varchar(255) DEFAULT NULL,
  `launch_index` int(11) DEFAULT NULL,
  `key_name` varchar(255) DEFAULT NULL,
  `key_data` mediumtext DEFAULT NULL,
  `power_state` int(11) DEFAULT NULL,
  `vm_state` varchar(255) DEFAULT NULL,
  `memory_mb` int(11) DEFAULT NULL,
  `vcpus` int(11) DEFAULT NULL,
  `hostname` varchar(255) DEFAULT NULL,
  `host` varchar(255) DEFAULT NULL,
  `user_data` mediumtext DEFAULT NULL,
  `reservation_id` varchar(255) DEFAULT NULL,
  `launched_at` datetime DEFAULT NULL,
  `terminated_at` datetime DEFAULT NULL,
  `display_name` varchar(255) DEFAULT NULL,
  `display_description` varchar(255) DEFAULT NULL,
  `availability_zone` varchar(255) DEFAULT NULL,
  `locked` tinyint(1) DEFAULT NULL,
  `os_type` varchar(255) DEFAULT NULL,
  `launched_on` mediumtext DEFAULT NULL,
  `instance_type_id` int(11) DEFAULT NULL,
  `vm_mode` varchar(255) DEFAULT NULL,
  `uuid` varchar(36) NOT NULL,
  `architecture` varchar(255) DEFAULT NULL,
  `root_device_name` varchar(255) DEFAULT NULL,
  `access_ip_v4` varchar(39) DEFAULT NULL,
  `access_ip_v6` varchar(39) DEFAULT NULL,
  `config_drive` varchar(255) DEFAULT NULL,
  `task_state` varchar(255) DEFAULT NULL,
  `default_ephemeral_device` varchar(255) DEFAULT NULL,
  `default_swap_device` varchar(255) DEFAULT NULL,
  `progress` int(11) DEFAULT NULL,
  `auto_disk_config` tinyint(1) DEFAULT NULL,
  `shutdown_terminate` tinyint(1) DEFAULT NULL,
  `disable_terminate` tinyint(1) DEFAULT NULL,
  `root_gb` int(11) DEFAULT NULL,
  `ephemeral_gb` int(11) DEFAULT NULL,
  `cell_name` varchar(255) DEFAULT NULL,
  `node` varchar(255) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `locked_by` enum('owner','admin') DEFAULT NULL,
  `cleaned` int(11) DEFAULT NULL,
  `ephemeral_key_uuid` varchar(36) DEFAULT NULL,
  `hidden` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uuid` (`uuid`),
  UNIQUE KEY `uniq_instances0uuid` (`uuid`),
  KEY `instances_reservation_id_idx` (`reservation_id`),
  KEY `instances_terminated_at_launched_at_idx` (`terminated_at`,`launched_at`),
  KEY `instances_task_state_updated_at_idx` (`task_state`,`updated_at`),
  KEY `instances_uuid_deleted_idx` (`uuid`,`deleted`),
  KEY `instances_host_node_deleted_idx` (`host`,`node`,`deleted`),
  KEY `instances_host_deleted_cleaned_idx` (`host`,`deleted`,`cleaned`),
  KEY `instances_project_id_deleted_idx` (`project_id`,`deleted`),
  KEY `instances_deleted_created_at_idx` (`deleted`,`created_at`),
  KEY `instances_project_id_idx` (`project_id`),
  KEY `instances_updated_at_project_id_idx` (`updated_at`,`project_id`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`locked` in (0,1)),
  CONSTRAINT `CONSTRAINT_2` CHECK (`auto_disk_config` in (0,1)),
  CONSTRAINT `CONSTRAINT_3` CHECK (`shutdown_terminate` in (0,1)),
  CONSTRAINT `CONSTRAINT_4` CHECK (`disable_terminate` in (0,1))
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instances`
--

LOCK TABLES `instances` WRITE;
/*!40000 ALTER TABLE `instances` DISABLE KEYS */;
INSERT INTO `instances` VALUES ('2019-12-25 03:12:55','2019-12-25 03:23:05','2019-12-25 03:23:05',3,NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','4246efca-c550-48f8-aa0e-7a368df98da6','','',0,'key1','ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDCvkVwCj0HsRBuORHdiLSUYLX+smlUj/vM8N4aLCJhiR83FvA6P5845Vslb5pYvBi/+6NnHxeh1SMV6uYtJ6jMpo7UjmdBKw+N14G+8ZMepmTpMNQpX9pLmlb3LuMju/rJmpzH4li2/VNmeZf/ls23FDJjRx0cLoyif+u1S7CHoFn2KPGYqr64tP+FYlUwVXJwVZsJS79x1OUNzZEg49DmYHDKUW/jNLsJpzIGCMVf2e6czKOhOBhYjUzxRmwkv0aFtOSVRBjm4h+DcisTCV5LO2X8Z1ij0bqM2f++x7x8vtZJY2olSUGW90z0mHFkRyVAsmAdoJzdidi1XukJ7n8j root@controller01\n',0,'deleted',4096,4,'centos3',NULL,NULL,'r-l05f9xg0',NULL,'2019-12-25 03:23:05','centos3','centos3','nova',0,NULL,NULL,3,NULL,'1c4bd9e1-1e4b-4a25-b1a7-9eb58076edd3',NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,0,0,0,0,40,0,NULL,NULL,3,NULL,0,NULL,0),('2019-12-25 08:29:03','2019-12-25 08:31:00','2019-12-25 08:31:00',6,NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','','','',0,'key1','ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDCvkVwCj0HsRBuORHdiLSUYLX+smlUj/vM8N4aLCJhiR83FvA6P5845Vslb5pYvBi/+6NnHxeh1SMV6uYtJ6jMpo7UjmdBKw+N14G+8ZMepmTpMNQpX9pLmlb3LuMju/rJmpzH4li2/VNmeZf/ls23FDJjRx0cLoyif+u1S7CHoFn2KPGYqr64tP+FYlUwVXJwVZsJS79x1OUNzZEg49DmYHDKUW/jNLsJpzIGCMVf2e6czKOhOBhYjUzxRmwkv0aFtOSVRBjm4h+DcisTCV5LO2X8Z1ij0bqM2f++x7x8vtZJY2olSUGW90z0mHFkRyVAsmAdoJzdidi1XukJ7n8j root@controller01\n',0,'deleted',6144,4,'w4',NULL,NULL,'r-oa0lx8pw',NULL,'2019-12-25 08:31:00','w4',NULL,'nova',0,NULL,NULL,6,NULL,'c4d322a8-26a3-4768-8f62-2445471fbe71',NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,0,1,0,0,60,0,NULL,NULL,6,NULL,0,NULL,0),('2019-12-25 08:44:16','2019-12-25 09:01:08','2019-12-25 09:01:08',9,NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','','','',0,'key1','ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDCvkVwCj0HsRBuORHdiLSUYLX+smlUj/vM8N4aLCJhiR83FvA6P5845Vslb5pYvBi/+6NnHxeh1SMV6uYtJ6jMpo7UjmdBKw+N14G+8ZMepmTpMNQpX9pLmlb3LuMju/rJmpzH4li2/VNmeZf/ls23FDJjRx0cLoyif+u1S7CHoFn2KPGYqr64tP+FYlUwVXJwVZsJS79x1OUNzZEg49DmYHDKUW/jNLsJpzIGCMVf2e6czKOhOBhYjUzxRmwkv0aFtOSVRBjm4h+DcisTCV5LO2X8Z1ij0bqM2f++x7x8vtZJY2olSUGW90z0mHFkRyVAsmAdoJzdidi1XukJ7n8j root@controller01\n',0,'deleted',4096,4,'w1',NULL,NULL,'r-7xhsfadb',NULL,'2019-12-25 09:01:08','w1',NULL,'nova',0,NULL,NULL,3,NULL,'571c378c-b250-4b18-a00e-cc71c79d8d95',NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,0,1,0,0,40,0,NULL,NULL,9,NULL,0,NULL,0),('2019-12-25 08:50:22','2019-12-25 09:01:07','2019-12-25 09:01:07',12,NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','4246efca-c550-48f8-aa0e-7a368df98da6','','',0,'key1','ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDCvkVwCj0HsRBuORHdiLSUYLX+smlUj/vM8N4aLCJhiR83FvA6P5845Vslb5pYvBi/+6NnHxeh1SMV6uYtJ6jMpo7UjmdBKw+N14G+8ZMepmTpMNQpX9pLmlb3LuMju/rJmpzH4li2/VNmeZf/ls23FDJjRx0cLoyif+u1S7CHoFn2KPGYqr64tP+FYlUwVXJwVZsJS79x1OUNzZEg49DmYHDKUW/jNLsJpzIGCMVf2e6czKOhOBhYjUzxRmwkv0aFtOSVRBjm4h+DcisTCV5LO2X8Z1ij0bqM2f++x7x8vtZJY2olSUGW90z0mHFkRyVAsmAdoJzdidi1XukJ7n8j root@controller01\n',0,'deleted',4096,4,'centos3',NULL,NULL,'r-9yim224u',NULL,'2019-12-25 09:01:07','centos3','centos3','nova',0,NULL,NULL,3,NULL,'ae77ef6c-9ca5-497b-92c0-d4bfcb29ccdf',NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,0,0,0,0,40,0,NULL,NULL,12,NULL,0,NULL,0),('2019-12-25 10:19:35','2019-12-25 11:01:17','2019-12-25 11:01:17',15,NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','5ee759d1-e9e3-4bda-a9c6-50bcfe5cc355','','',0,'key1','ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDCvkVwCj0HsRBuORHdiLSUYLX+smlUj/vM8N4aLCJhiR83FvA6P5845Vslb5pYvBi/+6NnHxeh1SMV6uYtJ6jMpo7UjmdBKw+N14G+8ZMepmTpMNQpX9pLmlb3LuMju/rJmpzH4li2/VNmeZf/ls23FDJjRx0cLoyif+u1S7CHoFn2KPGYqr64tP+FYlUwVXJwVZsJS79x1OUNzZEg49DmYHDKUW/jNLsJpzIGCMVf2e6czKOhOBhYjUzxRmwkv0aFtOSVRBjm4h+DcisTCV5LO2X8Z1ij0bqM2f++x7x8vtZJY2olSUGW90z0mHFkRyVAsmAdoJzdidi1XukJ7n8j root@controller01\n',0,'deleted',2048,1,'centos4',NULL,NULL,'r-7nxmc4ch',NULL,'2019-12-25 11:01:17','centos4','centos4','nova',0,NULL,NULL,1,NULL,'5f6ee10e-4a04-4a19-8199-5d4b458048a5',NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,0,0,0,0,10,0,NULL,NULL,15,NULL,0,NULL,0),('2019-12-25 10:21:26','2019-12-25 11:01:16','2019-12-25 11:01:16',18,NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','5ee759d1-e9e3-4bda-a9c6-50bcfe5cc355','','',0,'key1','ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDCvkVwCj0HsRBuORHdiLSUYLX+smlUj/vM8N4aLCJhiR83FvA6P5845Vslb5pYvBi/+6NnHxeh1SMV6uYtJ6jMpo7UjmdBKw+N14G+8ZMepmTpMNQpX9pLmlb3LuMju/rJmpzH4li2/VNmeZf/ls23FDJjRx0cLoyif+u1S7CHoFn2KPGYqr64tP+FYlUwVXJwVZsJS79x1OUNzZEg49DmYHDKUW/jNLsJpzIGCMVf2e6czKOhOBhYjUzxRmwkv0aFtOSVRBjm4h+DcisTCV5LO2X8Z1ij0bqM2f++x7x8vtZJY2olSUGW90z0mHFkRyVAsmAdoJzdidi1XukJ7n8j root@controller01\n',0,'deleted',2048,1,'centos5',NULL,NULL,'r-b1bfq0zb',NULL,'2019-12-25 11:01:16','centos5','centos5','nova',0,NULL,NULL,1,NULL,'886c28dc-a479-4573-ad77-fdcc201be823',NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,0,0,0,0,10,0,NULL,NULL,18,NULL,0,NULL,0),('2019-12-25 10:31:26','2019-12-25 11:01:16','2019-12-25 11:01:16',21,NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','5ee759d1-e9e3-4bda-a9c6-50bcfe5cc355','','',0,'key1','ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDCvkVwCj0HsRBuORHdiLSUYLX+smlUj/vM8N4aLCJhiR83FvA6P5845Vslb5pYvBi/+6NnHxeh1SMV6uYtJ6jMpo7UjmdBKw+N14G+8ZMepmTpMNQpX9pLmlb3LuMju/rJmpzH4li2/VNmeZf/ls23FDJjRx0cLoyif+u1S7CHoFn2KPGYqr64tP+FYlUwVXJwVZsJS79x1OUNzZEg49DmYHDKUW/jNLsJpzIGCMVf2e6czKOhOBhYjUzxRmwkv0aFtOSVRBjm4h+DcisTCV5LO2X8Z1ij0bqM2f++x7x8vtZJY2olSUGW90z0mHFkRyVAsmAdoJzdidi1XukJ7n8j root@controller01\n',0,'deleted',2048,1,'centos8',NULL,NULL,'r-etoq91fp',NULL,'2019-12-25 11:01:15','centos8','centos8','nova',0,NULL,NULL,1,NULL,'2dea7cba-4024-41b5-9302-9ac7345384aa',NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,0,0,0,0,10,0,NULL,NULL,21,NULL,0,NULL,0),('2019-12-25 10:59:06','2019-12-25 11:01:15','2019-12-25 11:01:15',24,NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','5ee759d1-e9e3-4bda-a9c6-50bcfe5cc355','','',0,'key1','ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDCvkVwCj0HsRBuORHdiLSUYLX+smlUj/vM8N4aLCJhiR83FvA6P5845Vslb5pYvBi/+6NnHxeh1SMV6uYtJ6jMpo7UjmdBKw+N14G+8ZMepmTpMNQpX9pLmlb3LuMju/rJmpzH4li2/VNmeZf/ls23FDJjRx0cLoyif+u1S7CHoFn2KPGYqr64tP+FYlUwVXJwVZsJS79x1OUNzZEg49DmYHDKUW/jNLsJpzIGCMVf2e6czKOhOBhYjUzxRmwkv0aFtOSVRBjm4h+DcisTCV5LO2X8Z1ij0bqM2f++x7x8vtZJY2olSUGW90z0mHFkRyVAsmAdoJzdidi1XukJ7n8j root@controller01\n',0,'deleted',2048,1,'centos9',NULL,NULL,'r-eaj29u4z',NULL,'2019-12-25 11:01:15','centos9','centos9','nova',0,NULL,NULL,1,NULL,'7a8aee11-c444-49d4-a97b-cd4a42104932',NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,0,0,0,0,10,0,NULL,NULL,24,NULL,0,NULL,0),('2019-12-25 11:32:53','2019-12-26 02:40:16','2019-12-26 02:40:16',27,NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','5ee759d1-e9e3-4bda-a9c6-50bcfe5cc355','','',0,'key1','ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDCvkVwCj0HsRBuORHdiLSUYLX+smlUj/vM8N4aLCJhiR83FvA6P5845Vslb5pYvBi/+6NnHxeh1SMV6uYtJ6jMpo7UjmdBKw+N14G+8ZMepmTpMNQpX9pLmlb3LuMju/rJmpzH4li2/VNmeZf/ls23FDJjRx0cLoyif+u1S7CHoFn2KPGYqr64tP+FYlUwVXJwVZsJS79x1OUNzZEg49DmYHDKUW/jNLsJpzIGCMVf2e6czKOhOBhYjUzxRmwkv0aFtOSVRBjm4h+DcisTCV5LO2X8Z1ij0bqM2f++x7x8vtZJY2olSUGW90z0mHFkRyVAsmAdoJzdidi1XukJ7n8j root@controller01\n',0,'deleted',2048,1,'cpt2-2',NULL,NULL,'r-np2crcbk',NULL,'2019-12-26 02:40:16','CPT2-2','CPT2-2','nova',0,NULL,NULL,1,NULL,'a8ce01ca-c34e-45c1-bd48-09e95666a776',NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,0,0,0,0,10,0,NULL,NULL,27,NULL,0,NULL,0),('2019-12-26 02:11:11','2019-12-26 02:40:14','2019-12-26 02:40:14',30,NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','5ee759d1-e9e3-4bda-a9c6-50bcfe5cc355','','',0,'key1','ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDCvkVwCj0HsRBuORHdiLSUYLX+smlUj/vM8N4aLCJhiR83FvA6P5845Vslb5pYvBi/+6NnHxeh1SMV6uYtJ6jMpo7UjmdBKw+N14G+8ZMepmTpMNQpX9pLmlb3LuMju/rJmpzH4li2/VNmeZf/ls23FDJjRx0cLoyif+u1S7CHoFn2KPGYqr64tP+FYlUwVXJwVZsJS79x1OUNzZEg49DmYHDKUW/jNLsJpzIGCMVf2e6czKOhOBhYjUzxRmwkv0aFtOSVRBjm4h+DcisTCV5LO2X8Z1ij0bqM2f++x7x8vtZJY2olSUGW90z0mHFkRyVAsmAdoJzdidi1XukJ7n8j root@controller01\n',0,'deleted',2048,1,'cpt2-6',NULL,NULL,'r-em0zob0g',NULL,'2019-12-26 02:40:14','CPT2-6','CPT2-6','nova',0,NULL,NULL,1,NULL,'57320b78-98c3-43b0-8170-87007ada0c6d',NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,0,0,0,0,10,0,NULL,NULL,30,NULL,0,NULL,0),('2019-12-26 02:56:20','2019-12-26 03:04:42','2019-12-26 03:04:42',33,NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','5ee759d1-e9e3-4bda-a9c6-50bcfe5cc355','','',0,'key1','ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDCvkVwCj0HsRBuORHdiLSUYLX+smlUj/vM8N4aLCJhiR83FvA6P5845Vslb5pYvBi/+6NnHxeh1SMV6uYtJ6jMpo7UjmdBKw+N14G+8ZMepmTpMNQpX9pLmlb3LuMju/rJmpzH4li2/VNmeZf/ls23FDJjRx0cLoyif+u1S7CHoFn2KPGYqr64tP+FYlUwVXJwVZsJS79x1OUNzZEg49DmYHDKUW/jNLsJpzIGCMVf2e6czKOhOBhYjUzxRmwkv0aFtOSVRBjm4h+DcisTCV5LO2X8Z1ij0bqM2f++x7x8vtZJY2olSUGW90z0mHFkRyVAsmAdoJzdidi1XukJ7n8j root@controller01\n',0,'deleted',2048,1,'cpt1-3',NULL,NULL,'r-eiu96dqv',NULL,'2019-12-26 03:04:42','CPT1-3','CPT1-3','nova',0,NULL,NULL,1,NULL,'d73201b6-62d3-4260-99ed-0e20374178bc',NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,0,0,0,0,10,0,NULL,NULL,33,NULL,0,NULL,0),('2019-12-26 09:36:47','2019-12-27 02:19:02','2019-12-27 02:19:02',36,NULL,'871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0','5ee759d1-e9e3-4bda-a9c6-50bcfe5cc355','','',0,'key1','ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDCvkVwCj0HsRBuORHdiLSUYLX+smlUj/vM8N4aLCJhiR83FvA6P5845Vslb5pYvBi/+6NnHxeh1SMV6uYtJ6jMpo7UjmdBKw+N14G+8ZMepmTpMNQpX9pLmlb3LuMju/rJmpzH4li2/VNmeZf/ls23FDJjRx0cLoyif+u1S7CHoFn2KPGYqr64tP+FYlUwVXJwVZsJS79x1OUNzZEg49DmYHDKUW/jNLsJpzIGCMVf2e6czKOhOBhYjUzxRmwkv0aFtOSVRBjm4h+DcisTCV5LO2X8Z1ij0bqM2f++x7x8vtZJY2olSUGW90z0mHFkRyVAsmAdoJzdidi1XukJ7n8j root@controller01\n',0,'deleted',2048,1,'cpt1-cirros-2',NULL,NULL,'r-joy8raep',NULL,'2019-12-27 02:19:02','CPT1-cirros-2','CPT1-cirros-2','nova',0,NULL,NULL,1,NULL,'26a41a6e-7da0-43b0-8ad1-54b6bdba8d39',NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,0,0,0,0,10,0,NULL,NULL,36,NULL,0,NULL,0);
/*!40000 ALTER TABLE `instances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventories`
--

DROP TABLE IF EXISTS `inventories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resource_provider_id` int(11) NOT NULL,
  `resource_class_id` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `reserved` int(11) NOT NULL,
  `min_unit` int(11) NOT NULL,
  `max_unit` int(11) NOT NULL,
  `step_size` int(11) NOT NULL,
  `allocation_ratio` float NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_inventories0resource_provider_resource_class` (`resource_provider_id`,`resource_class_id`),
  KEY `inventories_resource_class_id_idx` (`resource_class_id`),
  KEY `inventories_resource_provider_id_idx` (`resource_provider_id`),
  KEY `inventories_resource_provider_resource_class_idx` (`resource_provider_id`,`resource_class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventories`
--

LOCK TABLES `inventories` WRITE;
/*!40000 ALTER TABLE `inventories` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `key_pairs`
--

DROP TABLE IF EXISTS `key_pairs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `key_pairs` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `fingerprint` varchar(255) DEFAULT NULL,
  `public_key` mediumtext DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `type` enum('ssh','x509') NOT NULL DEFAULT 'ssh',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_key_pairs0user_id0name0deleted` (`user_id`,`name`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `key_pairs`
--

LOCK TABLES `key_pairs` WRITE;
/*!40000 ALTER TABLE `key_pairs` DISABLE KEYS */;
/*!40000 ALTER TABLE `key_pairs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrate_version`
--

DROP TABLE IF EXISTS `migrate_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrate_version` (
  `repository_id` varchar(250) NOT NULL,
  `repository_path` text DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  PRIMARY KEY (`repository_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrate_version`
--

LOCK TABLES `migrate_version` WRITE;
/*!40000 ALTER TABLE `migrate_version` DISABLE KEYS */;
INSERT INTO `migrate_version` VALUES ('nova','/usr/lib/python2.7/site-packages/nova/db/sqlalchemy/migrate_repo',402);
/*!40000 ALTER TABLE `migrate_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `source_compute` varchar(255) DEFAULT NULL,
  `dest_compute` varchar(255) DEFAULT NULL,
  `dest_host` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `instance_uuid` varchar(36) DEFAULT NULL,
  `old_instance_type_id` int(11) DEFAULT NULL,
  `new_instance_type_id` int(11) DEFAULT NULL,
  `source_node` varchar(255) DEFAULT NULL,
  `dest_node` varchar(255) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `migration_type` enum('migration','resize','live-migration','evacuation') DEFAULT NULL,
  `hidden` tinyint(1) DEFAULT NULL,
  `memory_total` bigint(20) DEFAULT NULL,
  `memory_processed` bigint(20) DEFAULT NULL,
  `memory_remaining` bigint(20) DEFAULT NULL,
  `disk_total` bigint(20) DEFAULT NULL,
  `disk_processed` bigint(20) DEFAULT NULL,
  `disk_remaining` bigint(20) DEFAULT NULL,
  `uuid` varchar(36) DEFAULT NULL,
  `cross_cell_move` tinyint(1) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `migrations_uuid` (`uuid`),
  KEY `migrations_by_host_nodes_and_status_idx` (`deleted`,`source_compute`(100),`dest_compute`(100),`source_node`(100),`dest_node`(100),`status`),
  KEY `migrations_instance_uuid_and_status_idx` (`deleted`,`instance_uuid`,`status`),
  KEY `fk_migrations_instance_uuid` (`instance_uuid`),
  KEY `migrations_updated_at_idx` (`updated_at`),
  CONSTRAINT `fk_migrations_instance_uuid` FOREIGN KEY (`instance_uuid`) REFERENCES `instances` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `networks`
--

DROP TABLE IF EXISTS `networks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `networks` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `injected` tinyint(1) DEFAULT NULL,
  `cidr` varchar(43) DEFAULT NULL,
  `netmask` varchar(39) DEFAULT NULL,
  `bridge` varchar(255) DEFAULT NULL,
  `gateway` varchar(39) DEFAULT NULL,
  `broadcast` varchar(39) DEFAULT NULL,
  `dns1` varchar(39) DEFAULT NULL,
  `vlan` int(11) DEFAULT NULL,
  `vpn_public_address` varchar(39) DEFAULT NULL,
  `vpn_public_port` int(11) DEFAULT NULL,
  `vpn_private_address` varchar(39) DEFAULT NULL,
  `dhcp_start` varchar(39) DEFAULT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `host` varchar(255) DEFAULT NULL,
  `cidr_v6` varchar(43) DEFAULT NULL,
  `gateway_v6` varchar(39) DEFAULT NULL,
  `label` varchar(255) DEFAULT NULL,
  `netmask_v6` varchar(39) DEFAULT NULL,
  `bridge_interface` varchar(255) DEFAULT NULL,
  `multi_host` tinyint(1) DEFAULT NULL,
  `dns2` varchar(39) DEFAULT NULL,
  `uuid` varchar(36) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  `rxtx_base` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `mtu` int(11) DEFAULT NULL,
  `dhcp_server` varchar(39) DEFAULT NULL,
  `enable_dhcp` tinyint(1) DEFAULT NULL,
  `share_address` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_networks0vlan0deleted` (`vlan`,`deleted`),
  KEY `networks_host_idx` (`host`),
  KEY `networks_cidr_v6_idx` (`cidr_v6`),
  KEY `networks_bridge_deleted_idx` (`bridge`,`deleted`),
  KEY `networks_project_id_deleted_idx` (`project_id`,`deleted`),
  KEY `networks_uuid_project_id_deleted_idx` (`uuid`,`project_id`,`deleted`),
  KEY `networks_vlan_deleted_idx` (`vlan`,`deleted`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`injected` in (0,1)),
  CONSTRAINT `CONSTRAINT_2` CHECK (`multi_host` in (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `networks`
--

LOCK TABLES `networks` WRITE;
/*!40000 ALTER TABLE `networks` DISABLE KEYS */;
/*!40000 ALTER TABLE `networks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pci_devices`
--

DROP TABLE IF EXISTS `pci_devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pci_devices` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `compute_node_id` int(11) NOT NULL,
  `address` varchar(12) NOT NULL,
  `product_id` varchar(4) NOT NULL,
  `vendor_id` varchar(4) NOT NULL,
  `dev_type` varchar(8) NOT NULL,
  `dev_id` varchar(255) DEFAULT NULL,
  `label` varchar(255) NOT NULL,
  `status` varchar(36) NOT NULL,
  `extra_info` text DEFAULT NULL,
  `instance_uuid` varchar(36) DEFAULT NULL,
  `request_id` varchar(36) DEFAULT NULL,
  `numa_node` int(11) DEFAULT NULL,
  `parent_addr` varchar(12) DEFAULT NULL,
  `uuid` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_pci_devices0compute_node_id0address0deleted` (`compute_node_id`,`address`,`deleted`),
  KEY `ix_pci_devices_compute_node_id_deleted` (`compute_node_id`,`deleted`),
  KEY `ix_pci_devices_instance_uuid_deleted` (`instance_uuid`,`deleted`),
  KEY `ix_pci_devices_compute_node_id_parent_addr_deleted` (`compute_node_id`,`parent_addr`,`deleted`),
  CONSTRAINT `pci_devices_compute_node_id_fkey` FOREIGN KEY (`compute_node_id`) REFERENCES `compute_nodes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pci_devices`
--

LOCK TABLES `pci_devices` WRITE;
/*!40000 ALTER TABLE `pci_devices` DISABLE KEYS */;
/*!40000 ALTER TABLE `pci_devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_user_quotas`
--

DROP TABLE IF EXISTS `project_user_quotas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_user_quotas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `user_id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `resource` varchar(255) NOT NULL,
  `hard_limit` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_project_user_quotas0user_id0project_id0resource0deleted` (`user_id`,`project_id`,`resource`,`deleted`),
  KEY `project_user_quotas_project_id_deleted_idx` (`project_id`,`deleted`),
  KEY `project_user_quotas_user_id_deleted_idx` (`user_id`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_user_quotas`
--

LOCK TABLES `project_user_quotas` WRITE;
/*!40000 ALTER TABLE `project_user_quotas` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_user_quotas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `provider_fw_rules`
--

DROP TABLE IF EXISTS `provider_fw_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `provider_fw_rules` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `protocol` varchar(5) DEFAULT NULL,
  `from_port` int(11) DEFAULT NULL,
  `to_port` int(11) DEFAULT NULL,
  `cidr` varchar(43) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `provider_fw_rules`
--

LOCK TABLES `provider_fw_rules` WRITE;
/*!40000 ALTER TABLE `provider_fw_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `provider_fw_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quota_classes`
--

DROP TABLE IF EXISTS `quota_classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quota_classes` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_name` varchar(255) DEFAULT NULL,
  `resource` varchar(255) DEFAULT NULL,
  `hard_limit` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_quota_classes_class_name` (`class_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quota_classes`
--

LOCK TABLES `quota_classes` WRITE;
/*!40000 ALTER TABLE `quota_classes` DISABLE KEYS */;
/*!40000 ALTER TABLE `quota_classes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quota_usages`
--

DROP TABLE IF EXISTS `quota_usages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quota_usages` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` varchar(255) DEFAULT NULL,
  `resource` varchar(255) NOT NULL,
  `in_use` int(11) NOT NULL,
  `reserved` int(11) NOT NULL,
  `until_refresh` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_quota_usages_project_id` (`project_id`),
  KEY `ix_quota_usages_user_id_deleted` (`user_id`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quota_usages`
--

LOCK TABLES `quota_usages` WRITE;
/*!40000 ALTER TABLE `quota_usages` DISABLE KEYS */;
/*!40000 ALTER TABLE `quota_usages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quotas`
--

DROP TABLE IF EXISTS `quotas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quotas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `resource` varchar(255) NOT NULL,
  `hard_limit` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_quotas0project_id0resource0deleted` (`project_id`,`resource`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quotas`
--

LOCK TABLES `quotas` WRITE;
/*!40000 ALTER TABLE `quotas` DISABLE KEYS */;
/*!40000 ALTER TABLE `quotas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservations`
--

DROP TABLE IF EXISTS `reservations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reservations` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `usage_id` int(11) NOT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `resource` varchar(255) DEFAULT NULL,
  `delta` int(11) NOT NULL,
  `expire` datetime DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `usage_id` (`usage_id`),
  KEY `ix_reservations_project_id` (`project_id`),
  KEY `ix_reservations_user_id_deleted` (`user_id`,`deleted`),
  KEY `reservations_uuid_idx` (`uuid`),
  KEY `reservations_deleted_expire_idx` (`deleted`,`expire`),
  CONSTRAINT `reservations_ibfk_1` FOREIGN KEY (`usage_id`) REFERENCES `quota_usages` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservations`
--

LOCK TABLES `reservations` WRITE;
/*!40000 ALTER TABLE `reservations` DISABLE KEYS */;
/*!40000 ALTER TABLE `reservations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resource_provider_aggregates`
--

DROP TABLE IF EXISTS `resource_provider_aggregates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resource_provider_aggregates` (
  `resource_provider_id` int(11) NOT NULL,
  `aggregate_id` int(11) NOT NULL,
  PRIMARY KEY (`resource_provider_id`,`aggregate_id`),
  KEY `resource_provider_aggregates_aggregate_id_idx` (`aggregate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resource_provider_aggregates`
--

LOCK TABLES `resource_provider_aggregates` WRITE;
/*!40000 ALTER TABLE `resource_provider_aggregates` DISABLE KEYS */;
/*!40000 ALTER TABLE `resource_provider_aggregates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resource_providers`
--

DROP TABLE IF EXISTS `resource_providers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resource_providers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `name` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `generation` int(11) DEFAULT NULL,
  `can_host` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_resource_providers0uuid` (`uuid`),
  UNIQUE KEY `uniq_resource_providers0name` (`name`),
  KEY `resource_providers_uuid_idx` (`uuid`),
  KEY `resource_providers_name_idx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resource_providers`
--

LOCK TABLES `resource_providers` WRITE;
/*!40000 ALTER TABLE `resource_providers` DISABLE KEYS */;
/*!40000 ALTER TABLE `resource_providers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `s3_images`
--

DROP TABLE IF EXISTS `s3_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `s3_images` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `s3_images`
--

LOCK TABLES `s3_images` WRITE;
/*!40000 ALTER TABLE `s3_images` DISABLE KEYS */;
INSERT INTO `s3_images` VALUES ('2019-12-25 03:12:55',NULL,NULL,3,'4246efca-c550-48f8-aa0e-7a368df98da6',0),('2019-12-25 10:20:35',NULL,NULL,6,'5ee759d1-e9e3-4bda-a9c6-50bcfe5cc355',0);
/*!40000 ALTER TABLE `s3_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_group_default_rules`
--

DROP TABLE IF EXISTS `security_group_default_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `security_group_default_rules` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `protocol` varchar(5) DEFAULT NULL,
  `from_port` int(11) DEFAULT NULL,
  `to_port` int(11) DEFAULT NULL,
  `cidr` varchar(43) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_group_default_rules`
--

LOCK TABLES `security_group_default_rules` WRITE;
/*!40000 ALTER TABLE `security_group_default_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `security_group_default_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_group_instance_association`
--

DROP TABLE IF EXISTS `security_group_instance_association`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `security_group_instance_association` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `security_group_id` int(11) DEFAULT NULL,
  `instance_uuid` varchar(36) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `security_group_id` (`security_group_id`),
  KEY `security_group_instance_association_instance_uuid_idx` (`instance_uuid`),
  CONSTRAINT `security_group_instance_association_ibfk_1` FOREIGN KEY (`security_group_id`) REFERENCES `security_groups` (`id`),
  CONSTRAINT `security_group_instance_association_instance_uuid_fkey` FOREIGN KEY (`instance_uuid`) REFERENCES `instances` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_group_instance_association`
--

LOCK TABLES `security_group_instance_association` WRITE;
/*!40000 ALTER TABLE `security_group_instance_association` DISABLE KEYS */;
/*!40000 ALTER TABLE `security_group_instance_association` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_group_rules`
--

DROP TABLE IF EXISTS `security_group_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `security_group_rules` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_group_id` int(11) DEFAULT NULL,
  `protocol` varchar(255) DEFAULT NULL,
  `from_port` int(11) DEFAULT NULL,
  `to_port` int(11) DEFAULT NULL,
  `cidr` varchar(43) DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `parent_group_id` (`parent_group_id`),
  KEY `group_id` (`group_id`),
  CONSTRAINT `security_group_rules_ibfk_1` FOREIGN KEY (`parent_group_id`) REFERENCES `security_groups` (`id`),
  CONSTRAINT `security_group_rules_ibfk_2` FOREIGN KEY (`group_id`) REFERENCES `security_groups` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_group_rules`
--

LOCK TABLES `security_group_rules` WRITE;
/*!40000 ALTER TABLE `security_group_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `security_group_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_groups`
--

DROP TABLE IF EXISTS `security_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `security_groups` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_security_groups0project_id0name0deleted` (`project_id`,`name`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_groups`
--

LOCK TABLES `security_groups` WRITE;
/*!40000 ALTER TABLE `security_groups` DISABLE KEYS */;
INSERT INTO `security_groups` VALUES ('2019-12-25 03:12:55',NULL,NULL,3,'default','default','871c3da4707d4524af705b7eff6e34a2','673aefad16724aa994e9224b37780ca0',0);
/*!40000 ALTER TABLE `security_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `services` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `host` varchar(255) DEFAULT NULL,
  `binary` varchar(255) DEFAULT NULL,
  `topic` varchar(255) DEFAULT NULL,
  `report_count` int(11) NOT NULL,
  `disabled` tinyint(1) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `disabled_reason` varchar(255) DEFAULT NULL,
  `last_seen_up` datetime DEFAULT NULL,
  `forced_down` tinyint(1) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `uuid` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_services0host0topic0deleted` (`host`,`topic`,`deleted`),
  UNIQUE KEY `uniq_services0host0binary0deleted` (`host`,`binary`,`deleted`),
  UNIQUE KEY `services_uuid_idx` (`uuid`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`disabled` in (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services`
--

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_agent_builds`
--

DROP TABLE IF EXISTS `shadow_agent_builds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_agent_builds` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hypervisor` varchar(255) DEFAULT NULL,
  `os` varchar(255) DEFAULT NULL,
  `architecture` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `md5hash` varchar(255) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_agent_builds`
--

LOCK TABLES `shadow_agent_builds` WRITE;
/*!40000 ALTER TABLE `shadow_agent_builds` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_agent_builds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_aggregate_hosts`
--

DROP TABLE IF EXISTS `shadow_aggregate_hosts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_aggregate_hosts` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `host` varchar(255) DEFAULT NULL,
  `aggregate_id` int(11) NOT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_aggregate_hosts`
--

LOCK TABLES `shadow_aggregate_hosts` WRITE;
/*!40000 ALTER TABLE `shadow_aggregate_hosts` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_aggregate_hosts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_aggregate_metadata`
--

DROP TABLE IF EXISTS `shadow_aggregate_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_aggregate_metadata` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aggregate_id` int(11) NOT NULL,
  `key` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_aggregate_metadata`
--

LOCK TABLES `shadow_aggregate_metadata` WRITE;
/*!40000 ALTER TABLE `shadow_aggregate_metadata` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_aggregate_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_aggregates`
--

DROP TABLE IF EXISTS `shadow_aggregates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_aggregates` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `uuid` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_aggregates`
--

LOCK TABLES `shadow_aggregates` WRITE;
/*!40000 ALTER TABLE `shadow_aggregates` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_aggregates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_block_device_mapping`
--

DROP TABLE IF EXISTS `shadow_block_device_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_block_device_mapping` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_name` varchar(255) DEFAULT NULL,
  `delete_on_termination` tinyint(1) DEFAULT NULL,
  `snapshot_id` varchar(36) DEFAULT NULL,
  `volume_id` varchar(36) DEFAULT NULL,
  `volume_size` int(11) DEFAULT NULL,
  `no_device` tinyint(1) DEFAULT NULL,
  `connection_info` mediumtext DEFAULT NULL,
  `instance_uuid` varchar(36) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `source_type` varchar(255) DEFAULT NULL,
  `destination_type` varchar(255) DEFAULT NULL,
  `guest_format` varchar(255) DEFAULT NULL,
  `device_type` varchar(255) DEFAULT NULL,
  `disk_bus` varchar(255) DEFAULT NULL,
  `boot_index` int(11) DEFAULT NULL,
  `image_id` varchar(36) DEFAULT NULL,
  `tag` varchar(255) DEFAULT NULL,
  `attachment_id` varchar(36) DEFAULT NULL,
  `uuid` varchar(36) DEFAULT NULL,
  `volume_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_block_device_mapping`
--

LOCK TABLES `shadow_block_device_mapping` WRITE;
/*!40000 ALTER TABLE `shadow_block_device_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_block_device_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_bw_usage_cache`
--

DROP TABLE IF EXISTS `shadow_bw_usage_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_bw_usage_cache` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `start_period` datetime NOT NULL,
  `last_refreshed` datetime DEFAULT NULL,
  `bw_in` bigint(20) DEFAULT NULL,
  `bw_out` bigint(20) DEFAULT NULL,
  `mac` varchar(255) DEFAULT NULL,
  `uuid` varchar(36) DEFAULT NULL,
  `last_ctr_in` bigint(20) DEFAULT NULL,
  `last_ctr_out` bigint(20) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_bw_usage_cache`
--

LOCK TABLES `shadow_bw_usage_cache` WRITE;
/*!40000 ALTER TABLE `shadow_bw_usage_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_bw_usage_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_cells`
--

DROP TABLE IF EXISTS `shadow_cells`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_cells` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `api_url` varchar(255) DEFAULT NULL,
  `weight_offset` float DEFAULT NULL,
  `weight_scale` float DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `is_parent` tinyint(1) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `transport_url` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_cells`
--

LOCK TABLES `shadow_cells` WRITE;
/*!40000 ALTER TABLE `shadow_cells` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_cells` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_certificates`
--

DROP TABLE IF EXISTS `shadow_certificates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_certificates` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(255) DEFAULT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_certificates`
--

LOCK TABLES `shadow_certificates` WRITE;
/*!40000 ALTER TABLE `shadow_certificates` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_certificates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_compute_nodes`
--

DROP TABLE IF EXISTS `shadow_compute_nodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_compute_nodes` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_id` int(11) DEFAULT NULL,
  `vcpus` int(11) NOT NULL,
  `memory_mb` int(11) NOT NULL,
  `local_gb` int(11) NOT NULL,
  `vcpus_used` int(11) NOT NULL,
  `memory_mb_used` int(11) NOT NULL,
  `local_gb_used` int(11) NOT NULL,
  `hypervisor_type` mediumtext NOT NULL,
  `hypervisor_version` int(11) NOT NULL,
  `cpu_info` mediumtext NOT NULL,
  `disk_available_least` int(11) DEFAULT NULL,
  `free_ram_mb` int(11) DEFAULT NULL,
  `free_disk_gb` int(11) DEFAULT NULL,
  `current_workload` int(11) DEFAULT NULL,
  `running_vms` int(11) DEFAULT NULL,
  `hypervisor_hostname` varchar(255) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `host_ip` varchar(39) DEFAULT NULL,
  `supported_instances` text DEFAULT NULL,
  `pci_stats` text DEFAULT NULL,
  `metrics` text DEFAULT NULL,
  `extra_resources` text DEFAULT NULL,
  `stats` text DEFAULT NULL,
  `numa_topology` text DEFAULT NULL,
  `host` varchar(255) DEFAULT NULL,
  `ram_allocation_ratio` float DEFAULT NULL,
  `cpu_allocation_ratio` float DEFAULT NULL,
  `uuid` varchar(36) DEFAULT NULL,
  `disk_allocation_ratio` float DEFAULT NULL,
  `mapped` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_compute_nodes`
--

LOCK TABLES `shadow_compute_nodes` WRITE;
/*!40000 ALTER TABLE `shadow_compute_nodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_compute_nodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_console_pools`
--

DROP TABLE IF EXISTS `shadow_console_pools`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_console_pools` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `address` varchar(39) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `console_type` varchar(255) DEFAULT NULL,
  `public_hostname` varchar(255) DEFAULT NULL,
  `host` varchar(255) DEFAULT NULL,
  `compute_host` varchar(255) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_console_pools`
--

LOCK TABLES `shadow_console_pools` WRITE;
/*!40000 ALTER TABLE `shadow_console_pools` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_console_pools` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_consoles`
--

DROP TABLE IF EXISTS `shadow_consoles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_consoles` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `instance_name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `port` int(11) DEFAULT NULL,
  `pool_id` int(11) DEFAULT NULL,
  `instance_uuid` varchar(36) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_consoles`
--

LOCK TABLES `shadow_consoles` WRITE;
/*!40000 ALTER TABLE `shadow_consoles` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_consoles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_dns_domains`
--

DROP TABLE IF EXISTS `shadow_dns_domains`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_dns_domains` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `domain` varchar(255) NOT NULL,
  `scope` varchar(255) DEFAULT NULL,
  `availability_zone` varchar(255) DEFAULT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`domain`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_dns_domains`
--

LOCK TABLES `shadow_dns_domains` WRITE;
/*!40000 ALTER TABLE `shadow_dns_domains` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_dns_domains` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_fixed_ips`
--

DROP TABLE IF EXISTS `shadow_fixed_ips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_fixed_ips` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `address` varchar(39) DEFAULT NULL,
  `network_id` int(11) DEFAULT NULL,
  `allocated` tinyint(1) DEFAULT NULL,
  `leased` tinyint(1) DEFAULT NULL,
  `reserved` tinyint(1) DEFAULT NULL,
  `virtual_interface_id` int(11) DEFAULT NULL,
  `host` varchar(255) DEFAULT NULL,
  `instance_uuid` varchar(36) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_fixed_ips`
--

LOCK TABLES `shadow_fixed_ips` WRITE;
/*!40000 ALTER TABLE `shadow_fixed_ips` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_fixed_ips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_floating_ips`
--

DROP TABLE IF EXISTS `shadow_floating_ips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_floating_ips` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `address` varchar(39) DEFAULT NULL,
  `fixed_ip_id` int(11) DEFAULT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `host` varchar(255) DEFAULT NULL,
  `auto_assigned` tinyint(1) DEFAULT NULL,
  `pool` varchar(255) DEFAULT NULL,
  `interface` varchar(255) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_floating_ips`
--

LOCK TABLES `shadow_floating_ips` WRITE;
/*!40000 ALTER TABLE `shadow_floating_ips` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_floating_ips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_instance_actions`
--

DROP TABLE IF EXISTS `shadow_instance_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_instance_actions` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action` varchar(255) DEFAULT NULL,
  `instance_uuid` varchar(36) DEFAULT NULL,
  `request_id` varchar(255) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `finish_time` datetime DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_instance_actions`
--

LOCK TABLES `shadow_instance_actions` WRITE;
/*!40000 ALTER TABLE `shadow_instance_actions` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_instance_actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_instance_actions_events`
--

DROP TABLE IF EXISTS `shadow_instance_actions_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_instance_actions_events` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event` varchar(255) DEFAULT NULL,
  `action_id` int(11) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `finish_time` datetime DEFAULT NULL,
  `result` varchar(255) DEFAULT NULL,
  `traceback` text DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `host` varchar(255) DEFAULT NULL,
  `details` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_instance_actions_events`
--

LOCK TABLES `shadow_instance_actions_events` WRITE;
/*!40000 ALTER TABLE `shadow_instance_actions_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_instance_actions_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_instance_extra`
--

DROP TABLE IF EXISTS `shadow_instance_extra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_instance_extra` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `instance_uuid` varchar(36) NOT NULL,
  `numa_topology` text DEFAULT NULL,
  `pci_requests` text DEFAULT NULL,
  `flavor` text DEFAULT NULL,
  `vcpu_model` text DEFAULT NULL,
  `migration_context` text DEFAULT NULL,
  `keypairs` text DEFAULT NULL,
  `device_metadata` text DEFAULT NULL,
  `trusted_certs` text DEFAULT NULL,
  `vpmems` text DEFAULT NULL,
  `resources` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shadow_instance_extra_idx` (`instance_uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_instance_extra`
--

LOCK TABLES `shadow_instance_extra` WRITE;
/*!40000 ALTER TABLE `shadow_instance_extra` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_instance_extra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_instance_faults`
--

DROP TABLE IF EXISTS `shadow_instance_faults`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_instance_faults` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `instance_uuid` varchar(36) DEFAULT NULL,
  `code` int(11) NOT NULL,
  `message` varchar(255) DEFAULT NULL,
  `details` mediumtext DEFAULT NULL,
  `host` varchar(255) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_instance_faults`
--

LOCK TABLES `shadow_instance_faults` WRITE;
/*!40000 ALTER TABLE `shadow_instance_faults` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_instance_faults` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_instance_group_member`
--

DROP TABLE IF EXISTS `shadow_instance_group_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_instance_group_member` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `instance_id` varchar(255) DEFAULT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_instance_group_member`
--

LOCK TABLES `shadow_instance_group_member` WRITE;
/*!40000 ALTER TABLE `shadow_instance_group_member` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_instance_group_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_instance_group_policy`
--

DROP TABLE IF EXISTS `shadow_instance_group_policy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_instance_group_policy` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `policy` varchar(255) DEFAULT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_instance_group_policy`
--

LOCK TABLES `shadow_instance_group_policy` WRITE;
/*!40000 ALTER TABLE `shadow_instance_group_policy` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_instance_group_policy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_instance_groups`
--

DROP TABLE IF EXISTS `shadow_instance_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_instance_groups` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(255) DEFAULT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `uuid` varchar(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_instance_groups`
--

LOCK TABLES `shadow_instance_groups` WRITE;
/*!40000 ALTER TABLE `shadow_instance_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_instance_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_instance_id_mappings`
--

DROP TABLE IF EXISTS `shadow_instance_id_mappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_instance_id_mappings` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_instance_id_mappings`
--

LOCK TABLES `shadow_instance_id_mappings` WRITE;
/*!40000 ALTER TABLE `shadow_instance_id_mappings` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_instance_id_mappings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_instance_info_caches`
--

DROP TABLE IF EXISTS `shadow_instance_info_caches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_instance_info_caches` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `network_info` mediumtext DEFAULT NULL,
  `instance_uuid` varchar(36) NOT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_instance_info_caches`
--

LOCK TABLES `shadow_instance_info_caches` WRITE;
/*!40000 ALTER TABLE `shadow_instance_info_caches` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_instance_info_caches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_instance_metadata`
--

DROP TABLE IF EXISTS `shadow_instance_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_instance_metadata` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `instance_uuid` varchar(36) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_instance_metadata`
--

LOCK TABLES `shadow_instance_metadata` WRITE;
/*!40000 ALTER TABLE `shadow_instance_metadata` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_instance_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_instance_system_metadata`
--

DROP TABLE IF EXISTS `shadow_instance_system_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_instance_system_metadata` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `instance_uuid` varchar(36) NOT NULL,
  `key` varchar(255) NOT NULL,
  `value` varchar(255) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_instance_system_metadata`
--

LOCK TABLES `shadow_instance_system_metadata` WRITE;
/*!40000 ALTER TABLE `shadow_instance_system_metadata` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_instance_system_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_instance_type_extra_specs`
--

DROP TABLE IF EXISTS `shadow_instance_type_extra_specs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_instance_type_extra_specs` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `instance_type_id` int(11) NOT NULL,
  `key` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_instance_type_extra_specs`
--

LOCK TABLES `shadow_instance_type_extra_specs` WRITE;
/*!40000 ALTER TABLE `shadow_instance_type_extra_specs` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_instance_type_extra_specs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_instance_type_projects`
--

DROP TABLE IF EXISTS `shadow_instance_type_projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_instance_type_projects` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `instance_type_id` int(11) NOT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_instance_type_projects`
--

LOCK TABLES `shadow_instance_type_projects` WRITE;
/*!40000 ALTER TABLE `shadow_instance_type_projects` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_instance_type_projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_instance_types`
--

DROP TABLE IF EXISTS `shadow_instance_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_instance_types` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `memory_mb` int(11) NOT NULL,
  `vcpus` int(11) NOT NULL,
  `swap` int(11) NOT NULL,
  `vcpu_weight` int(11) DEFAULT NULL,
  `flavorid` varchar(255) DEFAULT NULL,
  `rxtx_factor` float DEFAULT NULL,
  `root_gb` int(11) DEFAULT NULL,
  `ephemeral_gb` int(11) DEFAULT NULL,
  `disabled` tinyint(1) DEFAULT NULL,
  `is_public` tinyint(1) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_instance_types`
--

LOCK TABLES `shadow_instance_types` WRITE;
/*!40000 ALTER TABLE `shadow_instance_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_instance_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_instances`
--

DROP TABLE IF EXISTS `shadow_instances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_instances` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `internal_id` int(11) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `image_ref` varchar(255) DEFAULT NULL,
  `kernel_id` varchar(255) DEFAULT NULL,
  `ramdisk_id` varchar(255) DEFAULT NULL,
  `launch_index` int(11) DEFAULT NULL,
  `key_name` varchar(255) DEFAULT NULL,
  `key_data` mediumtext DEFAULT NULL,
  `power_state` int(11) DEFAULT NULL,
  `vm_state` varchar(255) DEFAULT NULL,
  `memory_mb` int(11) DEFAULT NULL,
  `vcpus` int(11) DEFAULT NULL,
  `hostname` varchar(255) DEFAULT NULL,
  `host` varchar(255) DEFAULT NULL,
  `user_data` mediumtext DEFAULT NULL,
  `reservation_id` varchar(255) DEFAULT NULL,
  `launched_at` datetime DEFAULT NULL,
  `terminated_at` datetime DEFAULT NULL,
  `display_name` varchar(255) DEFAULT NULL,
  `display_description` varchar(255) DEFAULT NULL,
  `availability_zone` varchar(255) DEFAULT NULL,
  `locked` tinyint(1) DEFAULT NULL,
  `os_type` varchar(255) DEFAULT NULL,
  `launched_on` mediumtext DEFAULT NULL,
  `instance_type_id` int(11) DEFAULT NULL,
  `vm_mode` varchar(255) DEFAULT NULL,
  `uuid` varchar(36) NOT NULL,
  `architecture` varchar(255) DEFAULT NULL,
  `root_device_name` varchar(255) DEFAULT NULL,
  `access_ip_v4` varchar(39) DEFAULT NULL,
  `access_ip_v6` varchar(39) DEFAULT NULL,
  `config_drive` varchar(255) DEFAULT NULL,
  `task_state` varchar(255) DEFAULT NULL,
  `default_ephemeral_device` varchar(255) DEFAULT NULL,
  `default_swap_device` varchar(255) DEFAULT NULL,
  `progress` int(11) DEFAULT NULL,
  `auto_disk_config` tinyint(1) DEFAULT NULL,
  `shutdown_terminate` tinyint(1) DEFAULT NULL,
  `disable_terminate` tinyint(1) DEFAULT NULL,
  `root_gb` int(11) DEFAULT NULL,
  `ephemeral_gb` int(11) DEFAULT NULL,
  `cell_name` varchar(255) DEFAULT NULL,
  `node` varchar(255) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `locked_by` enum('owner','admin') DEFAULT NULL,
  `cleaned` int(11) DEFAULT NULL,
  `ephemeral_key_uuid` varchar(36) DEFAULT NULL,
  `hidden` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_instances`
--

LOCK TABLES `shadow_instances` WRITE;
/*!40000 ALTER TABLE `shadow_instances` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_instances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_key_pairs`
--

DROP TABLE IF EXISTS `shadow_key_pairs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_key_pairs` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `fingerprint` varchar(255) DEFAULT NULL,
  `public_key` mediumtext DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `type` enum('ssh','x509') NOT NULL DEFAULT 'ssh',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_key_pairs`
--

LOCK TABLES `shadow_key_pairs` WRITE;
/*!40000 ALTER TABLE `shadow_key_pairs` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_key_pairs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_migrate_version`
--

DROP TABLE IF EXISTS `shadow_migrate_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_migrate_version` (
  `repository_id` varchar(250) NOT NULL,
  `repository_path` text DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  PRIMARY KEY (`repository_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_migrate_version`
--

LOCK TABLES `shadow_migrate_version` WRITE;
/*!40000 ALTER TABLE `shadow_migrate_version` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_migrate_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_migrations`
--

DROP TABLE IF EXISTS `shadow_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_migrations` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `source_compute` varchar(255) DEFAULT NULL,
  `dest_compute` varchar(255) DEFAULT NULL,
  `dest_host` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `instance_uuid` varchar(36) DEFAULT NULL,
  `old_instance_type_id` int(11) DEFAULT NULL,
  `new_instance_type_id` int(11) DEFAULT NULL,
  `source_node` varchar(255) DEFAULT NULL,
  `dest_node` varchar(255) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `migration_type` enum('migration','resize','live-migration','evacuation') DEFAULT NULL,
  `hidden` tinyint(1) DEFAULT NULL,
  `memory_total` bigint(20) DEFAULT NULL,
  `memory_processed` bigint(20) DEFAULT NULL,
  `memory_remaining` bigint(20) DEFAULT NULL,
  `disk_total` bigint(20) DEFAULT NULL,
  `disk_processed` bigint(20) DEFAULT NULL,
  `disk_remaining` bigint(20) DEFAULT NULL,
  `uuid` varchar(36) DEFAULT NULL,
  `cross_cell_move` tinyint(1) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `shadow_migrations_uuid` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_migrations`
--

LOCK TABLES `shadow_migrations` WRITE;
/*!40000 ALTER TABLE `shadow_migrations` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_networks`
--

DROP TABLE IF EXISTS `shadow_networks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_networks` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `injected` tinyint(1) DEFAULT NULL,
  `cidr` varchar(43) DEFAULT NULL,
  `netmask` varchar(39) DEFAULT NULL,
  `bridge` varchar(255) DEFAULT NULL,
  `gateway` varchar(39) DEFAULT NULL,
  `broadcast` varchar(39) DEFAULT NULL,
  `dns1` varchar(39) DEFAULT NULL,
  `vlan` int(11) DEFAULT NULL,
  `vpn_public_address` varchar(39) DEFAULT NULL,
  `vpn_public_port` int(11) DEFAULT NULL,
  `vpn_private_address` varchar(39) DEFAULT NULL,
  `dhcp_start` varchar(39) DEFAULT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `host` varchar(255) DEFAULT NULL,
  `cidr_v6` varchar(43) DEFAULT NULL,
  `gateway_v6` varchar(39) DEFAULT NULL,
  `label` varchar(255) DEFAULT NULL,
  `netmask_v6` varchar(39) DEFAULT NULL,
  `bridge_interface` varchar(255) DEFAULT NULL,
  `multi_host` tinyint(1) DEFAULT NULL,
  `dns2` varchar(39) DEFAULT NULL,
  `uuid` varchar(36) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  `rxtx_base` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `mtu` int(11) DEFAULT NULL,
  `dhcp_server` varchar(39) DEFAULT NULL,
  `enable_dhcp` tinyint(1) DEFAULT NULL,
  `share_address` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_networks`
--

LOCK TABLES `shadow_networks` WRITE;
/*!40000 ALTER TABLE `shadow_networks` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_networks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_pci_devices`
--

DROP TABLE IF EXISTS `shadow_pci_devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_pci_devices` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `compute_node_id` int(11) NOT NULL,
  `address` varchar(12) NOT NULL,
  `product_id` varchar(4) DEFAULT NULL,
  `vendor_id` varchar(4) DEFAULT NULL,
  `dev_type` varchar(8) DEFAULT NULL,
  `dev_id` varchar(255) DEFAULT NULL,
  `label` varchar(255) NOT NULL,
  `status` varchar(36) NOT NULL,
  `extra_info` text DEFAULT NULL,
  `instance_uuid` varchar(36) DEFAULT NULL,
  `request_id` varchar(36) DEFAULT NULL,
  `numa_node` int(11) DEFAULT NULL,
  `parent_addr` varchar(12) DEFAULT NULL,
  `uuid` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_pci_devices`
--

LOCK TABLES `shadow_pci_devices` WRITE;
/*!40000 ALTER TABLE `shadow_pci_devices` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_pci_devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_project_user_quotas`
--

DROP TABLE IF EXISTS `shadow_project_user_quotas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_project_user_quotas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `user_id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `resource` varchar(255) NOT NULL,
  `hard_limit` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_project_user_quotas`
--

LOCK TABLES `shadow_project_user_quotas` WRITE;
/*!40000 ALTER TABLE `shadow_project_user_quotas` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_project_user_quotas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_provider_fw_rules`
--

DROP TABLE IF EXISTS `shadow_provider_fw_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_provider_fw_rules` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `protocol` varchar(5) DEFAULT NULL,
  `from_port` int(11) DEFAULT NULL,
  `to_port` int(11) DEFAULT NULL,
  `cidr` varchar(43) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_provider_fw_rules`
--

LOCK TABLES `shadow_provider_fw_rules` WRITE;
/*!40000 ALTER TABLE `shadow_provider_fw_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_provider_fw_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_quota_classes`
--

DROP TABLE IF EXISTS `shadow_quota_classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_quota_classes` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_name` varchar(255) DEFAULT NULL,
  `resource` varchar(255) DEFAULT NULL,
  `hard_limit` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_quota_classes`
--

LOCK TABLES `shadow_quota_classes` WRITE;
/*!40000 ALTER TABLE `shadow_quota_classes` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_quota_classes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_quota_usages`
--

DROP TABLE IF EXISTS `shadow_quota_usages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_quota_usages` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` varchar(255) DEFAULT NULL,
  `resource` varchar(255) DEFAULT NULL,
  `in_use` int(11) NOT NULL,
  `reserved` int(11) NOT NULL,
  `until_refresh` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_quota_usages`
--

LOCK TABLES `shadow_quota_usages` WRITE;
/*!40000 ALTER TABLE `shadow_quota_usages` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_quota_usages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_quotas`
--

DROP TABLE IF EXISTS `shadow_quotas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_quotas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `resource` varchar(255) NOT NULL,
  `hard_limit` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_quotas`
--

LOCK TABLES `shadow_quotas` WRITE;
/*!40000 ALTER TABLE `shadow_quotas` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_quotas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_reservations`
--

DROP TABLE IF EXISTS `shadow_reservations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_reservations` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `usage_id` int(11) NOT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `resource` varchar(255) DEFAULT NULL,
  `delta` int(11) NOT NULL,
  `expire` datetime DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_reservations`
--

LOCK TABLES `shadow_reservations` WRITE;
/*!40000 ALTER TABLE `shadow_reservations` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_reservations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_s3_images`
--

DROP TABLE IF EXISTS `shadow_s3_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_s3_images` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_s3_images`
--

LOCK TABLES `shadow_s3_images` WRITE;
/*!40000 ALTER TABLE `shadow_s3_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_s3_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_security_group_default_rules`
--

DROP TABLE IF EXISTS `shadow_security_group_default_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_security_group_default_rules` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `protocol` varchar(5) DEFAULT NULL,
  `from_port` int(11) DEFAULT NULL,
  `to_port` int(11) DEFAULT NULL,
  `cidr` varchar(43) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_security_group_default_rules`
--

LOCK TABLES `shadow_security_group_default_rules` WRITE;
/*!40000 ALTER TABLE `shadow_security_group_default_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_security_group_default_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_security_group_instance_association`
--

DROP TABLE IF EXISTS `shadow_security_group_instance_association`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_security_group_instance_association` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `security_group_id` int(11) DEFAULT NULL,
  `instance_uuid` varchar(36) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_security_group_instance_association`
--

LOCK TABLES `shadow_security_group_instance_association` WRITE;
/*!40000 ALTER TABLE `shadow_security_group_instance_association` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_security_group_instance_association` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_security_group_rules`
--

DROP TABLE IF EXISTS `shadow_security_group_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_security_group_rules` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_group_id` int(11) DEFAULT NULL,
  `protocol` varchar(255) DEFAULT NULL,
  `from_port` int(11) DEFAULT NULL,
  `to_port` int(11) DEFAULT NULL,
  `cidr` varchar(43) DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_security_group_rules`
--

LOCK TABLES `shadow_security_group_rules` WRITE;
/*!40000 ALTER TABLE `shadow_security_group_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_security_group_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_security_groups`
--

DROP TABLE IF EXISTS `shadow_security_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_security_groups` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_security_groups`
--

LOCK TABLES `shadow_security_groups` WRITE;
/*!40000 ALTER TABLE `shadow_security_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_security_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_services`
--

DROP TABLE IF EXISTS `shadow_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_services` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `host` varchar(255) DEFAULT NULL,
  `binary` varchar(255) DEFAULT NULL,
  `topic` varchar(255) DEFAULT NULL,
  `report_count` int(11) NOT NULL,
  `disabled` tinyint(1) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `disabled_reason` varchar(255) DEFAULT NULL,
  `last_seen_up` datetime DEFAULT NULL,
  `forced_down` tinyint(1) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `uuid` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_services`
--

LOCK TABLES `shadow_services` WRITE;
/*!40000 ALTER TABLE `shadow_services` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_snapshot_id_mappings`
--

DROP TABLE IF EXISTS `shadow_snapshot_id_mappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_snapshot_id_mappings` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_snapshot_id_mappings`
--

LOCK TABLES `shadow_snapshot_id_mappings` WRITE;
/*!40000 ALTER TABLE `shadow_snapshot_id_mappings` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_snapshot_id_mappings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_snapshots`
--

DROP TABLE IF EXISTS `shadow_snapshots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_snapshots` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` varchar(36) NOT NULL,
  `volume_id` varchar(36) NOT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `progress` varchar(255) DEFAULT NULL,
  `volume_size` int(11) DEFAULT NULL,
  `scheduled_at` datetime DEFAULT NULL,
  `display_name` varchar(255) DEFAULT NULL,
  `display_description` varchar(255) DEFAULT NULL,
  `deleted` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_snapshots`
--

LOCK TABLES `shadow_snapshots` WRITE;
/*!40000 ALTER TABLE `shadow_snapshots` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_snapshots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_task_log`
--

DROP TABLE IF EXISTS `shadow_task_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_task_log` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_name` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `host` varchar(255) NOT NULL,
  `period_beginning` datetime NOT NULL,
  `period_ending` datetime NOT NULL,
  `message` varchar(255) NOT NULL,
  `task_items` int(11) DEFAULT NULL,
  `errors` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_task_log`
--

LOCK TABLES `shadow_task_log` WRITE;
/*!40000 ALTER TABLE `shadow_task_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_task_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_virtual_interfaces`
--

DROP TABLE IF EXISTS `shadow_virtual_interfaces`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_virtual_interfaces` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `address` varchar(255) DEFAULT NULL,
  `network_id` int(11) DEFAULT NULL,
  `uuid` varchar(36) DEFAULT NULL,
  `instance_uuid` varchar(36) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `tag` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_virtual_interfaces`
--

LOCK TABLES `shadow_virtual_interfaces` WRITE;
/*!40000 ALTER TABLE `shadow_virtual_interfaces` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_virtual_interfaces` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_volume_id_mappings`
--

DROP TABLE IF EXISTS `shadow_volume_id_mappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_volume_id_mappings` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_volume_id_mappings`
--

LOCK TABLES `shadow_volume_id_mappings` WRITE;
/*!40000 ALTER TABLE `shadow_volume_id_mappings` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_volume_id_mappings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shadow_volume_usage_cache`
--

DROP TABLE IF EXISTS `shadow_volume_usage_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shadow_volume_usage_cache` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `volume_id` varchar(36) NOT NULL,
  `tot_last_refreshed` datetime DEFAULT NULL,
  `tot_reads` bigint(20) DEFAULT NULL,
  `tot_read_bytes` bigint(20) DEFAULT NULL,
  `tot_writes` bigint(20) DEFAULT NULL,
  `tot_write_bytes` bigint(20) DEFAULT NULL,
  `curr_last_refreshed` datetime DEFAULT NULL,
  `curr_reads` bigint(20) DEFAULT NULL,
  `curr_read_bytes` bigint(20) DEFAULT NULL,
  `curr_writes` bigint(20) DEFAULT NULL,
  `curr_write_bytes` bigint(20) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `instance_uuid` varchar(36) DEFAULT NULL,
  `project_id` varchar(36) DEFAULT NULL,
  `user_id` varchar(36) DEFAULT NULL,
  `availability_zone` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shadow_volume_usage_cache`
--

LOCK TABLES `shadow_volume_usage_cache` WRITE;
/*!40000 ALTER TABLE `shadow_volume_usage_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `shadow_volume_usage_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `snapshot_id_mappings`
--

DROP TABLE IF EXISTS `snapshot_id_mappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `snapshot_id_mappings` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `snapshot_id_mappings`
--

LOCK TABLES `snapshot_id_mappings` WRITE;
/*!40000 ALTER TABLE `snapshot_id_mappings` DISABLE KEYS */;
/*!40000 ALTER TABLE `snapshot_id_mappings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `snapshots`
--

DROP TABLE IF EXISTS `snapshots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `snapshots` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` varchar(36) NOT NULL,
  `volume_id` varchar(36) NOT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `progress` varchar(255) DEFAULT NULL,
  `volume_size` int(11) DEFAULT NULL,
  `scheduled_at` datetime DEFAULT NULL,
  `display_name` varchar(255) DEFAULT NULL,
  `display_description` varchar(255) DEFAULT NULL,
  `deleted` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `snapshots`
--

LOCK TABLES `snapshots` WRITE;
/*!40000 ALTER TABLE `snapshots` DISABLE KEYS */;
/*!40000 ALTER TABLE `snapshots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
  `resource_id` varchar(36) NOT NULL,
  `tag` varchar(80) NOT NULL,
  PRIMARY KEY (`resource_id`,`tag`),
  KEY `tags_tag_idx` (`tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task_log`
--

DROP TABLE IF EXISTS `task_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task_log` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_name` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `host` varchar(255) NOT NULL,
  `period_beginning` datetime NOT NULL,
  `period_ending` datetime NOT NULL,
  `message` varchar(255) NOT NULL,
  `task_items` int(11) DEFAULT NULL,
  `errors` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_task_log0task_name0host0period_beginning0period_ending` (`task_name`,`host`,`period_beginning`,`period_ending`),
  KEY `ix_task_log_period_beginning` (`period_beginning`),
  KEY `ix_task_log_host` (`host`),
  KEY `ix_task_log_period_ending` (`period_ending`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_log`
--

LOCK TABLES `task_log` WRITE;
/*!40000 ALTER TABLE `task_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `task_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `virtual_interfaces`
--

DROP TABLE IF EXISTS `virtual_interfaces`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `virtual_interfaces` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `address` varchar(255) DEFAULT NULL,
  `network_id` int(11) DEFAULT NULL,
  `uuid` varchar(36) DEFAULT NULL,
  `instance_uuid` varchar(36) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `tag` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_virtual_interfaces0address0deleted` (`address`,`deleted`),
  KEY `virtual_interfaces_instance_uuid_fkey` (`instance_uuid`),
  KEY `virtual_interfaces_network_id_idx` (`network_id`),
  KEY `virtual_interfaces_uuid_idx` (`uuid`),
  CONSTRAINT `virtual_interfaces_instance_uuid_fkey` FOREIGN KEY (`instance_uuid`) REFERENCES `instances` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `virtual_interfaces`
--

LOCK TABLES `virtual_interfaces` WRITE;
/*!40000 ALTER TABLE `virtual_interfaces` DISABLE KEYS */;
/*!40000 ALTER TABLE `virtual_interfaces` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volume_id_mappings`
--

DROP TABLE IF EXISTS `volume_id_mappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volume_id_mappings` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volume_id_mappings`
--

LOCK TABLES `volume_id_mappings` WRITE;
/*!40000 ALTER TABLE `volume_id_mappings` DISABLE KEYS */;
/*!40000 ALTER TABLE `volume_id_mappings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volume_usage_cache`
--

DROP TABLE IF EXISTS `volume_usage_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volume_usage_cache` (
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `volume_id` varchar(36) NOT NULL,
  `tot_last_refreshed` datetime DEFAULT NULL,
  `tot_reads` bigint(20) DEFAULT NULL,
  `tot_read_bytes` bigint(20) DEFAULT NULL,
  `tot_writes` bigint(20) DEFAULT NULL,
  `tot_write_bytes` bigint(20) DEFAULT NULL,
  `curr_last_refreshed` datetime DEFAULT NULL,
  `curr_reads` bigint(20) DEFAULT NULL,
  `curr_read_bytes` bigint(20) DEFAULT NULL,
  `curr_writes` bigint(20) DEFAULT NULL,
  `curr_write_bytes` bigint(20) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `instance_uuid` varchar(36) DEFAULT NULL,
  `project_id` varchar(36) DEFAULT NULL,
  `user_id` varchar(64) DEFAULT NULL,
  `availability_zone` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volume_usage_cache`
--

LOCK TABLES `volume_usage_cache` WRITE;
/*!40000 ALTER TABLE `volume_usage_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `volume_usage_cache` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-30  0:00:02
